import flet as ft
import json
import os
import shutil
import csv
import asyncio
from datetime import datetime

# === ПАЛИТРА ТЕМЫ ===
PALETTE_LIGHT = {
    "teal_accent": "TEAL_500",
    "card": "WHITE",
    "surface": "GREY_50",
    "text": "BLACK",
    "text_secondary": "GREY_800",
    "text_muted": "GREY_700",
    "text_soft": "GREY_600",
    "text_disabled": "GREY_400",
    "divider": "GREY_300",
    "border": "GREY_300",
    "border_light": "GREY_200",
    "accent": "BLUE_900",
    "accent_soft": "BLUE_50",
    "accent_icon": "BLUE_700",
    "accent_border": "BLUE",
    "link": "BLUE_600",
    "danger": "RED",
    "danger_strong": "RED_700",
    "danger_muted": "RED_400",
    "danger_icon": "RED_600",
    "success": "GREEN_700",
    "success_strong": "GREEN_800",
    "warning_text": "ORANGE_700",
    "warning_strong": "YELLOW_900",
    "teal_text": "TEAL_700",
    "purchase_text": "PURPLE_700",
    "purchase_bg": "PURPLE_50",
    "writeoff_text": "ORANGE_800",
    "writeoff_bg": "ORANGE_50",
    "fuel_text": "TEAL_700",
    "fuel_bg": "TEAL_50",
    "to_text": "GREEN_800",
    "to_bg": "GREEN_50",
    "resolved_text": "GREEN_700",
    "resolved_bg": "GREEN_50",
    "service_text": "INDIGO_700",
    "service_bg": "INDIGO_50",
    "parts_text": "CYAN_700",
    "parts_bg": "CYAN_50",
    "other_text": "BROWN_700",
    "other_bg": "BROWN_50",
    "defect_text": "RED_700",
    "defect_bg": "RED_50",
    "neutral_text": "GREY_700",
    "neutral_bg": "GREY_100",
    "status_red_bg": "RED_50",
    "status_green_bg": "GREEN_50",
    "status_orange_bg": "ORANGE_50",
    "status_yellow_bg": "YELLOW_50",
    "status_indigo_bg": "INDIGO_50",
    "status_cyan_bg": "CYAN_50",
    "status_brown_bg": "BROWN_50",
    "status_purple_bg": "PURPLE_50",
    "status_grey_bg": "GREY_100",
    "teal_soft": "TEAL_50",
}

PALETTE_DARK = {
    "teal_accent": "TEAL_400",
    "card": "GREY_900",
    "surface": "GREY_800",
    "text": "WHITE",
    "text_secondary": "GREY_200",
    "text_muted": "GREY_400",
    "text_soft": "GREY_400",
    "text_disabled": "GREY_600",
    "divider": "GREY_700",
    "border": "GREY_700",
    "border_light": "GREY_800",
    "accent": "BLUE_200",
    "accent_soft": "BLUE_900",
    "accent_icon": "BLUE_300",
    "accent_border": "BLUE_400",
    "link": "BLUE_300",
    "danger": "RED_300",
    "danger_strong": "RED_300",
    "danger_muted": "RED_400",
    "danger_icon": "RED_300",
    "success": "GREEN_300",
    "success_strong": "GREEN_300",
    "warning_text": "ORANGE_300",
    "warning_strong": "YELLOW_300",
    "teal_text": "TEAL_300",
    "purchase_text": "PURPLE_200",
    "purchase_bg": "PURPLE_900",
    "writeoff_text": "ORANGE_200",
    "writeoff_bg": "ORANGE_900",
    "fuel_text": "TEAL_200",
    "fuel_bg": "TEAL_900",
    "to_text": "GREEN_200",
    "to_bg": "GREEN_900",
    "resolved_text": "GREEN_300",
    "resolved_bg": "GREEN_900",
    "service_text": "INDIGO_200",
    "service_bg": "INDIGO_900",
    "parts_text": "CYAN_200",
    "parts_bg": "CYAN_900",
    "other_text": "BROWN_200",
    "other_bg": "BROWN_900",
    "defect_text": "RED_300",
    "defect_bg": "RED_900",
    "neutral_text": "GREY_300",
    "neutral_bg": "GREY_800",
    "status_red_bg": "RED_900",
    "status_green_bg": "GREEN_900",
    "status_orange_bg": "ORANGE_900",
    "status_yellow_bg": "YELLOW_900",
    "status_indigo_bg": "INDIGO_900",
    "status_cyan_bg": "CYAN_900",
    "status_brown_bg": "BROWN_900",
    "status_purple_bg": "PURPLE_900",
    "status_grey_bg": "GREY_800",
    "teal_soft": "TEAL_900",
}

CURRENT_THEME = {"mode": "light"}


def C(key):
    """Возвращает цвет по ключу палитры с учётом текущей темы."""
    palette = PALETTE_DARK if CURRENT_THEME.get("mode") == "dark" else PALETTE_LIGHT
    name = palette.get(key, "GREY_500")
    return getattr(ft.Colors, name)


def status_bg_key(color_key):
    """Возвращает ключ палитры для фона карточки по цвету статуса."""
    return {
        "red": "status_red_bg",
        "orange": "status_orange_bg",
        "yellow": "status_yellow_bg",
        "green": "status_green_bg",
        "grey": "status_grey_bg",
    }.get(color_key, "card")




# === ПУТИ К ФАЙЛАМ ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOGS_DIR = os.path.join(BASE_DIR, "catalogs")
CARS_PATH = os.path.join(CATALOGS_DIR, "cars.json")
ANALOGS_PATH = os.path.join(CATALOGS_DIR, "analogs_torque.json")
KIA_ANALOGS_PATH = os.path.join(CATALOGS_DIR, "analogs_torque_kia.json")
MY_PURCHASES_PATH = os.path.join(CATALOGS_DIR, "my_purchases.json")
BACKUP_DIR = os.path.join(CATALOGS_DIR, "_backup")
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

# Активная машина: сюда кладём путь к файлу каталога.
# Изначально None — заполним при запуске, прочитав cars.json
CATALOG_PATH = None


def get_article_prefix():
    """Возвращает префикс для артикула: VAG для Polo, OEM для Kia."""
    if CATALOG_PATH and "kia" in os.path.basename(CATALOG_PATH).lower():
        return "OEM"
    return "VAG"


def get_article_value(item):
    """Возвращает VAG (Polo) или OEM (Kia) номер, либо 'N/A'."""
    val = item.get("vag") or item.get("oem")
    return val if val else "N/A"


def get_analogs_path():
    """Для Kia — analogs_torque_kia.json, для остальных — analogs_torque.json."""
    if CATALOG_PATH and "kia" in os.path.basename(CATALOG_PATH).lower():
        return KIA_ANALOGS_PATH
    return ANALOGS_PATH


def get_reference_title():
    """Заголовок правой панели радара. Kia → СПРАВОЧНИК KIA, остальные → СПРАВОЧНИК VW."""
    if CATALOG_PATH and "kia" in os.path.basename(CATALOG_PATH).lower():
        return "📖 СПРАВОЧНИК KIA"
    return "📖 СПРАВОЧНИК VW"


def get_current_car_id():
    """Возвращает id текущей активной машины (по совпадению CATALOG_PATH с cars.json)."""
    if not CATALOG_PATH:
        return ""
    try:
        cars = load_cars_list()
    except Exception:
        return ""
    for c in cars:
        if get_catalog_path_for_car(c) == CATALOG_PATH:
            return c.get("id", "")
    return ""


# === ЗАГРУЗКА / СОХРАНЕНИЕ JSON ===
def load_cars_list():
    """Читает список машин из catalogs/cars.json.
    Если файла нет — возвращает одну машину Поло (чтобы программа не падала)."""
    if not os.path.exists(CARS_PATH):
        return [{
            "id": "polo",
            "name": "VW Polo Sedan 2012",
            "file": "vw_polo_2012.json",
            "logo": "vw.png",
        }]
    with open(CARS_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    return fix_keys(data)


def get_catalog_path_for_car(car):
    """Собирает путь к JSON машины из её записи в cars.json."""
    if not car:
        return None
    return os.path.join(CATALOGS_DIR, car.get("file", ""))

SETTINGS_PATH = os.path.join(CATALOGS_DIR, "settings.json")


def load_app_settings():
    """Читает настройки приложения (какая машина выбрана и т.п.)."""
    if not os.path.exists(SETTINGS_PATH):
        return {}
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def save_app_settings(settings):
    """Сохраняет настройки приложения."""
    try:
        os.makedirs(CATALOGS_DIR, exist_ok=True)
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(settings, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def get_saved_car_id():
    """Возвращает id машины, которая была выбрана в прошлый раз (или None)."""
    return load_app_settings().get("active_car_id")


def set_saved_car_id(car_id):
    """Запоминает, какую машину выбрал пользователь."""
    settings = load_app_settings()
    settings["active_car_id"] = car_id
    save_app_settings(settings)


def get_active_car(cars, car_id=None):
    """Возвращает запись машины по id. Если id нет — берёт первую.
    Если id передан, но такой машины в списке нет — тоже первую."""
    if not cars:
        return None
    if not car_id:
        return cars[0]
    for c in cars:
        if c.get("id") == car_id:
            return c
    return cars[0]

def load_catalog():
    if not CATALOG_PATH or not os.path.exists(CATALOG_PATH):
        return None
    with open(CATALOG_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    data = fix_keys(data)

    # Подмена interval_km из файла интервалов машины (если он есть или создаётся)
    try:
        intervals = load_or_create_intervals(data, CATALOG_PATH)
        if intervals:
            for item in data.get("maintenance_radar", []):
                item_id = item.get("id")
                if item_id in intervals:
                    item["interval_km"] = intervals[item_id]
            for category in data.get("parts", []):
                for subcat in category.get("subcategories", []):
                    for item in subcat.get("items", []):
                        item_id = item.get("id")
                        if item_id in intervals:
                            item["interval_km"] = intervals[item_id]
    except Exception:
        pass

    return data

def get_intervals_path(catalog_path):
    """Возвращает путь к файлу интервалов для конкретной машины.
    Например: catalogs/vw_polo_2012.json -> catalogs/vw_polo_2012_intervals.json"""
    if not catalog_path:
        return None
    base = os.path.splitext(os.path.basename(catalog_path))[0]
    return os.path.join(CATALOGS_DIR, f"{base}_intervals.json")


def load_or_create_intervals(catalog, catalog_path):
    """Читает файл интервалов машины. Если файла нет — создаёт его из дефолтов
    каталога (maintenance_radar + parts) и возвращает словарь {id: interval_km}.
    Каталог НЕ меняется — только читается."""
    if not catalog_path:
        return {}
    intervals_path = get_intervals_path(catalog_path)

    if os.path.exists(intervals_path):
        try:
            with open(intervals_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return fix_keys(data)
        except (json.JSONDecodeError, OSError):
            pass

    # Файла нет или он битый — собираем дефолты из каталога
    defaults = {}
    for item in catalog.get("maintenance_radar", []):
        item_id = item.get("id")
        if item_id:
            defaults[item_id] = item.get("interval_km", 0)
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for item in subcat.get("items", []):
                item_id = item.get("id")
                if item_id and item_id not in defaults:
                    defaults[item_id] = item.get("interval_km", 0)

    try:
        os.makedirs(CATALOGS_DIR, exist_ok=True)
        with open(intervals_path, "w", encoding="utf-8") as f:
            json.dump(defaults, f, ensure_ascii=False, indent=2)
    except OSError:
        pass

    return defaults

def load_analogs_torque():
    path = get_analogs_path()
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return fix_keys(data)


def load_my_purchases():
    if not os.path.exists(MY_PURCHASES_PATH):
        return []
    try:
        with open(MY_PURCHASES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data.get("purchases", [])
        return []
    except (json.JSONDecodeError, OSError):
        return []


def save_my_purchases(purchases):
    try:
        os.makedirs(CATALOGS_DIR, exist_ok=True)
        with open(MY_PURCHASES_PATH, "w", encoding="utf-8") as f:
            json.dump({"purchases": purchases}, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def save_catalog(catalog):
    if os.path.exists(CATALOG_PATH):
        os.makedirs(BACKUP_DIR, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base = os.path.splitext(os.path.basename(CATALOG_PATH))[0]
        try:
            shutil.copy2(CATALOG_PATH, os.path.join(BACKUP_DIR, f"{base}_{stamp}.json"))
        except OSError:
            pass
    with open(CATALOG_PATH, "w", encoding="utf-8") as f:
        json.dump(catalog, f, ensure_ascii=False, indent=2)


def fix_keys(obj):
    if isinstance(obj, dict):
        return {k.strip(): fix_keys(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [fix_keys(item) for item in obj]
    elif isinstance(obj, str):
        return obj.strip()
    return obj

# === ТЕМА ===
def apply_theme(page, mode):
    CURRENT_THEME["mode"] = mode
    page.bgcolor = C("surface")
    if mode == "dark":
        page.theme_mode = ft.ThemeMode.DARK
    else:
        page.theme_mode = ft.ThemeMode.LIGHT
    page.update()


def get_theme(catalog):
    settings = catalog.get("settings", {})
    return settings.get("theme", "light")


def set_theme(catalog, mode):
    catalog.setdefault("settings", {})["theme"] = mode
    save_catalog(catalog)
    
# === ЭКСПОРТ В CSV ===
def export_to_csv(rows, filename, columns):
    """rows — список словарей, columns — список пар (ключ, заголовок)."""
    os.makedirs(EXPORTS_DIR, exist_ok=True)
    path = os.path.join(EXPORTS_DIR, filename)

    # Определяем заголовки: если ключа нет в первой строке, берём из columns
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow([title for _, title in columns])
        for row in rows:
            line = []
            for key, _ in columns:
                val = row.get(key, "")
                if isinstance(val, (dict, list)):
                    val = json.dumps(val, ensure_ascii=False)
                line.append(val)
            writer.writerow(line)
    return path


# === УТИЛИТЫ ===
def format_km(value):
    try:
        return f"{int(value):,}".replace(",", " ")
    except (ValueError, TypeError):
        return str(value)


def today_str():
    return datetime.now().strftime("%d.%m.%Y")


def parse_date(s):
    try:
        datetime.strptime(s.strip(), "%d.%m.%Y")
        return True
    except (ValueError, AttributeError):
        return False


def parse_int(s):
    try:
        return int(str(s).strip())
    except (ValueError, TypeError):
        return None


def parse_float(s):
    try:
        return float(str(s).strip().replace(",", "."))
    except (ValueError, TypeError):
        return None


# === РАСЧЁТ СОСТОЯНИЯ ТО ===
def calc_status(last_km, interval_km, current_km):
    if interval_km == 0:
        return C("text_muted"), "Не регламентировано", 0, "grey"
    passed = current_km - last_km
    remaining = interval_km - passed
    if remaining <= 0:
        return C("danger"), f"ПЕРЕРАСХОД {-remaining} км", remaining, "red"
    elif remaining < interval_km * 0.2:
        return C("warning_text"), f"Критично: {remaining} км", remaining, "orange"
    elif remaining < interval_km * 0.5:
        return C("warning_strong"), f"Планировать: {remaining} км", remaining, "yellow"
    else:
        return C("success"), f"Норма: {remaining} км", remaining, "green"


def get_status_key(last_km, interval_km, current_km, defect=None):
    if defect:
        return "red"
    if interval_km == 0 or last_km == 0:
        return "grey"
    passed = current_km - last_km
    remaining = interval_km - passed
    if remaining <= 0:
        return "red"
    elif remaining < interval_km * 0.2:
        return "orange"
    elif remaining < interval_km * 0.5:
        return "yellow"
    else:
        return "green"


def build_replace_info_lines(last_km, last_date, interval_km, current_km):
    line1 = "🛠 Нет данных о замене"
    line2 = "📏 —"
    if last_km and last_date:
        line1 = f"🛠 {last_date} · {format_km(last_km)} км"
    elif last_km:
        line1 = f"🛠 — · {format_km(last_km)} км"
    if interval_km > 0 and last_km > 0:
        passed = current_km - last_km
        remaining = interval_km - passed
        if remaining >= 0:
            line2 = f"📏 Отслужил: {format_km(passed)} км · Остаток: {format_km(remaining)} км"
        else:
            line2 = f"📏 Отслужил: {format_km(passed)} км · Перепробег: {format_km(-remaining)} км"
    elif last_km > 0:
        passed = current_km - last_km
        line2 = f"📏 Отслужил: {format_km(passed)} км"
    return line1, line2


# === ОПРЕДЕЛЕНИЕ ТИПА ЗАПИСИ ИСТОРИИ ===
def detect_history_type(entry):
    t = entry.get("type")
    if t == "work":
        return "replace", "🔵 Замена/Установка", C("accent_icon"), C("accent_soft")
    if t == "purchase":
        return "purchase", "🟣 Покупка", C("purchase_text"), C("purchase_bg")
    if t == "writeoff":
        return "writeoff", "🟠 Списание", C("writeoff_text"), C("writeoff_bg")
    if t == "fuel":
        return "fuel", "⛽ Бензин", C("fuel_text"), C("fuel_bg")
    if t == "to":
        return "to", "🟢 ТО", C("to_text"), C("to_bg")
    if t == "expense_service":
        return "expense_service", "💰 Сервис", C("service_text"), C("service_bg")
    if t == "expense_parts":
        return "expense_parts", "🧩 Запчасти", C("parts_text"), C("parts_bg")
    if t == "expense_other":
        return "expense_other", "📦 Прочее", C("other_text"), C("other_bg")
    if t == "defect":
        return "defect", "⚠ Дефект", C("defect_text"), C("defect_bg")
    if t == "defect_resolved":
        return "defect_resolved", "✔ Дефект снят", C("resolved_text"), C("resolved_bg")
    if t == "other":
        return "other", "⚪ Прочее", C("neutral_text"), C("neutral_bg")
    work = (entry.get("work") or "").lower()
    if "бензин" in work or "заправка" in work:
        return "fuel", "⛽ Бензин", C("fuel_text"), C("fuel_bg")
    if "куплено" in work or "покупка" in work:
        return "purchase", "🟣 Покупка", C("purchase_text"), C("purchase_bg")
    if "замена" in work or "установк" in work:
        return "replace", "🔵 Замена/Установка", C("accent_icon"), C("accent_soft")
    if "списан" in work or "списание" in work:
        return "writeoff", "🟠 Списание", C("writeoff_text"), C("writeoff_bg")
    if "то " in work or work.startswith("то") or "регламент" in work:
        return "to", "🟢 ТО", C("to_text"), C("to_bg")
    return "other", "⚪ Прочее", C("neutral_text"), C("neutral_bg")


# === ПОИСК ===
def find_item_by_id(catalog, item_id):
    for item in catalog.get("maintenance_radar", []):
        if item.get("id") == item_id:
            return item, catalog["maintenance_radar"]
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for item in subcat.get("items", []):
                if item.get("id") == item_id:
                    return item, subcat["items"]
    return None, None


def find_pair_item(catalog, item):
    pair_id = item.get("pair_id")
    if not pair_id:
        return None
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for it in subcat.get("items", []):
                if it.get("pair_id") == pair_id and it.get("id") != item.get("id"):
                    return it
    for it in catalog.get("maintenance_radar", []):
        if it.get("pair_id") == pair_id and it.get("id") != item.get("id"):
            return it
    return None

def find_linked_items(catalog, item):
    """Ищет ту же деталь в другом списке (радар ↔ запчасти) по названию."""
    name = (item.get("name") or "").strip().lower()
    if not name:
        return []
    result = []
    # Ищем в радаре
    for it in catalog.get("maintenance_radar", []):
        if it.get("id") == item.get("id"):
            continue
        if (it.get("name") or "").strip().lower() == name:
            result.append(it)
    # Ищем в запчастях
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for it in subcat.get("items", []):
                if it.get("id") == item.get("id"):
                    continue
                if (it.get("name") or "").strip().lower() == name:
                    result.append(it)
    return result
def get_all_parts(catalog):
    result = []
    for item in catalog.get("maintenance_radar", []):
        result.append({
            "id": item.get("id"),
            "name": item.get("name", ""),
            "vag": item.get("vag", "N/A"),
            "source": "radar",
            "item": item,
        })
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for item in subcat.get("items", []):
                result.append({
                    "id": item.get("id"),
                    "name": item.get("name", ""),
                    "vag": item.get("vag", "N/A"),
                    "source": "parts",
                    "item": item,
                })
    return result

def get_service_suggestions(catalog):
    """Собирает уникальные подсказки для поля «Сервис / кто делал»."""
    suggestions = set()
    for contact in catalog.get("contacts_log", []):
        name = (contact.get("name") or "").strip()
        if name:
            suggestions.add(name)
    for entry in catalog.get("history", []):
        svc = (entry.get("service") or "").strip()
        if svc:
            suggestions.add(svc)
    for entry in catalog.get("expenses_log", []):
        svc = (entry.get("service") or "").strip()
        if svc:
            suggestions.add(svc)
    for rec in catalog.get("defect_log", []):
        fb = (rec.get("found_by") or "").strip()
        if fb:
            suggestions.add(fb)
    return sorted(suggestions)


# === ДИАЛОГ: ЗАМЕНА ===
def open_replace_dialog(page, catalog, state, item, source, on_saved):
    current_km = state["current_km"]
    
    date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                            width=200, text_size=13)
    km_field = ft.TextField(label="Пробег, км", value=str(current_km),
                            width=200, text_size=13,
                            keyboard_type=ft.KeyboardType.NUMBER)
    service_field = ft.TextField(label="Сервис (кто делал)", width=410, text_size=13)
    article_field = ft.TextField(
        label="Артикул установленной (необязательно)",
        width=410,
        text_size=13,
        hint_text="Например: 03C115561H, MANN W 712/94...")
    note_field = ft.TextField(label="Заметка (что именно делали)", width=410, text_size=13,
                              hint_text="Например: сварка трещины, замена гофры...")
    related_field = ft.TextField(
        label="Сопутствующий ремонт (что ещё делали)",
        width=410, text_size=13,
        hint_text="Например: опоры, отбойники, пыльники — если меняли в комплекте")

    error_text = ft.Text("", color=C("danger"), size=12)

    pair_item = find_pair_item(catalog, item)
    pair_checkbox = None
    if pair_item:
        pair_checkbox = ft.Checkbox(
            label=f"Заменить обе стороны (и «{pair_item.get('name', '')}»)",
            value=False)

    last_km = item.get("last_km", 0)
    last_date = item.get("last_date", "")
    interval = item.get("interval_km", 0)
    line1, line2 = build_replace_info_lines(last_km, last_date, interval, current_km)

    summary = ft.Column([
        ft.Text(item.get("name", ""), size=14, weight=ft.FontWeight.BOLD),
        ft.Text(f"{get_article_prefix()}: {get_article_value(item)}", size=11, selectable=True,
                color=C("text_muted"), font_family="monospace"),
        ft.Text(line1, size=11, color=C("text_secondary")),
        ft.Text(line2, size=11, color=C("text_secondary")),
    ], spacing=4)

    def apply_replacement(target_item, d, k):
        old_last_km = target_item.get("last_km", 0)
        interval_local = target_item.get("interval_km", 0)
        early_mark = ""
        if interval_local > 0 and old_last_km > 0:
            passed = k - old_last_km
            if 0 <= passed < interval_local:
                early_mark = " (досрочная замена)"
        target_item["last_km"] = k
        target_item["last_date"] = d
        target_item.pop("defect", None)
        return early_mark

    def resolve_defects(item_id, d, k):
        for rec in catalog.get("defect_log", []):
            if rec.get("item_id") == item_id and rec.get("status") == "active":
                rec["status"] = "resolved"
                rec["resolved_date"] = d
                rec["resolved_km"] = k

    def on_confirm(_e):
        d = date_field.value.strip() if date_field.value else ""
        k = parse_int(km_field.value)
        if not parse_date(d):
            error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
            page.update()
            return
        if k is None or k < 0:
            error_text.value = "Пробег должен быть числом"
            page.update()
            return

        article_text = article_field.value.strip() if article_field.value else ""

        early_mark = apply_replacement(item, d, k)
        resolve_defects(item.get("id"), d, k)
        if article_text:
            item["installed_article"] = article_text
        work_names = [item.get("name", "")]

        if pair_checkbox is not None and pair_checkbox.value and pair_item is not None:
            apply_replacement(pair_item, d, k)
            resolve_defects(pair_item.get("id"), d, k)
            if article_text:
                pair_item["installed_article"] = article_text
            work_names.append(pair_item.get("name", ""))

        # Связка: обновляем ту же деталь в другом списке (радар ↔ запчасти)
        linked_items = find_linked_items(catalog, item)
        for linked in linked_items:
            apply_replacement(linked, d, k)
            resolve_defects(linked.get("id"), d, k)
            if article_text:
                linked["installed_article"] = article_text

        if len(work_names) == 1:
            work_text = f"Замена: {work_names[0]}{early_mark}"
        else:
            work_text = f"Замена: {work_names[0]} + {work_names[1]} (обе стороны){early_mark}"
        note_text = note_field.value.strip() if note_field.value else ""
        if note_text:
            work_text += f" — {note_text}"
        related_text = related_field.value.strip() if related_field.value else ""
        if related_text:
            work_text += f" [сопутствующий: {related_text}]"
        history_entry = {
            "date": d,
            "km": k,
            "type": "work",
            "service": service_field.value.strip() if service_field.value else "",
            "work": work_text,
            "parts": item.get("vag", "N/A"),
            "installed_article": article_text,
            "cost": 0,
        }
        catalog.setdefault("history", []).insert(0, history_entry)

        save_catalog(catalog)
        page.close(dialog)
        on_saved()

    def on_cancel(_e):
        page.close(dialog)

    dialog_content = [summary, ft.Divider(height=1, color=C("border")),
                      ft.Text("Внеси факт замены (поля можно править)", size=12,
                              color=C("text_muted")),
                      ft.Row([date_field, km_field], spacing=10),
                      service_field,
                      article_field,
                      note_field,
                      related_field]
    if pair_checkbox is not None:
        dialog_content.append(pair_checkbox)
    dialog_content.append(error_text)

    dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text(f"🔧 Замена: {item.get('name', '')}", size=16),
        content=ft.Container(
            content=ft.Column(dialog_content, spacing=10, tight=True, width=460),
            padding=ft.padding.only(top=10)),
        actions=[
            ft.TextButton("ОТМЕНА", on_click=on_cancel),
            ft.ElevatedButton("ЗАМЕНИТЬ", on_click=on_confirm,
                              bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
        ],
        actions_alignment=ft.MainAxisAlignment.END)
    page.open(dialog)


# === ДИАЛОГ: ДЕФЕКТ ВНЕ КАТАЛОГА (П.35) ===
def open_free_defect_dialog(page, catalog, state, on_saved):
    """Добавляет дефект вне каталога: создаёт запись в parts -> 10/00 -> 10.1,
    пишет в defect_log и history, сохраняет каталог."""
    current_km = state["current_km"]

    text_field = ft.TextField(label="Текст дефекта (обязательно)", width=460, text_size=13,
                              multiline=True, min_lines=2, max_lines=4,
                              hint_text="Например: стук в передней подвеске справа")
    found_by_field = ft.TextField(label="Кто обнаружил", width=460, text_size=13,
                                  hint_text="Сервис / мастер / сам")
    date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                              width=200, text_size=13)
    km_field = ft.TextField(label="Пробег, км", value=str(current_km),
                            width=200, text_size=13,
                            keyboard_type=ft.KeyboardType.NUMBER)
    note_field = ft.TextField(label="Заметка", width=460, text_size=13,
                              multiline=True, min_lines=2, max_lines=3,
                              hint_text="Например: проявляется на неровностях")

    error_text = ft.Text("", color=C("danger"), size=12)

    def on_confirm(_e):
        text = text_field.value.strip() if text_field.value else ""
        if not text:
            error_text.value = "Впиши текст дефекта"
            page.update()
            return
        d = date_field.value.strip() if date_field.value else ""
        if not parse_date(d):
            error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
            page.update()
            return
        k = parse_int(km_field.value)
        if k is None or k < 0:
            error_text.value = "Пробег должен быть числом"
            page.update()
            return
        found_by = found_by_field.value.strip() if found_by_field.value else ""
        note_text = note_field.value.strip() if note_field.value else ""

        # Находим (или создаём) категорию 10/00 и подкатегорию 10.1
        target_subcat = None
        for category in catalog.get("parts", []):
            if category.get("category_id") == "10/00":
                for subcat in category.get("subcategories", []):
                    if subcat.get("subcategory_id") == "10.1":
                        target_subcat = subcat
                        break
                break

        if target_subcat is None:
            new_category = {
                "category_id": "10/00",
                "category_name": "Прочие дефекты (вне каталога)",
                "subcategories": [
                    {
                        "subcategory_id": "10.1",
                        "subcategory_name": "Прочие дефекты",
                        "items": [],
                    }
                ],
            }
            catalog.setdefault("parts", []).append(new_category)
            target_subcat = new_category["subcategories"][0]

        item_id = f"free_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        defect_text = f"{found_by} ({d})" if found_by else f"Дефект ({d})"
        new_item = {
            "id": item_id,
            "name": text,
            "vag": "N/A",
            "interval_km": 0,
            "last_km": 0,
            "last_date": "",
            "analog_best": "N/A",
            "defect": defect_text,
        }
        if note_text:
            new_item["note"] = note_text
        target_subcat.setdefault("items", []).append(new_item)

        rec = {
            "id": f"def_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
            "item_id": item_id,
            "item_name": text,
            "date": d,
            "km": k,
            "found_by": found_by,
            "note": note_text,
            "related_note": "",
            "status": "active",
            "resolved_date": "",
            "resolved_km": 0,
        }
        catalog.setdefault("defect_log", []).insert(0, rec)

        history_entry = {
            "date": d, "km": k, "type": "defect",
            "service": found_by, "work": f"Дефект: {text}",
            "parts": "", "cost": 0,
        }
        catalog.setdefault("history", []).insert(0, history_entry)

        save_catalog(catalog)
        page.close(dialog)
        on_saved()

    def on_cancel(_e):
        page.close(dialog)

    dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("⚠ Новый дефект (вне каталога)", size=16),
        content=ft.Container(
            content=ft.Column([
                ft.Text("Дефект попадёт в категорию 10/00 «Прочие дефекты» и в журнал дефектов.",
                        size=11, color=C("text_muted"), italic=True),
                text_field,
                found_by_field,
                ft.Row([date_field, km_field], spacing=10),
                note_field,
                error_text,
            ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
            padding=ft.padding.only(top=10)),
        actions=[
            ft.TextButton("ОТМЕНА", on_click=on_cancel),
            ft.ElevatedButton("СОЗДАТЬ ДЕФЕКТ", on_click=on_confirm,
                              bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
        ],
        actions_alignment=ft.MainAxisAlignment.END)
    page.open(dialog)

# === ДИАЛОГ: ДЕФЕКТОВКА ===
def open_defect_dialog(page, catalog, state, item, source, on_saved):
    current_km = state["current_km"]

    date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                              width=200, text_size=13)
    km_field = ft.TextField(label="Пробег, км", value=str(current_km),
                            width=200, text_size=13,
                            keyboard_type=ft.KeyboardType.NUMBER)
    found_by_field = ft.TextField(label="Кто обнаружил", width=410, text_size=13,
                                  hint_text="Сервис / мастер / сам")
    note_field = ft.TextField(label="Заметка", width=410, text_size=13,
                              multiline=True, min_lines=2, max_lines=3,
                              hint_text="Например: стук при проезде неровностей")
    related_field = ft.TextField(
        label="Сопутствующий ремонт (что ещё нужно)",
        width=410, text_size=13,
        hint_text="Например: опоры, отбойники, пыльники — если меняешь в комплекте")

    error_text = ft.Text("", color=C("danger"), size=12)

    pair_item = find_pair_item(catalog, item)
    pair_checkbox = None
    if pair_item:
        pair_checkbox = ft.Checkbox(
            label=f"Пометить обе стороны (и «{pair_item.get('name', '')}»)",
            value=False)

    summary = ft.Column([
        ft.Text(item.get("name", ""), size=14, weight=ft.FontWeight.BOLD),
        ft.Text(f"{get_article_prefix()}: {get_article_value(item)}", size=11, selectable=True,
                color=C("text_muted"), font_family="monospace"),
    ], spacing=4)

    def make_defect_record(target_item, d, k, found_by, note_text, related_text=""):
        rec = {
            "id": f"def_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
            "item_id": target_item.get("id"),
            "item_name": target_item.get("name", ""),
            "date": d,
            "km": k,
            "found_by": found_by,
            "note": note_text,
            "related_note": related_text,
            "status": "active",
            "resolved_date": "",
            "resolved_km": 0,
        }
        catalog.setdefault("defect_log", []).insert(0, rec)
        defect_text = f"{found_by} ({d})" if found_by else f"Дефект ({d})"
        target_item["defect"] = defect_text
        return rec

    def on_confirm(_e):
        d = date_field.value.strip() if date_field.value else ""
        k = parse_int(km_field.value)
        if not parse_date(d):
            error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
            page.update()
            return
        if k is None or k < 0:
            error_text.value = "Пробег должен быть числом"
            page.update()
            return

        found_by = found_by_field.value.strip() if found_by_field.value else ""
        note_text = note_field.value.strip() if note_field.value else ""
        related_text = related_field.value.strip() if related_field.value else ""

        make_defect_record(item, d, k, found_by, note_text, related_text)
        names = [item.get("name", "")]

        if pair_checkbox is not None and pair_checkbox.value and pair_item is not None:
            make_defect_record(pair_item, d, k, found_by, note_text, related_text)
            names.append(pair_item.get("name", ""))

        # Связка: помечаем дефект в той же детали в другом списке (радар ↔ запчасти).
        # В names НЕ добавляем — это та же деталь, а не вторая сторона.
        linked_items = find_linked_items(catalog, item)
        for linked in linked_items:
            make_defect_record(linked, d, k, found_by, note_text, related_text)

        if len(names) == 1:
            work_text = f"Дефект: {names[0]}"
        else:
            work_text = f"Дефект: {names[0]} + {names[1]} (обе стороны)"
        if found_by:
            work_text += f" — {found_by}"
        if related_text:
            work_text += f" [сопутствующий: {related_text}]"

        history_entry = {
            "date": d, "km": k, "type": "defect",
            "service": found_by, "work": work_text,
            "parts": "", "cost": 0,
        }
        catalog.setdefault("history", []).insert(0, history_entry)

        save_catalog(catalog)
        page.close(dialog)
        on_saved()

    def on_cancel(_e):
        page.close(dialog)

    dialog_content = [
        summary,
        ft.Divider(height=1, color=C("border")),
        ft.Text("Отметь дефект (поля можно править)", size=12, color=C("text_muted")),
        ft.Row([date_field, km_field], spacing=10),
        found_by_field,
        note_field,
        related_field,
    ]
    if pair_checkbox is not None:
        dialog_content.append(pair_checkbox)
    dialog_content.append(error_text)

    dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text(f"⚠ Дефектовка: {item.get('name', '')}", size=16),
        content=ft.Container(
            content=ft.Column(dialog_content, spacing=10, tight=True, width=460),
            padding=ft.padding.only(top=10)),
        actions=[
            ft.TextButton("ОТМЕНА", on_click=on_cancel),
            ft.ElevatedButton("ПОМЕТИТЬ ДЕФЕКТ", on_click=on_confirm,
                              bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
        ],
        actions_alignment=ft.MainAxisAlignment.END)
    page.open(dialog)


# === ДИАЛОГ: СНЯТИЕ ДЕФЕКТА (НОВОЕ) ===
def open_resolve_defect_dialog(page, catalog, state, item, source, on_saved):
    current_km = state["current_km"]

    date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                              width=200, text_size=13)
    km_field = ft.TextField(label="Пробег, км", value=str(current_km),
                            width=200, text_size=13,
                            keyboard_type=ft.KeyboardType.NUMBER)

    error_text = ft.Text("", color=C("danger"), size=12)

    summary = ft.Column([
        ft.Text(item.get("name", ""), size=14, weight=ft.FontWeight.BOLD),
        ft.Text(f"{get_article_prefix()}: {get_article_value(item)}", size=11, selectable=True,
                color=C("text_muted"), font_family="monospace"),
        ft.Text("Дефект выставлен ошибочно?", size=12,
                color=C("text_muted"), italic=True),
    ], spacing=4)

    def on_confirm(_e):
        d = date_field.value.strip() if date_field.value else ""
        k = parse_int(km_field.value)
        if not parse_date(d):
            error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
            page.update()
            return
        if k is None or k < 0:
            error_text.value = "Пробег должен быть числом"
            page.update()
            return

        item_id = item.get("id")
        item_name = item.get("name", "")

        if item_id and item_id.startswith("free_"):
            # «Прочий дефект» (вне каталога): удаляем полностью —
            # и запись из журнала, и саму запчасть из категории 10/00
            catalog["defect_log"] = [
                r for r in catalog.get("defect_log", [])
                if r.get("item_id") != item_id
            ]
            found_item, found_lst = find_item_by_id(catalog, item_id)
            if found_item is not None and found_lst is not None:
                try:
                    found_lst.remove(found_item)
                except ValueError:
                    pass
        else:
            # Обычная запчасть: только помечаем дефект устранённым
            for rec in catalog.get("defect_log", []):
                if rec.get("item_id") == item_id and rec.get("status") == "active":
                    rec["status"] = "resolved"
                    rec["resolved_date"] = d
                    rec["resolved_km"] = k
                    rec["resolved_note"] = "Снят — выставлен ошибочно"
            item.pop("defect", None)

            # Связка: снимаем дефект в другом списке (радар ↔ запчасти)
            linked_items = find_linked_items(catalog, item)
            for linked in linked_items:
                linked_id = linked.get("id")
                for rec in catalog.get("defect_log", []):
                    if rec.get("item_id") == linked_id and rec.get("status") == "active":
                        rec["status"] = "resolved"
                        rec["resolved_date"] = d
                        rec["resolved_km"] = k
                        rec["resolved_note"] = "Снят — выставлен ошибочно"
                linked.pop("defect", None)

        history_entry = {
            "date": d, "km": k, "type": "defect_resolved",
            "service": "", "work": f"Дефект снят: {item.get('name', '')}",
            "parts": "", "cost": 0,
        }
        catalog.setdefault("history", []).insert(0, history_entry)

        save_catalog(catalog)
        page.close(dialog)
        on_saved()

    def on_cancel(_e):
        page.close(dialog)

    dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text(f"✔ Снять дефект: {item.get('name', '')}", size=16),
        content=ft.Container(
            content=ft.Column([summary,
                               ft.Divider(height=1, color=C("border")),
                               ft.Text("Укажи дату и пробег снятия", size=12,
                                       color=C("text_muted")),
                               ft.Row([date_field, km_field], spacing=10),
                               error_text], spacing=10, tight=True, width=460),
            padding=ft.padding.only(top=10)),
        actions=[
            ft.TextButton("ОТМЕНА", on_click=on_cancel),
            ft.ElevatedButton("СНЯТЬ ДЕФЕКТ", on_click=on_confirm,
                              bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
        ],
        actions_alignment=ft.MainAxisAlignment.END)
    page.open(dialog)
    # === СПРАВОЧНАЯ ТАБЛИЦА ===
COL_CODE_W = 55
COL_TITLE_W = 160
COL_CONTENT_W = 380


def build_reference_table(reference_blocks):
    header = ft.Container(
        content=ft.Row([
            ft.Text("Код", size=12, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE, width=COL_CODE_W),
            ft.Text("Наименование", size=12, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE, width=COL_TITLE_W),
            ft.Text("Содержание", size=12, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE, width=COL_CONTENT_W),
        ], spacing=0),
        padding=ft.padding.symmetric(horizontal=10, vertical=8),
        bgcolor=ft.Colors.BLUE_900,
        border_radius=ft.border_radius.only(top_left=6, top_right=6))
    rows = [header]
    for idx, block in enumerate(reference_blocks):
        content_column = ft.Column(
            [ft.Text(f"• {line}", size=11, color=C("text")) for line in block.get("content", [])],
            spacing=2)
        row_bg = C("card") if idx % 2 == 0 else C("surface")
        row = ft.Container(
            content=ft.Row([
                ft.Text(block.get("code", ""), size=11, weight=ft.FontWeight.BOLD,
                        color=C("accent"), font_family="monospace", width=COL_CODE_W),
                ft.Text(block.get("title", ""), size=11, weight=ft.FontWeight.W_500,
                        color=C("text"), width=COL_TITLE_W),
                ft.Container(content=content_column, width=COL_CONTENT_W),
            ], spacing=0, vertical_alignment=ft.CrossAxisAlignment.START),
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
            bgcolor=row_bg,
            border=ft.border.only(bottom=ft.BorderSide(1, C("border_light"))))
        rows.append(row)
    table_width = COL_CODE_W + COL_TITLE_W + COL_CONTENT_W + 20
    return ft.Column(
        [
            ft.Row(
                [ft.Container(content=ft.Column(rows, spacing=0), width=table_width)],
                scroll=ft.ScrollMode.AUTO,
            )
        ],
        scroll=ft.ScrollMode.AUTO,
        expand=True,
    )


# === ВКЛАДКА: РАДАР ТО ===
def build_radar_tab(catalog, state, page, on_saved):
    current_km = state["current_km"]
    radar = catalog.get("maintenance_radar", [])
    reference_blocks = catalog.get("reference_blocks", [])

    tree_column = ft.Column(spacing=4, scroll=ft.ScrollMode.AUTO, expand=True)

    groups = {}
    for item in radar:
        req_opt = item.get("requires_option")
        if req_opt and req_opt not in (catalog.get("car", {}).get("options", []) or []):
            continue
        gid = item.get("group", "misc")
        gname = item.get("group_name", "📦 Прочее")
        if gid not in groups:
            groups[gid] = {"name": gname, "items": [], "expanded": False}
        groups[gid]["items"].append(item)

    def render_tree():
        tree_column.controls.clear()
        for gid, gdata in groups.items():
            red_count = orange_count = yellow_count = 0
            for item in gdata["items"]:
                key = get_status_key(item.get("last_km", 0), item.get("interval_km", 0),
                                     current_km, item.get("defect"))
                if key == "red":
                    red_count += 1
                elif key == "orange":
                    orange_count += 1
                elif key == "yellow":
                    yellow_count += 1
            summary = ft.Row([], spacing=6)
            if red_count > 0:
                summary.controls.append(ft.Text(f"🔴 {red_count}", size=12, weight=ft.FontWeight.BOLD))
            if orange_count > 0:
                summary.controls.append(ft.Text(f"🟠 {orange_count}", size=12, weight=ft.FontWeight.BOLD))
            if yellow_count > 0:
                summary.controls.append(ft.Text(f"🟡 {yellow_count}", size=12, weight=ft.FontWeight.BOLD))

            def make_group_toggle(g=gid):
                def handler(_e):
                    groups[g]["expanded"] = not groups[g]["expanded"]
                    render_tree()
                    page.update()
                return handler

            group_header = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.EXPAND_MORE if gdata["expanded"] else ft.Icons.CHEVRON_RIGHT,
                            size=20, color=C("accent")),
                    ft.Text(gdata["name"], size=14, weight=ft.FontWeight.BOLD,
                            color=C("accent"), expand=True),
                    summary,
                ], spacing=6),
                padding=8, bgcolor=C("accent_soft"), border_radius=8,
                on_click=make_group_toggle(gid), ink=True,
                margin=ft.margin.only(bottom=4))
            tree_column.controls.append(group_header)

            if gdata["expanded"]:
                for item in gdata["items"]:
                    color, status_text, _remaining, color_key = calc_status(
                        item.get("last_km", 0), item.get("interval_km", 0), current_km)
                    if item.get("defect"):
                        color = C("danger")
                        color_key = "red"
                    last_km = item.get("last_km", 0)
                    last_date = item.get("last_date", "")
                    interval = item.get("interval_km", 0)
                    vag = get_article_value(item)
                    analog = item.get("analog_best", "N/A")
                    if color_key == "red":
                        icon_name = ft.Icons.ERROR
                    elif color_key == "orange":
                        icon_name = ft.Icons.WARNING_AMBER
                    elif color_key == "yellow":
                        icon_name = ft.Icons.WARNING
                    elif color_key == "green":
                        icon_name = ft.Icons.CHECK_CIRCLE
                    else:
                        icon_name = ft.Icons.HELP_OUTLINE
                    line1, line2 = build_replace_info_lines(last_km, last_date, interval, current_km)
                    if item.get("defect"):
                        status_line = f"⚠ {item['defect']}"
                        status_color = C("danger")
                    elif interval == 0 or last_km == 0:
                        status_line = "⚪ Нет данных / Не регламентировано"
                        status_color = C("text_soft")
                    else:
                        status_line = status_text
                        status_color = color

                    def make_click(it=item):
                        def handler(_e):
                            open_replace_dialog(page, catalog, state, it, "radar", on_saved)
                        return handler

                    def make_defect(it=item):
                        def handler(_e):
                            open_defect_dialog(page, catalog, state, it, "radar", on_saved)
                        return handler

                    def make_resolve(it=item):
                        def handler(_e):
                            open_resolve_defect_dialog(page, catalog, state, it, "radar", on_saved)
                        return handler

                    has_defect = bool(item.get("defect"))
                    is_free_item = str(item.get("id", "")).startswith("free_")
                    if is_free_item:
                        defect_btn_text = "🗑 УДАЛИТЬ ДЕФЕКТ"
                        def make_delete_free(it=item):
                            def handler(_e):
                                delete_free_defect_item(catalog, it.get("id"))
                                save_catalog(catalog)
                                on_saved()
                            return handler
                        defect_btn_handler = make_delete_free(item)
                    else:
                        defect_btn_text = "✔ СНЯТЬ ДЕФЕКТ" if has_defect else "⚠ ДЕФЕКТОВКА"
                        defect_btn_handler = make_resolve(item) if has_defect else make_defect(item)

                    item_card = ft.Container(
                        content=ft.Row([
                            ft.Icon(icon_name, color=color, size=20),
                            ft.Column([
                                ft.Text(item.get("name", ""), size=13,
                                        weight=ft.FontWeight.BOLD, color=C("text")),
                                ft.Text(f"{get_article_prefix()}: {vag} · Аналог: {analog}", size=11, selectable=True,
                                        color=C("text_muted"), font_family="monospace"),
                                ft.Text(
                                    f"🔧 Установлено сейчас: {item.get('installed_article') or '—'}",
                                    size=11,
                                    color=C("success_strong") if item.get("installed_article") else C("text_muted"),
                                    weight=ft.FontWeight.BOLD if item.get("installed_article") else None),
                                ft.Text(line1, size=11, color=C("text_secondary")),
                                ft.Text(line2, size=11, color=C("text_secondary")),
                                ft.Text(status_line, size=11, color=status_color,
                                        weight=ft.FontWeight.BOLD),
                                ft.Row([
                                    ft.Container(expand=True),
                                    ft.TextButton(defect_btn_text,
                                                  icon=ft.Icons.WARNING_AMBER,
                                                  on_click=defect_btn_handler),
                                ]),
                            ], spacing=2, expand=True),
                        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                        padding=10, bgcolor=C(status_bg_key(color_key)),
                        border=ft.border.all(1, C("border")), border_radius=8,
                        margin=ft.margin.only(left=20, bottom=4),
                        on_click=None if is_free_item else make_click(item), ink=True)
                    tree_column.controls.append(item_card)

    render_tree()

    left_panel = ft.Container(
        content=ft.Column([
            ft.Text("🌳 ДЕРЕВО РЕГЛАМЕНТА", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
            ft.Divider(height=1, color=C("border")),
            tree_column,
        ], spacing=8, expand=True),
        col={"xs": 12, "md": 5},
        padding=10, bgcolor=C("surface"), border_radius=8)

    if reference_blocks:
        _ref_content = build_reference_table(reference_blocks)
    else:
        _ref_content = ft.Container(
            content=ft.Column([
                ft.Icon(ft.Icons.MENU_BOOK, size=48, color=C("text_disabled")),
                ft.Text("Справочные данные для этой машины ещё не заполнены.",
                        size=13, color=C("text_soft"), italic=True),
                ft.Text("Блок reference_blocks в JSON машины пуст.",
                        size=11, color=C("text_disabled"), italic=True),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=6),
            padding=40, alignment=ft.alignment.center)

    right_panel = ft.Container(
        content=ft.Column([
            ft.Text(get_reference_title(), size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
            ft.Divider(height=1, color=C("border")),
            _ref_content,
        ], spacing=8, expand=True),
        col={"xs": 12, "md": 7},
        padding=10, bgcolor=C("card"), border_radius=8)

    return ft.ResponsiveRow([left_panel, right_panel], spacing=10, run_spacing=10,
                            expand=True,
                            vertical_alignment=ft.CrossAxisAlignment.STRETCH)

def delete_free_defect_item(catalog, item_id):
    """Удаляет «прочий дефект» (id free_...) из каталога и все записи журнала с этим item_id."""
    catalog["defect_log"] = [
        r for r in catalog.get("defect_log", [])
        if r.get("item_id") != item_id
    ]
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            items = subcat.get("items", [])
            for i, it in enumerate(items):
                if it.get("id") == item_id:
                    del items[i]
                    return True
    return False


# === ВКЛАДКА: ЗАПЧАСТИ ===
def build_parts_tab(catalog, state, page, on_saved):
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}
    current_km = state["current_km"]
    state["expanded_cats"] = set()

    def apply_filters():
        content_column.controls.clear()
        search_text = search_field.value.lower().strip() if search_field.value else ""

        for category in catalog.get("parts", []):
            cat_id = category.get("category_id", "")
            cat_name = category.get("category_name", "")
            cat_red = cat_orange = cat_yellow = cat_green = cat_grey = 0
            visible_subcats = []

            for subcat in category.get("subcategories", []):
                req_opt = subcat.get("requires_option")
                car_options = catalog.get("car", {}).get("options", []) or []
                if req_opt and req_opt not in car_options:
                    continue
                visible_items = []
                for item in subcat.get("items", []):
                    defect = item.get("defect", "")
                    last_km = item.get("last_km", 0)
                    last_date = item.get("last_date", "")
                    interval = item.get("interval_km", 0)
                    vag = get_article_value(item)
                    analog = item.get("analog_best", "N/A")
                    color_key = get_status_key(last_km, interval, current_km, defect)
                    if color_key == "red":
                        cat_red += 1
                    elif color_key == "orange":
                        cat_orange += 1
                    elif color_key == "yellow":
                        cat_yellow += 1
                    elif color_key == "green":
                        cat_green += 1
                    else:
                        cat_grey += 1

                    if filter_state["active"] != "all" and filter_state["active"] != color_key:
                        continue
                    if search_text:
                        name = item.get("name", "").lower()
                        vag_l = vag.lower()
                        if search_text not in name and search_text not in vag_l:
                            continue

                    color_map = {"red": C("danger"), "orange": C("warning_text"),
                                 "yellow": C("warning_strong"), "green": C("success"),
                                 "grey": C("text_muted")}
                    bg_color_map = {"red": C("defect_bg"), "orange": C("writeoff_bg"),
                                    "yellow": C("status_yellow_bg"), "green": C("resolved_bg"),
                                    "grey": C("neutral_bg")}
                    if color_key == "red":
                        icon_name = ft.Icons.ERROR
                    elif color_key == "orange":
                        icon_name = ft.Icons.WARNING_AMBER
                    elif color_key == "yellow":
                        icon_name = ft.Icons.WARNING
                    elif color_key == "green":
                        icon_name = ft.Icons.CHECK_CIRCLE
                    else:
                        icon_name = ft.Icons.HELP_OUTLINE

                    if defect:
                        status_line = f"⚠ {defect}"
                    elif interval == 0 or last_km == 0:
                        status_line = "⚪ Нет данных / Не регламентировано"
                    else:
                        _, status_text, _, _ = calc_status(last_km, interval, current_km)
                        status_line = status_text

                    line1, line2 = build_replace_info_lines(last_km, last_date, interval, current_km)

                    def make_click(it=item):
                        def handler(_e):
                            open_replace_dialog(page, catalog, state, it, "parts", on_saved)
                        return handler

                    def make_defect(it=item):
                        def handler(_e):
                            open_defect_dialog(page, catalog, state, it, "parts", on_saved)
                        return handler

                    def make_resolve(it=item):
                        def handler(_e):
                            open_resolve_defect_dialog(page, catalog, state, it, "parts", on_saved)
                        return handler

                    has_defect = bool(item.get("defect"))
                    defect_btn_text = "✔ СНЯТЬ ДЕФЕКТ" if has_defect else "⚠ ДЕФЕКТОВКА"
                    defect_btn_handler = make_resolve(item) if has_defect else make_defect(item)

                    item_card = ft.Container(
                        content=ft.Row([
                            ft.Icon(icon_name, color=color_map.get(color_key, C("text_muted")), size=20),
                            ft.Column([
                                ft.Text(item.get("name", ""), weight=ft.FontWeight.BOLD, size=13, color=C("text")),
                                ft.Text(f"{get_article_prefix()}: {vag} · Аналог: {analog}", size=11, selectable=True,
                                        color=C("text_muted"), font_family="monospace"),
                                ft.Text(
                                    f"🔧 Установлено сейчас: {item.get('installed_article') or '—'}",
                                    size=11,
                                    color=C("success_strong") if item.get("installed_article") else C("text_muted"),
                                    weight=ft.FontWeight.BOLD if item.get("installed_article") else None),
                                ft.Text(line1, size=11, color=C("text_secondary")),
                                ft.Text(line2, size=11, color=C("text_secondary")),
                                ft.Text(status_line, size=11,
                                        color=color_map.get(color_key, C("text_muted")),
                                        weight=ft.FontWeight.BOLD),
                                ft.Row([
                                    ft.Container(expand=True),
                                    ft.TextButton(defect_btn_text,
                                                  icon=ft.Icons.WARNING_AMBER,
                                                  on_click=defect_btn_handler),
                                ]),
                            ], spacing=2, expand=True),
                        ], alignment=ft.MainAxisAlignment.START,
                           vertical_alignment=ft.CrossAxisAlignment.START),
                        padding=ft.padding.only(left=10, right=10, top=8, bottom=8),
                        bgcolor=C(status_bg_key(color_key)),
                        border_radius=6, margin=ft.margin.only(left=20, bottom=4),
                        on_click=make_click(item), ink=True)
                    visible_items.append(item_card)

                if visible_items:
                    subcat_header = ft.Container(
                        content=ft.Row([
                            ft.Icon(ft.Icons.FOLDER_OUTLINED, size=16, color=C("accent_icon")),
                            ft.Text(f"{subcat.get('subcategory_id', '')} {subcat.get('subcategory_name', '')}",
                                    weight=ft.FontWeight.W_500, size=12, color=C("accent")),
                        ], alignment=ft.MainAxisAlignment.START),
                        padding=ft.padding.only(left=10, top=6, bottom=2))
                    visible_subcats.append(subcat_header)
                    visible_subcats.extend(visible_items)

            if visible_subcats:
                cat_expanded = state.get("expanded_cats", set())
                is_expanded = cat_id in cat_expanded

                def make_toggle(cid=cat_id):
                    def toggle_handler(_e):
                        if "expanded_cats" not in state:
                            state["expanded_cats"] = set()
                        if cid in state["expanded_cats"]:
                            state["expanded_cats"].remove(cid)
                        else:
                            state["expanded_cats"].add(cid)
                        apply_filters()
                    return toggle_handler

                cat_summary = ft.Row([], spacing=6)
                if cat_red > 0:
                    cat_summary.controls.append(ft.Container(
                        content=ft.Text(f"🔴 {cat_red}", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                        bgcolor=ft.Colors.RED, border_radius=10,
                        padding=ft.padding.symmetric(horizontal=6, vertical=2)))
                if cat_orange > 0:
                    cat_summary.controls.append(ft.Container(
                        content=ft.Text(f"🟠 {cat_orange}", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                        bgcolor=ft.Colors.ORANGE, border_radius=10,
                        padding=ft.padding.symmetric(horizontal=6, vertical=2)))
                if cat_yellow > 0:
                    cat_summary.controls.append(ft.Container(
                        content=ft.Text(f"🟡 {cat_yellow}", size=11, weight=ft.FontWeight.BOLD, color=C("text")),
                        bgcolor=ft.Colors.YELLOW, border_radius=10,
                        padding=ft.padding.symmetric(horizontal=6, vertical=2)))
                if cat_green > 0 and cat_red == 0 and cat_orange == 0 and cat_yellow == 0:
                    cat_summary.controls.append(ft.Container(
                        content=ft.Text(f"🟢 {cat_green}", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
                        bgcolor=ft.Colors.GREEN, border_radius=10,
                        padding=ft.padding.symmetric(horizontal=6, vertical=2)))

                cat_header = ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.EXPAND_MORE if is_expanded else ft.Icons.CHEVRON_RIGHT,
                                size=20, color=C("accent")),
                        ft.Text(f"{cat_id} {cat_name}", weight=ft.FontWeight.BOLD,
                                size=14, color=C("accent"), expand=True),
                        cat_summary,
                    ], alignment=ft.MainAxisAlignment.START),
                    padding=10, bgcolor=C("accent_soft"), border_radius=8,
                    on_click=make_toggle(cat_id), ink=True,
                    margin=ft.margin.only(bottom=4))

                content_column.controls.append(cat_header)
                if is_expanded:
                    content_column.controls.extend(visible_subcats)

        if not content_column.controls:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SEARCH_OFF, size=48, color=C("text_disabled")),
                        ft.Text("Ничего не найдено", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        page.update()
        
    search_field = ft.TextField(
        hint_text="Поиск по названию или VAG-номеру...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: apply_filters())
    add_free_defect_btn = ft.ElevatedButton("+ ПРОЧИЙ ДЕФЕКТ", icon=ft.Icons.ADD, bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE, on_click=lambda _e: open_free_defect_dialog(page, catalog, state, on_saved))

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            apply_filters()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=175,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("🔴 Дефект/Перерасход", C("danger"), "red"),
        make_filter_btn("🟠 Критично", C("warning_text"), "orange"),
        make_filter_btn("🟡 Планировать", C("warning_strong"), "yellow"),
        make_filter_btn("🟢 Норма", C("success"), "green"),
        make_filter_btn("⚪ Нет данных", C("text_muted"), "grey"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)
    apply_filters()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                filters_row,
                ft.Row([search_field, add_free_defect_btn], spacing=10),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)

    
# === ВКЛАДКА: ЖУРНАЛ ДЕФЕКТОВ ===
def build_defect_log_tab(catalog, state, page):
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}
    
    def open_edit_defect_dialog(rec):
        note_field = ft.TextField(label="Заметка", width=440, text_size=13,
                                  multiline=True, min_lines=2, max_lines=4,
                                  value=rec.get("note", ""))
        found_by_field = ft.TextField(label="Кто обнаружил", width=440, text_size=13,
                                      value=rec.get("found_by", ""))
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", width=200, text_size=13,
                                  value=rec.get("date", ""))
        km_field = ft.TextField(label="Пробег, км", width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER,
                                value=str(rec.get("km", 0)))
        error_text = ft.Text("", color=C("danger"), size=12)

        summary = ft.Column([
            ft.Text(rec.get("item_name", "—"), size=14, weight=ft.FontWeight.BOLD),
            ft.Text("Название запчасти не меняется", size=11,
                    color=C("text_muted"), italic=True),
        ], spacing=2)

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            rec["note"] = note_field.value.strip() if note_field.value else ""
            rec["found_by"] = found_by_field.value.strip() if found_by_field.value else ""
            rec["date"] = d
            rec["km"] = k

            # Синхронизация с запчастью в каталоге:
            # обновляем отметку «defect» (кто нашёл + дата), а для «прочих
            # дефектов» (free_...) ещё и заметку.
            item_id = rec.get("item_id")
            if item_id:
                found_item, _lst = find_item_by_id(catalog, item_id)
                if found_item is not None:
                    if rec["found_by"]:
                        found_item["defect"] = f"{rec['found_by']} ({d})"
                    else:
                        found_item["defect"] = f"Дефект ({d})"
                    if item_id.startswith("free_"):
                        if rec["note"]:
                            found_item["note"] = rec["note"]
                        else:
                            found_item.pop("note", None)

            save_catalog(catalog)
            page.close(dialog)
            apply_filters()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать дефект", size=16),
            content=ft.Container(
                content=ft.Column([
                    summary,
                    ft.Divider(height=1, color=C("border")),
                    note_field,
                    found_by_field,
                    ft.Row([date_field, km_field], spacing=10),
                    error_text,
                ], spacing=10, tight=True, width=460, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_defect_dialog(rec):
        item_name = rec.get("item_name", "")
        item_id = rec.get("item_id", "")

        def on_confirm(_e):
            if item_id:
                it, lst = find_item_by_id(catalog, item_id)
                if it is not None:
                    it.pop("defect", None)
                    if item_id.startswith("free_") and lst is not None:
                        try:
                            lst.remove(it)
                        except ValueError:
                            pass
            catalog["defect_log"] = [
                r for r in catalog.get("defect_log", [])
                if r is not rec
            ]
            save_catalog(catalog)
            page.close(dialog)
            apply_filters()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить запись из журнала?", size=16),
            content=ft.Column([
                ft.Text(f"«{item_name}» от {rec.get('date', '')} "
                        f"будет удалена из журнала.", size=13),
                ft.Text("Отметка дефекта на запчасти тоже снимется "
                        "(если запчасть есть в каталоге).",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def apply_filters():
        content_column.controls.clear()
        search_text = search_field.value.lower().strip() if search_field.value else ""
        log = catalog.get("defect_log", [])
        shown = 0
        for rec in log:
            status = rec.get("status", "active")
            if filter_state["active"] != "all" and filter_state["active"] != status:
                continue
            if search_text:
                item_name = (rec.get("item_name") or "").lower()
                note = (rec.get("note") or "").lower()
                found_by = (rec.get("found_by") or "").lower()
                if (search_text not in item_name and search_text not in note
                        and search_text not in found_by):
                    continue
            shown += 1
            is_active = status == "active"
            color = C("danger") if is_active else C("success")
            bg = C("defect_bg") if is_active else C("resolved_bg")
            status_label = "🔴 АКТИВЕН" if is_active else "🟢 УСТРАНЁН"

            left_bar = ft.Container(width=4, bgcolor=color, border_radius=2)
            info_col = ft.Column([
                ft.Row([
                    ft.Text(rec.get("item_name", "—"), size=13, weight=ft.FontWeight.BOLD,
                            color=C("text"), expand=True),
                    ft.Text(status_label, size=11, weight=ft.FontWeight.BOLD, color=color),
                ], spacing=6),
                ft.Text(f"📅 {rec.get('date', '—')} · {format_km(rec.get('km', 0))} км",
                        size=11, color=C("text_secondary")),
                ft.Text(f"🔍 Обнаружил: {rec.get('found_by', '—') or '—'}",
                        size=11, color=C("text_secondary")),
            ], spacing=2)
            if rec.get("note"):
                info_col.controls.append(
                    ft.Text(f"💬 {rec['note']}", size=11, color=C("text_muted")))
            if rec.get("related_note"):
                info_col.controls.append(
                    ft.Text(f"🔗 Сопутствующий: {rec['related_note']}",
                            size=11, color=C("accent_icon"), weight=ft.FontWeight.BOLD))
            if not is_active:
                info_col.controls.append(
                    ft.Text(f"✔ Устранён: {rec.get('resolved_date', '—')} · "
                            f"{format_km(rec.get('resolved_km', 0))} км",
                            size=11, color=C("success_strong")))

            def make_edit_def(record=rec):
                def handler(_e):
                    open_edit_defect_dialog(record)
                return handler

            def make_delete_def(record=rec):
                def handler(_e):
                    open_delete_defect_dialog(record)
                return handler

            info_col.controls.append(
                ft.Row([
                    ft.Container(expand=True),
                    ft.IconButton(ft.Icons.EDIT, icon_size=18,
                                  icon_color=C("accent_icon"),
                                  tooltip="Редактировать",
                                  on_click=make_edit_def(rec)),
                    ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                                  icon_color=C("danger_icon"),
                                  tooltip="Удалить",
                                  on_click=make_delete_def(rec)),
                ], spacing=4))

            card = ft.Container(
                content=ft.Row([left_bar,
                                ft.Column([info_col], spacing=2, expand=True)],
                               spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=bg,
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)

        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.VERIFIED, size=48, color=C("text_disabled")),
                        ft.Text("Дефектов нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        page.update()

    search_field = ft.TextField(
        hint_text="Поиск по детали, заметке, кто нашёл...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: apply_filters())

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            apply_filters()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=135,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("🔴 Активные", C("danger"), "active"),
        make_filter_btn("🟢 Устранённые", C("success"), "resolved"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)
    header_info = ft.Text(f"Всего записей: {len(catalog.get('defect_log', []))}",
                          size=12, color=C("text_muted"))
    apply_filters()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Row([ft.Text("🔴 ЖУРНАЛ ДЕФЕКТОВ", size=16,
                                weight=ft.FontWeight.BOLD, color=C("accent")),
                        ft.Container(expand=True), header_info]),
                ft.Divider(height=1, color=C("border")),
                filters_row,
                search_field,
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)


# === ВКЛАДКА: РАСХОДЫ ===
def build_expenses_tab(catalog, state, page, on_saved):
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}

    def add_expense(exp_type, name, qty, price, total, service_or_place, d, k):
        entry = {
            "id": f"exp_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
            "date": d, "km": k if exp_type == "service" else 0,
            "expense_type": exp_type,
            "name": name, "qty": qty, "price": price, "total": total,
            "service": service_or_place,
        }
        catalog.setdefault("expenses_log", []).insert(0, entry)

        if exp_type == "service":
            work_text = f"Сервис: {name}"
            history_type = "expense_service"
            history_km = k
        elif exp_type == "parts":
            work_text = f"Запчасти: {name} × {qty} = {total} ₽"
            history_type = "expense_parts"
            history_km = 0
        else:
            work_text = f"Прочее: {name} × {qty} = {total} ₽"
            history_type = "expense_other"
            history_km = 0

        history_entry = {
            "date": d, "km": history_km, "type": history_type,
            "service": service_or_place, "work": work_text,
            "parts": "", "cost": int(total),
        }
        catalog.setdefault("history", []).insert(0, history_entry)
        save_catalog(catalog)

    def open_add_dialog(exp_type, title):
        is_service = (exp_type == "service")

        name_field = ft.TextField(label="Наименование", width=460, text_size=13)
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(state["current_km"]),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        qty_field = ft.TextField(label="Количество", value="1", width=140,
                                 text_size=13, keyboard_type=ft.KeyboardType.NUMBER)
        price_field = ft.TextField(label="Цена, ₽", width=200, text_size=13,
                                   keyboard_type=ft.KeyboardType.NUMBER)

        if is_service:
            place_field = ft.TextField(label="Сервис (кто делал)", width=460, text_size=13,
                                       hint_text="Гараж / AMD-MASTER / сам...")
        else:
            place_field = ft.TextField(label="Где приобрёл", width=460, text_size=13,
                                       hint_text="Магазин / рынок / у кого купил...")

        total_text = ft.Text("Сумма: 0 ₽", size=14, weight=ft.FontWeight.BOLD,
                             color=C("accent"))
        error_text = ft.Text("", color=C("danger"), size=12)

        if is_service:
            qty_field.value = "1"
            qty_field.disabled = True

        def recalc(_e=None):
            q = parse_float(qty_field.value) or 0
            p = parse_float(price_field.value) or 0
            total_text.value = f"Сумма: {q * p:.2f} ₽"
            page.update()

        qty_field.on_change = recalc
        price_field.on_change = recalc

        def on_save(_e):
            name = name_field.value.strip() if name_field.value else ""
            if not name:
                error_text.value = "Впиши наименование"
                page.update()
                return
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = 0
            if is_service:
                k = parse_int(km_field.value)
                if k is None or k < 0:
                    error_text.value = "Пробег должен быть числом"
                    page.update()
                    return
            qty = parse_float(qty_field.value) if not is_service else 1
            price = parse_float(price_field.value)
            if price is None or price < 0:
                error_text.value = "Цена должна быть числом ≥ 0"
                page.update()
                return
            if not is_service and (qty is None or qty < 1):
                error_text.value = "Количество должно быть числом ≥ 1"
                page.update()
                return
            total = qty * price
            place = place_field.value.strip() if place_field.value else ""
            add_expense(exp_type, name, qty, price, total, place, d, k)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        content_col = [name_field, ft.Row([date_field], spacing=10)]
        if is_service:
            content_col.append(ft.Row([km_field], spacing=10))
        if not is_service:
            content_col.append(ft.Row([qty_field, price_field], spacing=10))
        else:
            content_col.append(price_field)
        content_col.extend([place_field, total_text, error_text])

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title, size=16),
            content=ft.Container(
                content=ft.Column(content_col, spacing=10, tight=True, width=480,
                                  scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)
    def open_edit_expense_dialog(entry):
        """Редактирование существующего расхода. Тип не меняем."""
        exp_type = entry.get("expense_type", "other")
        is_service = (exp_type == "service")

        name_field = ft.TextField(label="Наименование", width=460, text_size=13,
                                  value=entry.get("name", ""))
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=entry.get("date", today_str()),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(entry.get("km", 0)),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        qty_field = ft.TextField(label="Количество", value=str(entry.get("qty", 1)),
                                 width=140, text_size=13, keyboard_type=ft.KeyboardType.NUMBER)
        price_field = ft.TextField(label="Цена, ₽", value=str(entry.get("price", 0)),
                                   width=200, text_size=13, keyboard_type=ft.KeyboardType.NUMBER)

        if is_service:
            place_field = ft.TextField(label="Сервис (кто делал)", width=460, text_size=13,
                                       value=entry.get("service", ""))
        else:
            place_field = ft.TextField(label="Где приобрёл", width=460, text_size=13,
                                       value=entry.get("service", ""))

        total_text = ft.Text(f"Сумма: {entry.get('total', 0):.2f} ₽", size=14,
                             weight=ft.FontWeight.BOLD, color=C("accent"))
        error_text = ft.Text("", color=C("danger"), size=12)

        if is_service:
            qty_field.disabled = True

        def recalc(_e=None):
            q = parse_float(qty_field.value) or 0
            p = parse_float(price_field.value) or 0
            total_text.value = f"Сумма: {q * p:.2f} ₽"
            page.update()

        qty_field.on_change = recalc
        price_field.on_change = recalc

        def find_history_match(old_entry):
            """Ищет связанную запись в истории по дате, сумме и типу."""
            old_total = old_entry.get("total", 0)
            old_date = old_entry.get("date", "")
            type_map = {"service": "expense_service",
                        "parts": "expense_parts",
                        "other": "expense_other"}
            hist_type = type_map.get(old_entry.get("expense_type", "other"), "expense_other")
            for h in catalog.get("history", []):
                if (h.get("type") == hist_type
                        and h.get("date") == old_date
                        and abs(h.get("cost", 0) - old_total) < 1):
                    return h
            return None

        def on_save(_e):
            name = name_field.value.strip() if name_field.value else ""
            if not name:
                error_text.value = "Впиши наименование"
                page.update()
                return
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = 0
            if is_service:
                k = parse_int(km_field.value)
                if k is None or k < 0:
                    error_text.value = "Пробег должен быть числом"
                    page.update()
                    return
            qty = parse_float(qty_field.value) if not is_service else 1
            price = parse_float(price_field.value)
            if price is None or price < 0:
                error_text.value = "Цена должна быть числом ≥ 0"
                page.update()
                return
            if not is_service and (qty is None or qty < 1):
                error_text.value = "Количество должно быть числом ≥ 1"
                page.update()
                return
            total = qty * price
            place = place_field.value.strip() if place_field.value else ""

            old_entry_snapshot = dict(entry)
            hist_match = find_history_match(old_entry_snapshot)

            entry["date"] = d
            entry["km"] = k if is_service else 0
            entry["name"] = name
            entry["qty"] = qty
            entry["price"] = price
            entry["total"] = total
            entry["service"] = place

            if hist_match is not None:
                hist_match["date"] = d
                if is_service:
                    hist_match["km"] = k
                if exp_type == "service":
                    hist_match["work"] = f"Сервис: {name}"
                elif exp_type == "parts":
                    hist_match["work"] = f"Запчасти: {name} × {qty} = {total} ₽"
                else:
                    hist_match["work"] = f"Прочее: {name} × {qty} = {total} ₽"
                hist_match["service"] = place
                hist_match["cost"] = int(total)

            save_catalog(catalog)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        content_col = [name_field, ft.Row([date_field], spacing=10)]
        if is_service:
            content_col.append(ft.Row([km_field], spacing=10))
        if not is_service:
            content_col.append(ft.Row([qty_field, price_field], spacing=10))
        else:
            content_col.append(price_field)
        content_col.extend([place_field, total_text, error_text])

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать расход", size=16),
            content=ft.Container(
                content=ft.Column(content_col, spacing=10, tight=True, width=480,
                                  scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_expense_dialog(entry):
        """Удаление расхода и связанной записи в истории."""
        def find_history_match(old_entry):
            old_total = old_entry.get("total", 0)
            old_date = old_entry.get("date", "")
            type_map = {"service": "expense_service",
                        "parts": "expense_parts",
                        "other": "expense_other"}
            hist_type = type_map.get(old_entry.get("expense_type", "other"), "expense_other")
            for h in catalog.get("history", []):
                if (h.get("type") == hist_type
                        and h.get("date") == old_date
                        and abs(h.get("cost", 0) - old_total) < 1):
                    return h
            return None

        def on_confirm(_e):
            hist_match = find_history_match(entry)
            if hist_match is not None:
                try:
                    catalog["history"].remove(hist_match)
                except ValueError:
                    pass
            catalog["expenses_log"] = [
                e for e in catalog.get("expenses_log", [])
                if e is not entry
            ]
            save_catalog(catalog)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить расход?", size=16),
            content=ft.Column([
                ft.Text(f"«{entry.get('name', '')}» от {entry.get('date', '')} "
                        f"на {entry.get('total', 0):.0f} ₽ будет удалён.", size=13),
                ft.Text("Связанная запись в истории тоже удалится (если найдётся).",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    add_row = ft.Row([
        ft.ElevatedButton("➕ СЕРВИС", icon=ft.Icons.BUILD,
                          on_click=lambda _e: open_add_dialog("service", "💰 Расход: Сервис"),
                          bgcolor=ft.Colors.INDIGO_600, color=ft.Colors.WHITE),
        ft.ElevatedButton("➕ ЗАПЧАСТИ", icon=ft.Icons.EXTENSION,
                          on_click=lambda _e: open_add_dialog("parts", "💰 Расход: Запчасти"),
                          bgcolor=ft.Colors.CYAN_700, color=ft.Colors.WHITE),
        ft.ElevatedButton("➕ ПРОЧЕЕ", icon=ft.Icons.CATEGORY,
                          on_click=lambda _e: open_add_dialog("other", "💰 Расход: Прочее"),
                          bgcolor=ft.Colors.BROWN_600, color=ft.Colors.WHITE),
    ], spacing=10, wrap=True)

    def render():
        content_column.controls.clear()

        log = catalog.get("expenses_log", [])
        search_text = search_field.value.lower().strip() if search_field.value else ""
        shown = 0
        total_sum = 0
        for entry in log:
            exp_type = entry.get("expense_type", "other")
            if filter_state["active"] != "all" and filter_state["active"] != exp_type:
                continue
            name = (entry.get("name") or "").lower()
            service = (entry.get("service") or "").lower()
            if search_text and search_text not in name and search_text not in service:
                continue
            shown += 1
            total_sum += entry.get("total", 0)

            type_map = {
                "service": ("💰 Сервис", C("service_text"), C("service_bg")),
                "parts": ("🧩 Запчасти", C("parts_text"), C("parts_bg")),
                "other": ("📦 Прочее", C("other_text"), C("other_bg")),
            }
            label, color, bg = type_map.get(exp_type, type_map["other"])

            qty = entry.get("qty", 1)
            price = entry.get("price", 0)
            total = entry.get("total", 0)

            left_bar = ft.Container(width=4, bgcolor=color, border_radius=2)

            top_row_controls = [
                ft.Text(entry.get("date", "—"), size=13, weight=ft.FontWeight.BOLD,
                        color=C("text")),
            ]
            if exp_type == "service" and entry.get("km", 0) > 0:
                top_row_controls.append(
                    ft.Text(f"· {format_km(entry.get('km', 0))} км", size=12,
                            color=C("text_muted")))
            top_row_controls.append(ft.Container(expand=True))
            top_row_controls.append(
                ft.Text(f"{total:.0f} ₽", size=14, weight=ft.FontWeight.BOLD, color=color))

            info_col = ft.Column([
                ft.Row(top_row_controls, spacing=6),
                ft.Text(f"{label} · {entry.get('name', '—')}", size=12, color=C("text")),
            ], spacing=2)
            if exp_type != "service":
                info_col.controls.append(
                    ft.Text(f"🔢 {qty} × {price:.2f} ₽", size=11, color=C("text_muted")))
            if entry.get("service"):
                place_label = "🏢" if exp_type == "service" else "🛒"
                info_col.controls.append(
                    ft.Text(f"{place_label} {entry['service']}", size=11, color=C("text_muted")))
            def make_edit_exp(e=entry):
                def handler(_e):
                    open_edit_expense_dialog(e)
                return handler

            def make_delete_exp(e=entry):
                def handler(_e):
                    open_delete_expense_dialog(e)
                return handler

            info_col.controls.append(
                ft.Row([
                    ft.Container(expand=True),
                    ft.IconButton(ft.Icons.EDIT, icon_size=18,
                                  icon_color=C("accent_icon"),
                                  tooltip="Редактировать",
                                  on_click=make_edit_exp(entry)),
                    ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                                  icon_color=C("danger_icon"),
                                  tooltip="Удалить",
                                  on_click=make_delete_exp(entry)),
                ], spacing=4))

            card = ft.Container(
                content=ft.Row([left_bar,
                                ft.Column([info_col], spacing=2, expand=True)],
                               spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=bg,
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)

        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.PAYMENTS_OUTLINED, size=48, color=C("text_disabled")),
                        ft.Text("Расходов нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        else:
            content_column.controls.append(
                ft.Container(
                    content=ft.Text(f"Итого: {total_sum:.0f} ₽ ({shown} записей)",
                                    size=13, weight=ft.FontWeight.BOLD, color=C("accent")),
                    padding=10, alignment=ft.alignment.center_right))
        page.update()

    search_field = ft.TextField(
        hint_text="Поиск по наименованию, месту...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: render())

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            render()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=135,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("💰 Сервис", C("service_text"), "service"),
        make_filter_btn("🧩 Запчасти", ft.Colors.CYAN_700, "parts"),
        make_filter_btn("📦 Прочее", C("other_text"), "other"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)
    render()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("💰 РАСХОДЫ", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                ft.Divider(height=1, color=C("border")),
                filters_row,
                ft.Row([search_field, add_row], spacing=10, scroll=ft.ScrollMode.AUTO),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)
# === ВКЛАДКА: БЕНЗИН ===
def build_fuel_tab(catalog, state, page, on_saved):
    content_column = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)
    header_column = ft.Column(spacing=10)
    chart_state = {"active": "consumption"}

    def add_fuel_entry(entry):
        catalog.setdefault("fuel_log", []).insert(0, entry)
        history_entry = {
            "date": entry["date"], "km": entry["km"], "type": "fuel",
            "service": entry.get("station", ""),
            "work": f"Бензин — {entry['liters']} л ({entry.get('fuel_type', 'АИ-95')}), {entry['total']:.0f} ₽",
            "parts": "", "cost": int(entry["total"]),
        }
        catalog.setdefault("history", []).insert(0, history_entry)
        save_catalog(catalog)
        on_saved()

    def open_add_dialog():
        current_km = state["current_km"]
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(current_km),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        liters_field = ft.TextField(label="Литры", width=200, text_size=13,
                                    keyboard_type=ft.KeyboardType.NUMBER)
        price_field = ft.TextField(label="Цена за литр, ₽", width=200, text_size=13,
                                   keyboard_type=ft.KeyboardType.NUMBER)
        total_text = ft.Text("Сумма: 0 ₽", size=14, weight=ft.FontWeight.BOLD,
                             color=C("accent"))
        fuel_type_field = ft.Dropdown(
            label="Тип топлива", width=200, text_size=13, value="АИ-95",
            options=[ft.dropdown.Option("АИ-92"), ft.dropdown.Option("АИ-95"),
                     ft.dropdown.Option("АИ-98"), ft.dropdown.Option("ДТ")])
        station_field = ft.TextField(label="АЗС (опционально)", width=410, text_size=13)
        comment_field = ft.TextField(label="Комментарий (опционально)", width=410,
                                     text_size=13, multiline=True,
                                     min_lines=2, max_lines=3)
        is_full_field = ft.Checkbox(label="Бак заправлен до полного", value=True)
        error_text = ft.Text("", color=C("danger"), size=12)

        def recalc(_e=None):
            l = parse_float(liters_field.value) or 0
            p = parse_float(price_field.value) or 0
            total_text.value = f"Сумма: {l * p:.2f} ₽"
            page.update()

        liters_field.on_change = recalc
        price_field.on_change = recalc

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            liters = parse_float(liters_field.value)
            price = parse_float(price_field.value)
            if liters is None or liters <= 0:
                error_text.value = "Литры должны быть числом > 0"
                page.update()
                return
            if price is None or price <= 0:
                error_text.value = "Цена за литр должна быть числом > 0"
                page.update()
                return
            total = round(liters * price, 2)
            entry = {
                "date": d, "km": k,
                "liters": liters, "price_per_liter": price, "total": total,
                "fuel_type": fuel_type_field.value or "АИ-95",
                "station": station_field.value.strip() if station_field.value else "",
                "comment": comment_field.value.strip() if comment_field.value else "",
                "is_full": bool(is_full_field.value),
            }
            add_fuel_entry(entry)
            page.close(dialog)

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("⛽ Новая заправка", size=16),
            content=ft.Container(
                content=ft.Column([
                    ft.Row([date_field, km_field], spacing=10),
                    ft.Row([liters_field, price_field], spacing=10),
                    total_text,
                    ft.Row([fuel_type_field], spacing=10),
                    station_field,
                    comment_field,
                    is_full_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def calc_fuel_metrics():
        log = catalog.get("fuel_log", [])
        if not log:
            return [], None, 0
        sorted_log = sorted(log, key=lambda x: x.get("km", 0))
        measurements = []
        prev_full = None
        for entry in sorted_log:
            if prev_full is not None and entry.get("is_full"):
                delta_km = entry["km"] - prev_full["km"]
                if delta_km > 0:
                    consumption = (entry["liters"] * 100) / delta_km
                    cost_per_km = entry["total"] / delta_km
                    measurements.append({
                        "date": entry["date"], "km": entry["km"],
                        "consumption": round(consumption, 2),
                        "cost_per_km": round(cost_per_km, 2),
                        "price_per_liter": entry["price_per_liter"],
                        "total": entry["total"],
                    })
            if entry.get("is_full"):
                prev_full = entry

        avg_consumption = None
        if measurements:
            avg_consumption = round(sum(m["consumption"] for m in measurements) / len(measurements), 2)

        total_budget = sum(e.get("total", 0) for e in log)
        return measurements, avg_consumption, total_budget

    def build_charts(measurements):
        if len(measurements) < 2:
            return ft.Container(
                content=ft.Text("Нет данных для графиков (нужны ≥2 замера между полными заправками)",
                                size=12, color=C("text_soft")),
                padding=20, alignment=ft.alignment.center)

        active = chart_state["active"]

        def make_chart_btn(label, key):
            def on_click(_e):
                chart_state["active"] = key
                render()
            is_active = active == key
            return ft.ElevatedButton(
                text=label, on_click=on_click,
                content=ft.Container(
                    content=ft.Text(label, size=12),
                    padding=ft.padding.symmetric(horizontal=10, vertical=6),
                    border_radius=6,
                    bgcolor=C("accent_soft") if is_active else C("card"),
                    border=ft.border.all(2 if is_active else 1,
                                         C("accent_border") if is_active else C("border"))),
                style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))

        buttons_row = ft.Row([
            make_chart_btn("Расход л/100 км", "consumption"),
            make_chart_btn("Цена за литр", "price"),
            make_chart_btn("Сумма по месяцам", "monthly"),
        ], spacing=8, wrap=True)

        chart_container = ft.Container(height=280, padding=10)

        if active in ("consumption", "price"):
            y_key = "consumption" if active == "consumption" else "price_per_liter"
            y_label = "л/100 км" if active == "consumption" else "₽/л"
            max_val = max(m[y_key] for m in measurements)
            min_val = min(m[y_key] for m in measurements)
            max_y = max_val * 1.1 if max_val > 0 else 10
            min_y = min_val * 0.9 if min_val > 0 else 0
            points = []
            for i, m in enumerate(measurements):
                points.append(ft.LineChartDataPoint(
                    x=i * 1.0,
                    y=m[y_key],
                    tooltip=f"{m['date']}: {m[y_key]} {y_label}",
                ))
            chart = ft.LineChart(
                data_series=[ft.LineChartData(
                    data_points=points,
                    stroke_width=3,
                    color=ft.Colors.BLUE_600,
                    curved=True,
                    stroke_cap_round=True,
                    point=True,
                )],
                border=ft.border.all(1, C("border")),
                horizontal_grid_lines=ft.ChartGridLines(interval=max(1, (max_y - min_y) / 5),
                                                        color=C("border"),
                                                        width=1, dash_pattern=[3, 3]),
                vertical_grid_lines=ft.ChartGridLines(interval=1, color=C("border"),
                                                      width=1, dash_pattern=[3, 3]),
                left_axis=ft.ChartAxis(
                    labels_size=40,
                    title=ft.Text(y_label, size=11),
                    title_size=30),
                bottom_axis=ft.ChartAxis(labels_size=40),
                min_y=min_y, max_y=max_y,
                min_x=0, max_x=max(1, len(measurements) - 1) * 1.0,
                expand=True)
            chart_container.content = chart
        else:
            monthly = {}
            for e in catalog.get("fuel_log", []):
                d = e.get("date", "")
                parts = d.split(".")
                if len(parts) == 3:
                    month_key = f"{parts[1]}.{parts[2]}"
                else:
                    month_key = d
                monthly[month_key] = monthly.get(month_key, 0) + e.get("total", 0)
            if not monthly:
                chart_container.content = ft.Text("Нет данных", size=12,
                                                  color=C("text_soft"))
            else:
                keys = sorted(monthly.keys(), key=lambda x: (x.split(".")[1], x.split(".")[0]))
                max_y = max(monthly.values()) * 1.15
                groups = []
                for i, key in enumerate(keys):
                    groups.append(ft.BarChartGroup(
                        x=i,
                        bar_rods=[ft.BarChartRod(
                            from_y=0, to_y=monthly[key], width=24,
                            color=C("fuel_text"),
                            tooltip=f"{key}: {monthly[key]:.0f} ₽",
                            border_radius=4)]))
                chart = ft.BarChart(
                    bar_groups=groups,
                    border=ft.border.all(1, C("border")),
                    horizontal_grid_lines=ft.ChartGridLines(interval=max(1, max_y / 5),
                                                            color=C("border"),
                                                            width=1, dash_pattern=[3, 3]),
                    left_axis=ft.ChartAxis(labels_size=50, title=ft.Text("₽", size=11),
                                           title_size=30),
                    bottom_axis=ft.ChartAxis(
                        labels=[ft.ChartAxisLabel(value=i, label=ft.Container(
                            content=ft.Text(keys[i], size=9), padding=2))
                                for i in range(len(keys))],
                        labels_size=30),
                    min_y=0, max_y=max_y,
                    expand=True)
                chart_container.content = chart

        return ft.Column([buttons_row, chart_container], spacing=10)

    def find_fuel_history_match(old_date, old_total):
        for h in catalog.get("history", []):
            if (h.get("type") == "fuel"
                    and h.get("date") == old_date
                    and abs(h.get("cost", 0) - old_total) < 1):
                return h
        return None

    def open_edit_fuel_dialog(entry):
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", width=200, text_size=13,
                                  value=entry.get("date", today_str()))
        km_field = ft.TextField(label="Пробег, км", width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER,
                                value=str(entry.get("km", 0)))
        liters_field = ft.TextField(label="Литры", width=200, text_size=13,
                                    keyboard_type=ft.KeyboardType.NUMBER,
                                    value=str(entry.get("liters", 0)))
        price_field = ft.TextField(label="Цена за литр, ₽", width=200, text_size=13,
                                   keyboard_type=ft.KeyboardType.NUMBER,
                                   value=str(entry.get("price_per_liter", 0)))
        total_text = ft.Text(f"Сумма: {entry.get('total', 0):.2f} ₽", size=14,
                             weight=ft.FontWeight.BOLD, color=C("accent"))
        fuel_type_field = ft.Dropdown(
            label="Тип топлива", width=200, text_size=13,
            value=entry.get("fuel_type", "АИ-95"),
            options=[ft.dropdown.Option("АИ-92"), ft.dropdown.Option("АИ-95"),
                     ft.dropdown.Option("АИ-98"), ft.dropdown.Option("ДТ")])
        station_field = ft.TextField(label="АЗС (опционально)", width=410, text_size=13,
                                     value=entry.get("station", ""))
        comment_field = ft.TextField(label="Комментарий (опционально)", width=410,
                                     text_size=13, multiline=True,
                                     min_lines=2, max_lines=3,
                                     value=entry.get("comment", ""))
        is_full_field = ft.Checkbox(label="Бак заправлен до полного",
                                    value=bool(entry.get("is_full", True)))
        error_text = ft.Text("", color=C("danger"), size=12)

        def recalc(_e=None):
            l = parse_float(liters_field.value) or 0
            p = parse_float(price_field.value) or 0
            total_text.value = f"Сумма: {l * p:.2f} ₽"
            page.update()

        liters_field.on_change = recalc
        price_field.on_change = recalc

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            liters = parse_float(liters_field.value)
            price = parse_float(price_field.value)
            if liters is None or liters <= 0:
                error_text.value = "Литры должны быть числом > 0"
                page.update()
                return
            if price is None or price <= 0:
                error_text.value = "Цена за литр должна быть числом > 0"
                page.update()
                return
            total = round(liters * price, 2)

            old_date = entry.get("date", "")
            old_total = entry.get("total", 0)
            hist_match = find_fuel_history_match(old_date, old_total)

            entry["date"] = d
            entry["km"] = k
            entry["liters"] = liters
            entry["price_per_liter"] = price
            entry["total"] = total
            entry["fuel_type"] = fuel_type_field.value or "АИ-95"
            entry["station"] = station_field.value.strip() if station_field.value else ""
            entry["comment"] = comment_field.value.strip() if comment_field.value else ""
            entry["is_full"] = bool(is_full_field.value)

            if hist_match is not None:
                hist_match["date"] = d
                hist_match["km"] = k
                hist_match["service"] = entry["station"]
                hist_match["work"] = (f"Бензин — {liters} л ({entry['fuel_type']}), "
                                      f"{total:.0f} ₽")
                hist_match["cost"] = int(total)

            save_catalog(catalog)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать заправку", size=16),
            content=ft.Container(
                content=ft.Column([
                    ft.Row([date_field, km_field], spacing=10),
                    ft.Row([liters_field, price_field], spacing=10),
                    total_text,
                    ft.Row([fuel_type_field], spacing=10),
                    station_field,
                    comment_field,
                    is_full_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_fuel_dialog(entry):
        def on_confirm(_e):
            hist_match = find_fuel_history_match(entry.get("date", ""),
                                                 entry.get("total", 0))
            if hist_match is not None:
                try:
                    catalog["history"].remove(hist_match)
                except ValueError:
                    pass
            catalog["fuel_log"] = [
                e for e in catalog.get("fuel_log", [])
                if e is not entry
            ]
            save_catalog(catalog)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить заправку?", size=16),
            content=ft.Column([
                ft.Text(f"Заправка от {entry.get('date', '')} "
                        f"на {entry.get('total', 0):.0f} ₽ будет удалена.",
                        size=13),
                ft.Text("Связанная запись в истории тоже удалится (если найдётся).",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def render():
        content_column.controls.clear()
        header_column.controls.clear()

        log = catalog.get("fuel_log", [])
        measurements, avg_consumption, total_budget = calc_fuel_metrics()

        add_btn = ft.ElevatedButton(
            "➕ НОВАЯ ЗАПРАВКА", icon=ft.Icons.LOCAL_GAS_STATION,
            on_click=lambda _e: open_add_dialog(),
            bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

        stats_row = ft.Row([
            ft.Container(
                content=ft.Column([
                    ft.Text("Средний расход", size=11, color=C("text_muted")),
                    ft.Text(f"{avg_consumption} л/100 км" if avg_consumption is not None else "—",
                            size=18, weight=ft.FontWeight.BOLD, color=C("accent")),
                ], spacing=2),
                padding=12, bgcolor=C("accent_soft"), border_radius=8, width=200),
            ft.Container(
                content=ft.Column([
                    ft.Text("Всего потрачено", size=11, color=C("text_muted")),
                    ft.Text(f"{total_budget:.0f} ₽", size=18, weight=ft.FontWeight.BOLD,
                            color=C("accent")),
                ], spacing=2),
                padding=12, bgcolor=C("fuel_bg"), border_radius=8, width=200),
            ft.Container(
                content=ft.Column([
                    ft.Text("Заправок", size=11, color=C("text_muted")),
                    ft.Text(f"{len(log)}", size=18, weight=ft.FontWeight.BOLD,
                            color=C("accent")),
                ], spacing=2),
                padding=12, bgcolor=C("resolved_bg"), border_radius=8, width=150),
        ], spacing=10, wrap=True)

        header_column.controls.append(
            ft.Row([add_btn], alignment=ft.MainAxisAlignment.END))
        header_column.controls.append(stats_row)

        if log:
            content_column.controls.append(
                ft.Text("📈 ГРАФИКИ", size=14, weight=ft.FontWeight.BOLD,
                        color=C("accent")))
            content_column.controls.append(build_charts(measurements))

        content_column.controls.append(
            ft.Text("📜 ИСТОРИЯ ЗАПРАВОК", size=14, weight=ft.FontWeight.BOLD,
                    color=C("accent")))

        if not log:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.LOCAL_GAS_STATION_OUTLINED, size=48,
                                color=C("text_disabled")),
                        ft.Text("Заправок пока нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        else:
            sorted_log = sorted(log, key=lambda x: x.get("km", 0), reverse=True)
            for entry in sorted_log:
                left_bar = ft.Container(width=4, bgcolor=C("teal_accent"), border_radius=2)
                info_col = ft.Column([
                    ft.Row([
                        ft.Text(entry.get("date", "—"), size=13,
                                weight=ft.FontWeight.BOLD, color=C("text")),
                        ft.Text(f"· {format_km(entry.get('km', 0))} км", size=12,
                                color=C("text_muted")),
                        ft.Container(expand=True),
                        ft.Text(f"{entry.get('total', 0):.0f} ₽", size=14,
                                weight=ft.FontWeight.BOLD, color=C("teal_text")),
                    ], spacing=6),
                    ft.Text(f"⛽ {entry.get('liters', 0)} л × {entry.get('price_per_liter', 0):.2f} ₽ · "
                            f"{entry.get('fuel_type', 'АИ-95')}"
                            + (" · до полного" if entry.get("is_full") else ""),
                            size=12, color=C("text")),
                ], spacing=2)
                if entry.get("station"):
                    info_col.controls.append(
                        ft.Text(f"🏢 {entry['station']}", size=11, color=C("text_muted")))
                if entry.get("comment"):
                    info_col.controls.append(
                        ft.Text(f"💬 {entry['comment']}", size=11, color=C("text_muted")))

                def make_edit_fuel(e=entry):
                    def handler(_e):
                        open_edit_fuel_dialog(e)
                    return handler

                def make_delete_fuel(e=entry):
                    def handler(_e):
                        open_delete_fuel_dialog(e)
                    return handler

                info_col.controls.append(
                    ft.Row([
                        ft.Container(expand=True),
                        ft.IconButton(ft.Icons.EDIT, icon_size=18,
                                      icon_color=C("accent_icon"),
                                      tooltip="Редактировать",
                                      on_click=make_edit_fuel(entry)),
                        ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                                      icon_color=C("danger_icon"),
                                      tooltip="Удалить",
                                      on_click=make_delete_fuel(entry)),
                    ], spacing=4))

                card = ft.Container(
                    content=ft.Row([left_bar,
                                    ft.Column([info_col], spacing=2, expand=True)],
                                   spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                    padding=10, bgcolor=C("card"),
                    border=ft.border.all(1, C("border_light")), border_radius=6,
                    margin=ft.margin.only(bottom=4))
                content_column.controls.append(card)

        page.update()

    render()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("⛽ БЕНЗИН", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        header_column,
        ft.Divider(height=1, color=C("border")),
        content_column,
    ], expand=True)


# === ВКЛАДКА: ИСТОРИЯ ===
def build_history_tab(catalog, state, page):
    history = catalog.get("history", [])
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}

    def apply_filters():
        content_column.controls.clear()
        search_text = search_field.value.lower().strip() if search_field.value else ""
        shown = 0
        for entry in history:
            type_key, type_label, color, bg = detect_history_type(entry)
            if filter_state["active"] != "all" and filter_state["active"] != type_key:
                continue
            if search_text:
                work_l = (entry.get("work") or "").lower()
                parts_l = (entry.get("parts") or "").lower()
                service_l = (entry.get("service") or "").lower()
                if (search_text not in work_l and search_text not in parts_l
                        and search_text not in service_l):
                    continue
            shown += 1
            left_bar = ft.Container(width=4, bgcolor=color, border_radius=2)

            top_row_controls = [
                ft.Text(entry.get("date", "—"), size=13, weight=ft.FontWeight.BOLD, color=C("text")),
            ]
            km_val = entry.get("km", 0)
            if km_val and km_val > 0:
                top_row_controls.append(
                    ft.Text(f"· {format_km(km_val)} км", size=12, color=C("text_muted")))
            top_row_controls.append(ft.Container(expand=True))
            top_row_controls.append(
                ft.Text(type_label, size=11, color=color, weight=ft.FontWeight.BOLD))

            top_row = ft.Row(top_row_controls, spacing=6)
            middle_col = ft.Column([
                ft.Text(entry.get("work", "—"), size=13, color=C("text")),
            ], spacing=2)
            if entry.get("parts"):
                middle_col.controls.append(
                    ft.Text(f"🔧 {entry['parts']}", size=11, color=C("text_muted")))
            if entry.get("installed_article"):
                middle_col.controls.append(
                    ft.Text(f"🔩 Стоит: {entry['installed_article']}", size=11,
                            color=C("success_strong"), weight=ft.FontWeight.BOLD))
            def make_edit_hist(e=entry):
                def handler(_e):
                    open_edit_history_dialog(e)
                return handler

            def make_delete_hist(e=entry):
                def handler(_e):
                    open_delete_history_dialog(e)
                return handler

            bottom_row = ft.Row([
                ft.Text(f"🏢 {entry['service']}" if entry.get("service") else "",
                        size=11, color=C("text_muted")),
                ft.Container(expand=True),
                ft.Text(f"{entry.get('cost', 0)} ₽" if entry.get("cost") else "",
                        size=11, color=C("text_secondary"), weight=ft.FontWeight.W_500),
                ft.IconButton(ft.Icons.EDIT, icon_size=18,
                              icon_color=C("accent_icon"),
                              tooltip="Редактировать",
                              on_click=make_edit_hist(entry)),
                ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                              icon_color=C("danger_icon"),
                              tooltip="Удалить",
                              on_click=make_delete_hist(entry)),
            ], spacing=4)
            card = ft.Container(
                content=ft.Row([
                    left_bar,
                    ft.Column([top_row, middle_col, bottom_row], spacing=6, expand=True),
                ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=bg,
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)
        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.HISTORY_TOGGLE_OFF, size=48, color=C("text_disabled")),
                        ft.Text("Записей нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        page.update()

    search_field = ft.TextField(
        hint_text="Поиск по работе, запчастям, сервису...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: apply_filters())

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            apply_filters()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=135,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn
    
    def open_edit_history_dialog(entry):
        """Редактирование записи истории. Тип не меняем."""
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=entry.get("date", ""),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(entry.get("km", 0)),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        service_field = ft.TextField(label="Сервис (кто делал)", width=460, text_size=13,
                                     value=entry.get("service", ""))
        work_field = ft.TextField(label="Работа", width=460, text_size=13,
                                  value=entry.get("work", ""))
        parts_field = ft.TextField(label="Запчасти", width=460, text_size=13,
                                   value=entry.get("parts", ""))
        cost_field = ft.TextField(label="Стоимость, ₽", width=200, text_size=13,
                                  value=str(entry.get("cost", 0)),
                                  keyboard_type=ft.KeyboardType.NUMBER)
        error_text = ft.Text("", color=C("danger"), size=12)

        summary = ft.Column([
            ft.Text("Тип записи не меняется", size=11,
                    color=C("text_muted"), italic=True),
        ], spacing=2)

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            cost = parse_int(cost_field.value)
            if cost is None or cost < 0:
                error_text.value = "Стоимость должна быть числом ≥ 0"
                page.update()
                return
            work = work_field.value.strip() if work_field.value else ""
            if not work:
                error_text.value = "Впиши работу"
                page.update()
                return

            entry["date"] = d
            entry["km"] = k
            entry["service"] = service_field.value.strip() if service_field.value else ""
            entry["work"] = work
            entry["parts"] = parts_field.value.strip() if parts_field.value else ""
            entry["cost"] = cost

            save_catalog(catalog)
            page.close(dialog)
            apply_filters()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать запись истории", size=16),
            content=ft.Container(
                content=ft.Column([
                    summary,
                    ft.Divider(height=1, color=C("border")),
                    ft.Row([date_field, km_field], spacing=10),
                    service_field,
                    work_field,
                    parts_field,
                    cost_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_history_dialog(entry):
        """Удаление записи истории."""
        def on_confirm(_e):
            try:
                catalog["history"].remove(entry)
            except ValueError:
                pass
            save_catalog(catalog)
            page.close(dialog)
            apply_filters()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить запись?", size=16),
            content=ft.Column([
                ft.Text(f"«{entry.get('work', '')}» от {entry.get('date', '')} "
                        f"будет удалена.", size=13),
                ft.Text("Связанная запись в расходах не удалится — правь её отдельно.",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("🔵 Замены", C("accent_icon"), "replace"),
        make_filter_btn("⛽ Бензин", C("teal_text"), "fuel"),
        make_filter_btn("💰 Сервис", C("service_text"), "expense_service"),
        make_filter_btn("🧩 Запчасти", ft.Colors.CYAN_700, "expense_parts"),
        make_filter_btn("📦 Прочее", C("other_text"), "expense_other"),
        make_filter_btn("⚠ Дефекты", C("danger_strong"), "defect"),
        make_filter_btn("✔ Дефект снят", C("success"), "defect_resolved"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)
    header_info = ft.Text(f"Всего записей: {len(history)}", size=12, color=C("text_muted"))
    apply_filters()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Row([ft.Text("📜 ИСТОРИЯ ОБСЛУЖИВАНИЯ", size=16,
                                weight=ft.FontWeight.BOLD, color=C("accent")),
                        ft.Container(expand=True), header_info]),
                ft.Divider(height=1, color=C("border")),
                filters_row, search_field,
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)
# === ВКЛАДКА: ЗАМЕТКИ ===
def build_notes_tab(catalog, state, page, on_saved):
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}

    PRIORITY_MAP = {
        "red": ("🔴 Важно", C("danger"), C("defect_bg")),
        "yellow": ("🟡 Средне", C("warning_strong"), C("status_yellow_bg")),
        "green": ("🟢 Не срочно", C("success"), C("resolved_bg")),
    }

    def open_note_dialog(note=None):
        is_edit = note is not None
        title_field = ft.TextField(label="Заголовок", width=460, text_size=13,
                                   value=note.get("title", "") if is_edit else "")
        text_field = ft.TextField(label="Текст", width=460, text_size=13,
                                  multiline=True, min_lines=4, max_lines=8,
                                  value=note.get("text", "") if is_edit else "")
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", width=200, text_size=13,
                                  value=note.get("date", today_str()) if is_edit else today_str())
        priority_state = {"value": note.get("priority", "yellow") if is_edit else "yellow"}
        priority_buttons = []

        def render_priority_buttons():
            for btn in priority_buttons:
                key = btn.data
                is_active = priority_state["value"] == key
                btn.content.bgcolor = PRIORITY_MAP[key][2] if is_active else C("card")
                btn.content.border = ft.border.all(
                    2 if is_active else 1,
                    PRIORITY_MAP[key][1] if is_active else C("border"))

        def make_priority_btn(key):
            def on_click(_e):
                priority_state["value"] = key
                render_priority_buttons()
                page.update()
            btn = ft.ElevatedButton(
                text=key, data=key, on_click=on_click,
                content=ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.CIRCLE, color=PRIORITY_MAP[key][1], size=12),
                        ft.Text(PRIORITY_MAP[key][0], size=12, color=C("text")),
                    ]),
                    padding=ft.padding.symmetric(horizontal=12, vertical=8),
                    border_radius=6,
                    bgcolor=PRIORITY_MAP[key][2] if priority_state["value"] == key else C("card"),
                    border=ft.border.all(
                        2 if priority_state["value"] == key else 1,
                        PRIORITY_MAP[key][1] if priority_state["value"] == key else C("border"))),
                style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
            return btn

        priority_buttons.extend([
            make_priority_btn("red"),
            make_priority_btn("yellow"),
            make_priority_btn("green"),
        ])

        error_text = ft.Text("", color=C("danger"), size=12)

        def on_save(_e):
            t = title_field.value.strip() if title_field.value else ""
            if not t:
                error_text.value = "Впиши заголовок"
                page.update()
                return
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            body = text_field.value.strip() if text_field.value else ""
            pr = priority_state["value"]
            if is_edit:
                note["title"] = t
                note["text"] = body
                note["priority"] = pr
            else:
                new_note = {
                    "id": f"note_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    "title": t,
                    "text": body,
                    "priority": pr,
                    "date": today_str(),
                }
                catalog.setdefault("notes", []).insert(0, new_note)
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать заметку" if is_edit else "📝 Новая заметка", size=16),
            content=ft.Container(
                content=ft.Column([
                title_field,
                text_field,
                date_field,
                ft.Text("Важность:", size=12, color=C("text_muted")),
                ft.Row(priority_buttons, spacing=8, wrap=True),
                error_text,
            ], spacing=10, tight=True, width=480),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_dialog(note):
        def on_confirm(_e):
            catalog["notes"] = [n for n in catalog.get("notes", []) if n.get("id") != note.get("id")]
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить заметку?", size=16),
            content=ft.Text(f"«{note.get('title', '')}» будет удалена.", size=13),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def apply_filters():
        content_column.controls.clear()
        search_text = search_field.value.lower().strip() if search_field.value else ""
        notes = catalog.get("notes", [])
        shown = 0
        for note in notes:
            pr = note.get("priority", "yellow")
            if pr not in PRIORITY_MAP:
                pr = "yellow"
            if filter_state["active"] != "all" and filter_state["active"] != pr:
                continue
            title_l = note.get("title", "").lower()
            text_l = note.get("text", "").lower()
            if search_text and search_text not in title_l and search_text not in text_l:
                continue
            shown += 1
            label, color, bg = PRIORITY_MAP[pr]

            def make_edit(n=note):
                def handler(_e):
                    open_note_dialog(n)
                return handler

            def make_delete(n=note):
                def handler(_e):
                    open_delete_dialog(n)
                return handler

            left_bar = ft.Container(width=4, bgcolor=color, border_radius=2)

            top_row = ft.Row([
                ft.Text(note.get("title", "—"), size=14, weight=ft.FontWeight.BOLD,
                        color=C("text"), expand=True),
                ft.Text(label, size=11, color=color, weight=ft.FontWeight.BOLD),
            ], spacing=6)

            body_text = ft.Text(note.get("text", ""), size=12, color=C("text"))

            bottom_row = ft.Row([
                ft.Text(note.get("date", "—"), size=11, color=C("text_muted")),
                ft.Container(expand=True),
                ft.IconButton(ft.Icons.EDIT, icon_size=18, icon_color=C("accent_icon"),
                              tooltip="Редактировать", on_click=make_edit(note)),
                ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                              icon_color=C("danger_icon"),
                              tooltip="Удалить", on_click=make_delete(note)),
            ], spacing=4)

            card = ft.Container(
                content=ft.Row([
                    left_bar,
                    ft.Column([top_row, body_text, bottom_row], spacing=6, expand=True),
                ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=bg,
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)

        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.NOTE_ALT_OUTLINED, size=48, color=C("text_disabled")),
                        ft.Text("Заметок нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        page.update()

    search_field = ft.TextField(
        hint_text="Поиск по заголовку и тексту...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: apply_filters())

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            apply_filters()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=135,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("🔴 Важно", C("danger"), "red"),
        make_filter_btn("🟡 Средне", C("warning_strong"), "yellow"),
        make_filter_btn("🟢 Не срочно", C("success"), "green"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)

    add_btn = ft.ElevatedButton(
        "+ НОВАЯ ЗАМЕТКА", icon=ft.Icons.ADD,
        on_click=lambda _e: open_note_dialog(None),
        bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE,
        style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

    apply_filters()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("📋 ЗАМЕТКИ", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                    ft.Container(expand=True),
                    add_btn,
                ]),
                ft.Divider(height=1, color=C("border")),
                filters_row, search_field,
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)


# === ВКЛАДКА: ДОЛИВКА ===
def build_topup_tab(catalog, state, page, on_saved):
    current_km = state["current_km"]

    def calc_oil_consumption():
        stock_oil = next((s for s in catalog.get("topup_stock", []) if s.get("id") == "topup_oil"), None)
        oil_item = next((i for i in catalog.get("maintenance_radar", []) if i.get("id") == "oil"), None)
        if not stock_oil or not oil_item:
            return None
        last_oil_km = oil_item.get("last_km", 0)
        if not last_oil_km:
            return None
        passed = current_km - last_oil_km
        if passed <= 0:
            return None
        total_ml = 0
        for entry in catalog.get("topup_log", []):
            if entry.get("fluid_id") == "topup_oil" and entry.get("km", 0) >= last_oil_km:
                total_ml += entry.get("amount_ml", 0)
        if total_ml == 0:
            return 0
        return round(total_ml / passed * 1000)

    def open_topup_dialog(fluid):
        fluid_id = fluid.get("id")
        unit = fluid.get("unit", "мл")
        is_oil = fluid_id == "topup_oil"
        unit_label = "Объём (мл)" if unit == "мл" else "Объём (л)"

        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                                  width=460, text_size=13)
        km_field = ft.TextField(label="Пробег (км)", value=str(current_km),
                                width=460, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        amount_field = ft.TextField(label=unit_label, width=460, text_size=13,
                                    keyboard_type=ft.KeyboardType.NUMBER,
                                    hint_text="Например: 250" if unit == "мл" else "Например: 1")
        comment_field = ft.TextField(label="Комментарий", width=460, text_size=13,
                                     hint_text="Например: Долив после поездки 500 км")
        error_text = ft.Text("", color=C("danger"), size=12)

        header = ft.Column([
            ft.Text(f"Жидкость: {fluid.get('name', '')}", size=13, weight=ft.FontWeight.BOLD),
            ft.Text(f"Остаток: {fluid.get('qty', 0)} {unit}", size=12, color=C("text_muted")),
        ], spacing=2)

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            amt = parse_float(amount_field.value)
            if amt is None or amt <= 0:
                error_text.value = "Объём должен быть числом > 0"
                page.update()
                return

            amount_native = amt
            amount_ml = int(amt) if unit == "мл" else int(amt * 1000)

            current_qty = fluid.get("qty", 0)
            if amount_native > current_qty:
                error_text.value = f"На складе только {current_qty} {unit}"
                page.update()
                return

            fluid["qty"] = current_qty - amount_native

            entry = {
                "date": d,
                "km": k,
                "fluid_id": fluid_id,
                "fluid_name": fluid.get("name", ""),
                "amount": amount_native,
                "unit": unit,
                "amount_ml": amount_ml,
                "comment": comment_field.value.strip() if comment_field.value else "",
            }
            catalog.setdefault("topup_log", []).insert(0, entry)

            if is_oil:
                history_entry = {
                    "date": d, "km": k, "type": "other", "service": "",
                    "work": f"Долив масла ДВС — {amount_ml} мл",
                    "parts": "", "cost": 0,
                }
                catalog.setdefault("history", []).insert(0, history_entry)

            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("💧 Добавить доливку", size=16),
            content=ft.Container(
                content=ft.Column([
                    header,
                    ft.Divider(height=1, color=C("border")),
                    date_field,
                    km_field,
                    amount_field,
                    comment_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_add_stock_dialog(fluid):
        fluid_id = fluid.get("id")
        unit = fluid.get("unit", "мл")
        unit_label = "Объём (мл)" if unit == "мл" else "Объём (л)"

        amount_field = ft.TextField(label=unit_label, width=460, text_size=13,
                                    keyboard_type=ft.KeyboardType.NUMBER,
                                    hint_text="Например: 1000" if unit == "мл" else "Например: 5")
        price_field = ft.TextField(label="Цена, ₽ (необязательно)", width=460, text_size=13,
                                   keyboard_type=ft.KeyboardType.NUMBER)
        comment_field = ft.TextField(label="Комментарий (необязательно)", width=460, text_size=13,
                                     hint_text="Например: куплено в Озоне, 4 л")
        error_text = ft.Text("", color=C("danger"), size=12)

        header = ft.Column([
            ft.Text(f"Жидкость: {fluid.get('name', '')}", size=13, weight=ft.FontWeight.BOLD),
            ft.Text(f"Остаток: {fluid.get('qty', 0)} {unit}", size=12, color=C("text_muted")),
        ], spacing=2)

        def on_save(_e):
            amt = parse_float(amount_field.value)
            if amt is None or amt <= 0:
                error_text.value = "Объём должен быть числом > 0"
                page.update()
                return
            fluid["qty"] = fluid.get("qty", 0) + amt
            price = parse_int(price_field.value) or 0
            comment_text = comment_field.value.strip() if comment_field.value else ""
            work_text = f"Куплено: {fluid.get('name', '')} — {amt} {unit}"
            if comment_text:
                work_text += f" ({comment_text})"
            history_entry = {
                "date": today_str(), "km": current_km, "type": "purchase", "service": "",
                "work": work_text,
                "parts": "", "cost": price,
            }
            catalog.setdefault("history", []).insert(0, history_entry)
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("📦 Добавить запас", size=16),
            content=ft.Container(
                content=ft.Column([
                    header,
                    ft.Divider(height=1, color=C("border")),
                    amount_field,
                    price_field,
                    comment_field,
                    error_text,
                ], spacing=10, tight=True, width=480),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
                        actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def find_topup_history_match(entry):
        """Ищет связанную запись в истории для доливки масла ДВС."""
        if entry.get("fluid_id") != "topup_oil":
            return None
        old_date = entry.get("date", "")
        old_km = entry.get("km", 0)
        old_ml = entry.get("amount_ml", 0)
        marker = f"Долив масла ДВС — {old_ml} мл"
        for h in catalog.get("history", []):
            if (h.get("type") == "other"
                    and h.get("date") == old_date
                    and h.get("km") == old_km
                    and h.get("work") == marker):
                return h
        return None

    def open_edit_topup_dialog(entry):
        fluid_id = entry.get("fluid_id")
        unit = entry.get("unit", "мл")
        is_oil = fluid_id == "topup_oil"
        unit_label = "Объём (мл)" if unit == "мл" else "Объём (л)"

        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", width=440, text_size=13,
                                  value=entry.get("date", ""))
        km_field = ft.TextField(label="Пробег, км", width=440, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER,
                                value=str(entry.get("km", 0)))
        amount_field = ft.TextField(label=unit_label, width=440, text_size=13,
                                    keyboard_type=ft.KeyboardType.NUMBER,
                                    value=str(entry.get("amount", 0)))
        comment_field = ft.TextField(label="Комментарий", width=440, text_size=13,
                                     value=entry.get("comment", ""))
        error_text = ft.Text("", color=C("danger"), size=12)

        header = ft.Column([
            ft.Text(entry.get("fluid_name", ""), size=13, weight=ft.FontWeight.BOLD),
            ft.Text("Остаток на складе не меняется", size=11,
                    color=C("text_muted"), italic=True),
        ], spacing=2)

        def on_save(_e):
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            k = parse_int(km_field.value)
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return
            amt = parse_float(amount_field.value)
            if amt is None or amt <= 0:
                error_text.value = "Объём должен быть числом > 0"
                page.update()
                return

            hist_match = find_topup_history_match(entry)
            amount_ml = int(amt) if unit == "мл" else int(amt * 1000)

            entry["date"] = d
            entry["km"] = k
            entry["amount"] = amt
            entry["amount_ml"] = amount_ml
            entry["comment"] = comment_field.value.strip() if comment_field.value else ""

            if hist_match is not None:
                hist_match["date"] = d
                hist_match["km"] = k
                hist_match["work"] = f"Долив масла ДВС — {amount_ml} мл"

            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать доливку", size=16),
            content=ft.Container(
                content=ft.Column([
                    header,
                    ft.Divider(height=1, color=C("border")),
                    date_field,
                    km_field,
                    amount_field,
                    comment_field,
                    error_text,
                ], spacing=10, tight=True, width=460, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_topup_dialog(entry):
        fluid_name = entry.get("fluid_name", "")
        unit = entry.get("unit", "мл")
        amount = entry.get("amount", 0)

        def on_confirm(_e):
            hist_match = find_topup_history_match(entry)
            if hist_match is not None:
                try:
                    catalog["history"].remove(hist_match)
                except ValueError:
                    pass
            catalog["topup_log"] = [
                e for e in catalog.get("topup_log", [])
                if e is not entry
            ]
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить запись о доливке?", size=16),
            content=ft.Column([
                ft.Text(f"Доливка «{fluid_name}» на {amount} {unit} "
                        f"от {entry.get('date', '')} будет удалена.",
                        size=13),
                ft.Text("Остаток на складе НЕ изменится (масло уже ушло).",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_edit_stock_dialog(fluid):
        unit = fluid.get("unit", "мл")
        unit_label = "Остаток (мл)" if unit == "мл" else "Остаток (л)"

        qty_field = ft.TextField(label=unit_label, width=440, text_size=13,
                                 keyboard_type=ft.KeyboardType.NUMBER,
                                 value=str(fluid.get("qty", 0)))
        error_text = ft.Text("", color=C("danger"), size=12)

        header = ft.Column([
            ft.Text(fluid.get("name", ""), size=13, weight=ft.FontWeight.BOLD),
            ft.Text("Впиши фактический остаток на складе. "
                    "Просто присваивается — ничего не считается.",
                    size=11, color=C("text_muted"), italic=True),
        ], spacing=2)

        def on_save(_e):
            amt = parse_float(qty_field.value)
            if amt is None or amt < 0:
                error_text.value = "Остаток должен быть числом ≥ 0"
                page.update()
                return
            fluid["qty"] = amt
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏ Изменить остаток", size=16),
            content=ft.Container(
                content=ft.Column([
                    header,
                    ft.Divider(height=1, color=C("border")),
                    qty_field,
                    error_text,
                ], spacing=10, tight=True, width=460),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    COLOR_MAP = {
        "orange": (C("warning_text"), C("writeoff_bg")),
        "blue": (C("accent_icon"), C("accent_soft")),
        "red": (C("defect_text"), C("defect_bg")),
        "green": (C("resolved_text"), C("resolved_bg")),
    }

    # --- Верхняя часть: карточки (без своего скролла, растут по высоте) ---
    cards_column = ft.Column(spacing=10)
    stocks = catalog.get("topup_stock", [])
    oil_consumption = calc_oil_consumption()

    for fluid in stocks:
        color_main, color_bg = COLOR_MAP.get(fluid.get("color", "blue"),
                                              (C("accent_icon"), C("accent_soft")))
        unit = fluid.get("unit", "мл")
        qty = fluid.get("qty", 0)

        if qty == 0:
            badge_text = "❌ Пусто"
            badge_color = ft.Colors.RED_600
        elif qty <= (200 if unit == "мл" else 1):
            badge_text = "⚠ Мало"
            badge_color = C("warning_text")
        else:
            badge_text = None
            badge_color = None

        title_row = ft.Row([
            ft.Text(fluid.get("name", ""), size=13, weight=ft.FontWeight.BOLD,
                    color=C("text"), expand=True),
        ], spacing=6)
        if badge_text:
            title_row.controls.append(ft.Container(
                content=ft.Text(badge_text, size=10, weight=ft.FontWeight.BOLD,
                                color=ft.Colors.WHITE),
                bgcolor=badge_color, border_radius=8,
                padding=ft.padding.symmetric(horizontal=8, vertical=3)))

        info_lines = [
            title_row,
            ft.Text(f"Остаток: {qty} {unit}", size=12, color=C("text_secondary")),
        ]

        if fluid.get("id") == "topup_oil" and oil_consumption is not None:
            if oil_consumption <= 100:
                cons_color = C("success")
                cons_text = f"🟢 Расход: {oil_consumption} мл / 1000 км (норма)"
            elif oil_consumption <= 300:
                cons_color = C("warning_strong")
                cons_text = f"🟡 Расход: {oil_consumption} мл / 1000 км (следить)"
            else:
                cons_color = C("danger")
                cons_text = f"🔴 Расход: {oil_consumption} мл / 1000 км (тревога)"
            info_lines.append(ft.Text(cons_text, size=11, color=cons_color,
                                      weight=ft.FontWeight.BOLD))

        def make_topup(f=fluid):
            def handler(_e):
                open_topup_dialog(f)
            return handler

        def make_add(f=fluid):
            def handler(_e):
                open_add_stock_dialog(f)
            return handler

        topup_btn = ft.ElevatedButton(
            "ДОЛИТЬ", icon=ft.Icons.WATER_DROP, on_click=make_topup(fluid),
            disabled=(qty == 0),
            bgcolor=ft.Colors.GREEN_600 if qty > 0 else C("border"),
            color=ft.Colors.WHITE,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=12, vertical=10)))

        add_btn = ft.ElevatedButton(
            "ДОБАВИТЬ ЗАПАС", icon=ft.Icons.ADD, on_click=make_add(fluid),
            bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=12, vertical=10)))

        def make_edit_stock(f=fluid):
            def handler(_e):
                open_edit_stock_dialog(f)
            return handler

        stock_edit_btn = ft.IconButton(
            icon=ft.Icons.EDIT, icon_size=18,
            icon_color=C("accent_icon"),
            tooltip="Изменить остаток",
            on_click=make_edit_stock(fluid))

        card = ft.Container(
            content=ft.Row([
                ft.Column(info_lines, spacing=2, expand=True),
                ft.Row([topup_btn, add_btn, stock_edit_btn], spacing=6,
                       vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=8, bgcolor=C("card"),
            border=ft.border.all(2, color_main),
            border_radius=8)
        cards_column.controls.append(card)

    # --- Нижняя часть: история доливок со СВОИМ фиксированным окном и скроллом ---
    history_column = ft.Column(spacing=4, scroll=ft.ScrollMode.AUTO, expand=True)

    log = catalog.get("topup_log", [])
    if not log:
        history_column.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.WATER_DROP_OUTLINED, size=48, color=C("text_disabled")),
                    ft.Text("Доливок пока не было", size=14, color=C("text_soft")),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=40, alignment=ft.alignment.center))
    else:
        for entry in log:
            unit = entry.get("unit", "мл")
            amount = entry.get("amount", 0)
            date_str = entry.get("date", "—")
            km_str = format_km(entry.get("km", 0))
            fluid_name = entry.get("fluid_name", "")
            comment = entry.get("comment", "")

            left_bar = ft.Container(width=4, bgcolor=ft.Colors.BLUE_400, border_radius=2)
            info_col = ft.Column([
                ft.Row([
                    ft.Text(date_str, size=13, weight=ft.FontWeight.BOLD, color=C("text")),
                    ft.Text(f"· {km_str} км", size=12, color=C("text_muted")),
                    ft.Container(expand=True),
                    ft.Text(f"+{amount} {unit}", size=13, weight=ft.FontWeight.BOLD,
                            color=C("success")),
                ], spacing=6),
                ft.Text(fluid_name, size=12, color=C("text")),
            ], spacing=2)
            if comment:
                info_col.controls.append(
                    ft.Text(f"💬 {comment}", size=11, color=C("text_muted")))

            def make_edit_topup(e=entry):
                def handler(_e):
                    open_edit_topup_dialog(e)
                return handler

            def make_delete_topup(e=entry):
                def handler(_e):
                    open_delete_topup_dialog(e)
                return handler

            info_col.controls.append(
                ft.Row([
                    ft.Container(expand=True),
                    ft.IconButton(ft.Icons.EDIT, icon_size=18,
                                  icon_color=C("accent_icon"),
                                  tooltip="Редактировать",
                                  on_click=make_edit_topup(entry)),
                    ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                                  icon_color=C("danger_icon"),
                                  tooltip="Удалить",
                                  on_click=make_delete_topup(entry)),
                ], spacing=4))

            card = ft.Container(
                content=ft.Row([left_bar,
                                ft.Column([info_col], spacing=2, expand=True)],
                               spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=C("card"),
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            history_column.controls.append(card)

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("💧 ДОЛИВКА", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        cards_column,
        ft.Divider(height=1, color=C("border")),
        ft.Text("📜 ИСТОРИЯ ДОЛИВОК", size=14, weight=ft.FontWeight.BOLD,
                color=C("accent")),
        ft.Container(content=history_column, expand=True,
                     border=ft.border.all(1, C("border_light")),
                     border_radius=6, padding=6),
    ], expand=True)


# === ВКЛАДКА: ШИНЫ / СЕЗОН ===
def build_tires_tab(catalog, state, page, on_saved):
    content_column = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

    def get_tires():
        return catalog.setdefault("tire_sets", [])

    def get_current_season():
        month = datetime.now().month
        return "summer" if 4 <= month <= 10 else "winter"

    def open_add_set_dialog():
        name_field = ft.TextField(label="Название (бренд + модель)", width=460, text_size=13,
                                  hint_text="Например: Sailun Atrezzo Elite")
        size_field = ft.TextField(label="Размерность", width=460, text_size=13,
                                  hint_text="Например: 185/60 R15")
        season_field = ft.Dropdown(
            label="Сезон", width=460, text_size=13, value="summer",
            options=[ft.dropdown.Option(key="summer", text="☀ Лето"),
                     ft.dropdown.Option(key="winter", text="❄ Зима")])
        error_text = ft.Text("", color=C("danger"), size=12)

        def on_save(_e):
            name = name_field.value.strip() if name_field.value else ""
            size = size_field.value.strip() if size_field.value else ""
            if not name:
                error_text.value = "Впиши название"
                page.update()
                return
            if not size:
                error_text.value = "Впиши размерность"
                page.update()
                return
            sets = get_tires()
            new_set = {
                "id": f"tire_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                "name": name,
                "size": size,
                "season": season_field.value or "summer",
                "status": "stored",
                "install_date": "",
                "install_km": 0,
                "removed_date": "",
                "removed_km": 0,
                "total_km": 0,
                "season_km": 0,
            }
            sets.append(new_set)
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("➕ Новый комплект шин", size=16),
            content=ft.Container(
                content=ft.Column([
                    ft.Text("Купил — положил в гараж. Дату и пробег спрашиваем при установке.",
                            size=11, color=C("text_muted"), italic=True),
                    name_field,
                    size_field,
                    season_field,
                    error_text,
                ], spacing=10, tight=True, width=480),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_install_dialog(tire_set):
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(state["current_km"]),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        error_text = ft.Text("", color=C("danger"), size=12)

        summary = ft.Column([
            ft.Text(tire_set.get("name", ""), size=14, weight=ft.FontWeight.BOLD),
            ft.Text(f"Размер: {tire_set.get('size', '')}", size=12, color=C("text_muted")),
        ], spacing=4)

        def on_confirm(_e):
            d = date_field.value.strip() if date_field.value else ""
            k = parse_int(km_field.value)
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return

            tires = get_tires()
            # Снимаем текущий установленный комплект того же сезона
            for t in tires:
                if t.get("status") == "installed" and t.get("season") == tire_set.get("season"):
                    t["status"] = "stored"
                    t["removed_date"] = d
                    t["removed_km"] = k

            tire_set["status"] = "installed"
            tire_set["install_date"] = d
            tire_set["install_km"] = k
            tire_set["removed_date"] = ""
            tire_set["removed_km"] = 0
            tire_set["season_km"] = 0

            history_entry = {
                "date": d, "km": k, "type": "work", "service": "",
                "work": f"Установка шин: {tire_set.get('name', '')} ({tire_set.get('size', '')})",
                "parts": "", "cost": 0,
            }
            catalog.setdefault("history", []).insert(0, history_entry)

            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🔄 Установка комплекта", size=16),
            content=ft.Container(
                content=ft.Column([
                    summary,
                    ft.Divider(height=1, color=C("border")),
                    ft.Row([date_field, km_field], spacing=10),
                    error_text,
                ], spacing=10, tight=True, width=460),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УСТАНОВИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_writeoff_dialog(tire_set):
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", value=today_str(),
                                  width=200, text_size=13)
        km_field = ft.TextField(label="Пробег, км", value=str(state["current_km"]),
                                width=200, text_size=13,
                                keyboard_type=ft.KeyboardType.NUMBER)
        error_text = ft.Text("", color=C("danger"), size=12)

        def on_confirm(_e):
            d = date_field.value.strip() if date_field.value else ""
            k = parse_int(km_field.value)
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            if k is None or k < 0:
                error_text.value = "Пробег должен быть числом"
                page.update()
                return

            tire_set["status"] = "written_off"
            tire_set["removed_date"] = d
            tire_set["removed_km"] = k

            history_entry = {
                "date": d, "km": k, "type": "writeoff", "service": "",
                "work": f"Списаны шины: {tire_set.get('name', '')} ({tire_set.get('size', '')})",
                "parts": "", "cost": 0,
            }
            catalog.setdefault("history", []).insert(0, history_entry)

            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("➖ Списать комплект", size=16),
            content=ft.Container(
                content=ft.Column([
                    ft.Text(f"{tire_set.get('name', '')} · {tire_set.get('size', '')}",
                            size=13, weight=ft.FontWeight.BOLD),
                    ft.Text("Комплект уйдёт в историю.", size=11,
                            color=C("text_muted"), italic=True),
                    ft.Divider(height=1, color=C("border")),
                    ft.Row([date_field, km_field], spacing=10),
                    error_text,
                ], spacing=10, tight=True, width=460),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СПИСАТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def render():
        content_column.controls.clear()

        tires = get_tires()
        current_km = state["current_km"]
        current_season = get_current_season()
        season_label = "☀ Лето" if current_season == "summer" else "❄ Зима"

        installed = next((t for t in tires if t.get("status") == "installed"), None)

        # Шапка со статусом
        header_info = ft.Column([
            ft.Text(f"Сейчас сезон: {season_label}", size=14, weight=ft.FontWeight.BOLD,
                    color=C("accent")),
            ft.Text(f"Установлено: {installed.get('name', '—') + ' ' + installed.get('size', '') if installed else '—'}",
                    size=12, color=C("text_secondary")),
        ], spacing=2)

        add_btn = ft.ElevatedButton(
            "➕ ДОБАВИТЬ КОМПЛЕКТ", icon=ft.Icons.ADD,
            on_click=lambda _e: open_add_set_dialog(),
            bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

        content_column.controls.append(
            ft.Container(
                content=ft.Row([header_info, ft.Container(expand=True), add_btn],
                               vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=14, bgcolor=C("accent_soft"), border_radius=8))

        content_column.controls.append(
            ft.Text("🔘 МОИ КОМПЛЕКТЫ", size=14, weight=ft.FontWeight.BOLD,
                    color=C("accent")))

        if not tires:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.TIRE_REPAIR, size=48, color=C("text_disabled")),
                        ft.Text("Комплектов нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        else:
            for t in tires:
                if t.get("status") == "written_off":
                    continue
                season = t.get("season", "summer")
                season_icon = "☀" if season == "summer" else "❄"
                is_installed = t.get("status") == "installed"

                total_km = 0
                if is_installed and t.get("install_km", 0) > 0:
                    total_km = current_km - t["install_km"]
                elif t.get("install_km", 0) > 0 and t.get("removed_km", 0) > 0:
                    total_km = t["removed_km"] - t["install_km"]

                # Ресурс
                threshold = 50000
                if total_km >= threshold * 0.8:
                    res_color = C("danger")
                    res_label = "🔴 Износ"
                elif total_km >= threshold * 0.5:
                    res_color = C("warning_strong")
                    res_label = "🟡 Следить"
                else:
                    res_color = C("success")
                    res_label = "🟢 ОК"

                left_bar = ft.Container(width=4, bgcolor=res_color, border_radius=2)

                title_row = ft.Row([
                    ft.Text(f"{season_icon} {t.get('name', '')}", size=14,
                            weight=ft.FontWeight.BOLD, color=C("text"), expand=True),
                    ft.Text("УСТАНОВЛЕНО" if is_installed else "В ГАРАЖЕ",
                            size=10, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.WHITE if is_installed else ft.Colors.BLACK),
                ], spacing=6)
                title_row.controls[-1] = ft.Container(
                    content=ft.Text("УСТАНОВЛЕНО" if is_installed else "В ГАРАЖЕ",
                                    size=10, weight=ft.FontWeight.BOLD,
                                    color=ft.Colors.WHITE),
                    bgcolor=ft.Colors.GREEN_600 if is_installed else C("text_muted"),
                    border_radius=6,
                    padding=ft.padding.symmetric(horizontal=8, vertical=3))

                info_col = ft.Column([
                    title_row,
                    ft.Text(f"Размер: {t.get('size', '—')}", size=12, color=C("text_secondary")),
                ], spacing=2)

                if is_installed:
                    info_col.controls.append(
                        ft.Text(f"Установлено: {t.get('install_date', '—')} · {format_km(t.get('install_km', 0))} км",
                                size=11, color=C("text_muted")))
                elif t.get("install_km", 0) > 0 and t.get("removed_km", 0) > 0:
                    info_col.controls.append(
                        ft.Text(f"Снято: {t.get('removed_date', '—')} · {format_km(t.get('removed_km', 0))} км",
                                size=11, color=C("text_muted")))
                if total_km > 0:
                    info_col.controls.append(
                        ft.Text(f"Проехал всего: {format_km(total_km)} км · {res_label}",
                                size=11, color=res_color, weight=ft.FontWeight.BOLD))

                def make_install(ts=t):
                    def handler(_e):
                        open_install_dialog(ts)
                    return handler

                def make_writeoff(ts=t):
                    def handler(_e):
                        open_writeoff_dialog(ts)
                    return handler

                btn_row = ft.Row([], spacing=6, wrap=True)
                if not is_installed:
                    btn_row.controls.append(
                        ft.ElevatedButton("🔄 УСТАНОВИТЬ", on_click=make_install(t),
                                          bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE))
                btn_row.controls.append(
                    ft.ElevatedButton("➖ СПИСАТЬ", on_click=make_writeoff(t),
                                      bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE))

                card = ft.Container(
                    content=ft.Row([left_bar,
                                    ft.Column([info_col, btn_row], spacing=8, expand=True)],
                                   spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                    padding=12, bgcolor=C("card"),
                    border=ft.border.all(2, res_color), border_radius=8,
                    margin=ft.margin.only(bottom=6))
                content_column.controls.append(card)

        # Справочная информация
        content_column.controls.append(
            ft.Text("📖 СПРАВОЧНАЯ ИНФОРМАЦИЯ", size=14, weight=ft.FontWeight.BOLD,
                    color=C("accent")))

        ref_data = []
        for block in catalog.get("tire_reference", []):
            ref_data.append((block.get("title", ""), block.get("items", [])))

        if not ref_data:
            content_column.controls.append(
                ft.Container(
                    content=ft.Text(
                        "📖 Справочные данные для этой машины не заполнены.\n"
                        "Добавь их в JSON машины (блок tire_reference).",
                        size=12, color=C("text_soft"), italic=True),
                    padding=20, alignment=ft.alignment.center))

        for title, lines in ref_data:
            block = ft.Container(
                content=ft.Column([
                    ft.Text(title, size=13, weight=ft.FontWeight.BOLD, color=C("accent")),
                    ft.Column([ft.Text(f"• {ln}", size=11, color=C("text")) for ln in lines],
                              spacing=2),
                ], spacing=4),
                padding=12, bgcolor=C("surface"), border_radius=8,
                margin=ft.margin.only(bottom=6))
            content_column.controls.append(block)

        page.update()

    render()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("🔘 ШИНЫ / СЕЗОН", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)


# === ВКЛАДКА: АНАЛОГИ / МОМЕНТЫ ===
def build_analogs_torque_tab(catalog, state, page):
    data = load_analogs_torque()
    if data is None:
        return ft.Column([
            ft.Container(
                content=ft.Column([
                    ft.Text("🔩 АНАЛОГИ / МОМЕНТЫ", size=16, weight=ft.FontWeight.BOLD,
                            color=C("accent")),
                    ft.Divider(height=1, color=C("border")),
                ], spacing=10),
                padding=10, bgcolor=C("surface"), border_radius=8,
                margin=ft.margin.only(bottom=10)),
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.FOLDER_OFF, size=48, color=C("danger_muted")),
                    ft.Text("Файл catalogs/analogs_torque.json не найден",
                            size=14, color=C("text_muted")),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=40, alignment=ft.alignment.center),
        ], expand=True)

    analogs = data.get("analogs", [])
    torque_specs = data.get("torque_specs", [])

    mode_state = {"active": "analogs"}
    expanded_state = {"groups": set()}
    search_state = {"text": ""}

    content_column = ft.Column(spacing=10, expand=True,
                               horizontal_alignment=ft.CrossAxisAlignment.STRETCH)

    def render():
        content_column.controls.clear()

        def make_mode_btn(label, key):
            def on_click(_e):
                mode_state["active"] = key
                expanded_state["groups"].clear()
                search_state["text"] = ""
                search_field.value = ""
                render()
            is_active = mode_state["active"] == key
            return ft.ElevatedButton(
                text=label, on_click=on_click,
                content=ft.Container(
                    content=ft.Text(label, size=13),
                    padding=ft.padding.symmetric(horizontal=16, vertical=10),
                    border_radius=6,
                    bgcolor=C("accent_soft") if is_active else C("card"),
                    border=ft.border.all(2 if is_active else 1,
                                         C("accent_border") if is_active else C("border"))),
                style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))

        mode_row = ft.Row([
            make_mode_btn("🔄 Аналоги", "analogs"),
            make_mode_btn("🔩 Моменты затяжки", "torque"),
            make_mode_btn("🛒 Мои запчасти", "purchases"),
        ], spacing=8, wrap=True)

        content_column.controls.append(mode_row)
        content_column.controls.append(ft.Divider(height=1, color=C("border")))

        search_text = search_state["text"].lower().strip()

        if mode_state["active"] == "analogs":
            render_analogs(search_text)
        elif mode_state["active"] == "torque":
            render_torque(search_text)
        else:
            render_purchases(search_text)

        page.update()

    def toggle_group(gid):
        if gid in expanded_state["groups"]:
            expanded_state["groups"].discard(gid)
        else:
            expanded_state["groups"].add(gid)
        render()

    def render_analogs(search_text):
        groups = {}
        for item in analogs:
            g = item.get("group", "Прочее")
            groups.setdefault(g, []).append(item)

        shown_total = 0
        for gname in sorted(groups.keys()):
            items = groups[gname]
            visible = []
            for item in items:
                if search_text:
                    haystack = " ".join([
                        item.get("name", ""), item.get("vag", ""),
                        item.get("oem", ""), item.get("verified", ""),
                        item.get("budget", ""), item.get("note", "")
                    ]).lower()
                    if search_text not in haystack:
                        continue
                visible.append(item)

            if not visible and search_text:
                continue

            is_expanded = gname in expanded_state["groups"] or bool(search_text)
            count_text = f"{len(visible)} поз." if search_text else f"{len(items)} поз."

            def make_toggle(g=gname):
                def handler(_e):
                    toggle_group(g)
                return handler

            header = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.EXPAND_MORE if is_expanded else ft.Icons.CHEVRON_RIGHT,
                            size=20, color=C("accent")),
                    ft.Text(gname, size=13, weight=ft.FontWeight.BOLD,
                            color=C("accent"), expand=True),
                    ft.Text(count_text, size=11, color=C("text_muted")),
                ], spacing=6),
                padding=10, bgcolor=C("accent_soft"), border_radius=8,
                on_click=make_toggle(gname), ink=True,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(header)

            if is_expanded:
                for item in visible:
                    shown_total += 1
                    card = build_analog_card(item)
                    content_column.controls.append(card)

        if shown_total == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SEARCH_OFF, size=48, color=C("text_disabled")),
                        ft.Text("Ничего не найдено", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))

    def build_analog_card(item):
        name = item.get("name", "")
        prefix = get_article_prefix()
        is_kia = (prefix == "OEM")

        rows = [
            ft.Text(name, size=13, weight=ft.FontWeight.BOLD, color=C("text"),
                    selectable=True),
        ]
        if is_kia:
            oem_val = item.get("oem", "")
            if oem_val:
                rows.append(ft.Text(f"OEM: {oem_val}", size=11,
                                    color=C("text_secondary"), selectable=True))
        else:
            vag_val = item.get("vag", "")
            if vag_val:
                rows.append(ft.Text(f"VAG: {vag_val}", size=11,
                                    color=C("text_secondary"), selectable=True))
            oem_val = item.get("oem", "")
            if oem_val:
                rows.append(ft.Text(f"Оригинал (конвейер): {oem_val}", size=11,
                                    color=C("text_secondary"), selectable=True))
        verified = item.get("verified", "")
        if verified:
            rows.append(ft.Text(f"Проверенные: {verified}", size=11,
                                color=C("text_secondary"), selectable=True))
        budget = item.get("budget", "")
        if budget:
            rows.append(ft.Text(f"Бюджет: {budget}", size=11,
                                color=C("text_secondary"), selectable=True))
        note = item.get("note", "")
        if note:
            rows.append(ft.Text(f"💬 {note}", size=11, color=C("text_muted"),
                                italic=True, selectable=True))

        return ft.Container(
            content=ft.Column(rows, spacing=4),
            padding=12, bgcolor=C("card"),
            border=ft.border.all(1, C("border")), border_radius=6,
            margin=ft.margin.only(left=20, bottom=4))

    def render_torque(search_text):
        shown_total = 0
        for block in torque_specs:
            gname = block.get("group", "Прочее")
            items = block.get("items", [])
            visible = []
            for it in items:
                if search_text:
                    haystack = (it.get("name", "") + " " + it.get("value", "")).lower()
                    if search_text not in haystack:
                        continue
                visible.append(it)

            if not visible and search_text:
                continue

            is_expanded = gname in expanded_state["groups"] or bool(search_text)

            def make_toggle(g=gname):
                def handler(_e):
                    toggle_group(g)
                return handler

            header = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.EXPAND_MORE if is_expanded else ft.Icons.CHEVRON_RIGHT,
                            size=20, color=C("accent")),
                    ft.Text(gname, size=13, weight=ft.FontWeight.BOLD,
                            color=C("accent"), expand=True),
                    ft.Text(f"{len(visible)}", size=11, color=C("text_muted")),
                ], spacing=6),
                padding=10, bgcolor=C("accent_soft"), border_radius=8,
                on_click=make_toggle(gname), ink=True,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(header)

            if is_expanded:
                for it in visible:
                    shown_total += 1
                    card = ft.Container(
                        content=ft.Row([
                            ft.Text(it.get("name", ""), size=12, color=C("text"),
                                    expand=True, selectable=True),
                            ft.Text(it.get("value", ""), size=12,
                                    weight=ft.FontWeight.BOLD, color=C("accent"),
                                    selectable=True),
                        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=10, bgcolor=C("card"),
                        border=ft.border.all(1, C("border")), border_radius=6,
                        margin=ft.margin.only(left=20, bottom=4))
                    content_column.controls.append(card)

        if shown_total == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SEARCH_OFF, size=48, color=C("text_disabled")),
                        ft.Text("Ничего не найдено", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))

    def render_purchases(search_text):
        all_purchases = load_my_purchases()
        _cur_car = get_current_car_id()
        purchases = [p for p in all_purchases
                     if not p.get("car_id") or p.get("car_id") == _cur_car]

        add_btn = ft.ElevatedButton(
            "➕ ДОБАВИТЬ ПОКУПКУ", icon=ft.Icons.ADD,
            on_click=lambda _e: open_purchase_dialog(None),
            bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))
        content_column.controls.append(
            ft.Row([add_btn], alignment=ft.MainAxisAlignment.END))

        shown = 0
        for p in purchases:
            if search_text:
                haystack = " ".join([
                    p.get("name", ""),
                    p.get("article", ""),
                    p.get("shop", ""),
                    p.get("note", ""),
                ]).lower()
                if search_text not in haystack:
                    continue
            shown += 1

            info_col = ft.Column([
                ft.Text(p.get("name", "—"), size=13, weight=ft.FontWeight.BOLD, color=C("text")),
                ft.Text(f"Артикул: {p.get('article', '—') or '—'}", size=11,
                        color=C("text_secondary"), font_family="monospace"),
                ft.Row([
                    ft.Text(f"📅 {p.get('date', '—')}", size=11, color=C("text_muted")),
                    ft.Text(f"· 🛒 {p.get('shop', '—') or '—'}", size=11, color=C("text_muted")),
                    ft.Text(f"· ×{p.get('qty', 1)}", size=11, color=C("text_muted")),
                ], spacing=4),
            ], spacing=2, expand=True)

            if p.get("price"):
                info_col.controls.append(
                    ft.Text(f"💰 {p['price']} ₽", size=11,
                            color=C("accent"), weight=ft.FontWeight.BOLD))
            if p.get("note"):
                info_col.controls.append(
                    ft.Text(f"💬 {p['note']}", size=11, color=C("text_muted"), italic=True))
            if p.get("linked_item_id"):
                info_col.controls.append(
                    ft.Text(f"🔗 Привязано: {p['linked_item_id']}", size=10,
                            color=C("text_soft"), font_family="monospace"))

            def make_edit(pu=p):
                def handler(_e):
                    open_purchase_dialog(pu)
                return handler

            def make_del(pu=p):
                def handler(_e):
                    open_delete_purchase_dialog(pu)
                return handler

            info_col.controls.append(ft.Row([
                ft.Container(expand=True),
                ft.IconButton(ft.Icons.EDIT, icon_size=18, icon_color=C("accent_icon"),
                              tooltip="Редактировать", on_click=make_edit(p)),
                ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18, icon_color=C("danger_icon"),
                              tooltip="Удалить", on_click=make_del(p)),
            ], spacing=4))

            card = ft.Container(
                content=ft.Row([
                    ft.Container(width=4, bgcolor=C("purchase_text"), border_radius=2),
                    info_col,
                ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=C("purchase_bg"),
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)

        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SHOPPING_CART_OUTLINED, size=48, color=C("text_disabled")),
                        ft.Text("Покупок нет" if not search_text else "Ничего не найдено",
                                size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))

    def open_purchase_dialog(purchase=None):
        is_edit = purchase is not None

        name_field = ft.TextField(label="Название запчасти", width=460, text_size=13,
                                  value=purchase.get("name", "") if is_edit else "")
        article_field = ft.TextField(label="Артикул", width=460, text_size=13,
                                     value=purchase.get("article", "") if is_edit else "")
        date_field = ft.TextField(label="Дата (ДД.ММ.ГГГГ)", width=200, text_size=13,
                                  value=purchase.get("date", today_str()) if is_edit else today_str())
        qty_field = ft.TextField(label="Количество", width=140, text_size=13,
                                 value=str(purchase.get("qty", 1)) if is_edit else "1",
                                 keyboard_type=ft.KeyboardType.NUMBER)
        price_field = ft.TextField(label="Цена, ₽", width=200, text_size=13,
                                   value=str(purchase.get("price", 0)) if is_edit else "0",
                                   keyboard_type=ft.KeyboardType.NUMBER)
        shop_field = ft.TextField(label="Где куплено", width=460, text_size=13,
                                  value=purchase.get("shop", "") if is_edit else "")
        linked_field = ft.TextField(
            label="ID детали в каталоге (необязательно)", width=460, text_size=13,
            value=purchase.get("linked_item_id", "") if is_edit else "",
            hint_text="Например: discs_f_l")
        note_field = ft.TextField(label="Заметка", width=460, text_size=13,
                                  multiline=True, min_lines=2, max_lines=3,
                                  value=purchase.get("note", "") if is_edit else "")
        error_text = ft.Text("", color=C("danger"), size=12)

        def on_save(_e):
            name = name_field.value.strip() if name_field.value else ""
            if not name:
                error_text.value = "Впиши название"
                page.update()
                return
            d = date_field.value.strip() if date_field.value else ""
            if not parse_date(d):
                error_text.value = "Дата должна быть в формате ДД.ММ.ГГГГ"
                page.update()
                return
            qty = parse_float(qty_field.value) or 1
            price = parse_float(price_field.value) or 0

            purchases = load_my_purchases()

            if is_edit:
                target = None
                for p in purchases:
                    if p.get("id") == purchase.get("id"):
                        target = p
                        break
                if target is None:
                    error_text.value = "Покупка не найдена (возможно, удалена). Закрой окно."
                    page.update()
                    return
                target["name"] = name
                target["article"] = article_field.value.strip() if article_field.value else ""
                target["date"] = d
                target["qty"] = qty
                target["price"] = price
                target["shop"] = shop_field.value.strip() if shop_field.value else ""
                target["linked_item_id"] = linked_field.value.strip() if linked_field.value else ""
                target["note"] = note_field.value.strip() if note_field.value else ""
            else:
                new_purchase = {
                    "id": f"purch_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                    "date": d,
                    "name": name,
                    "article": article_field.value.strip() if article_field.value else "",
                    "qty": qty,
                    "price": price,
                    "shop": shop_field.value.strip() if shop_field.value else "",
                    "linked_item_id": linked_field.value.strip() if linked_field.value else "",
                    "note": note_field.value.strip() if note_field.value else "",
                    "car_id": get_current_car_id(),
                }
                purchases.insert(0, new_purchase)

            save_my_purchases(purchases)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать покупку" if is_edit else "🛒 Новая покупка", size=16),
            content=ft.Container(
                content=ft.Column([
                    name_field,
                    article_field,
                    ft.Row([date_field, qty_field], spacing=10),
                    price_field,
                    shop_field,
                    linked_field,
                    note_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_purchase_dialog(purchase):
        def on_confirm(_e):
            purchases = load_my_purchases()
            purchases = [p for p in purchases if p.get("id") != purchase.get("id")]
            save_my_purchases(purchases)
            page.close(dialog)
            render()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить покупку?", size=16),
            content=ft.Text(
                f"«{purchase.get('name', '')}» будет удалена из списка.", size=13),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    search_field = ft.TextField(
        hint_text="Поиск по названию, VAG-номеру, аналогу...",
        prefix_icon=ft.Icons.SEARCH, width=500, text_size=13,
        border_radius=8,
        on_change=lambda _e: (search_state.update({"text": search_field.value or ""}),
                              render()))

    content_column.controls.append(search_field)
    render()

    scroll_area = ft.Column(
        [content_column],
        scroll=ft.ScrollMode.AUTO,
        expand=True,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH)

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("🔩 АНАЛОГИ / МОМЕНТЫ", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        scroll_area,
    ], expand=True)

# === ВКЛАДКА: КОНТАКТЫ ===
def build_contacts_tab(catalog, state, page, on_saved):
    content_column = ft.ListView(expand=True, spacing=4, padding=0)
    filter_state = {"active": "all"}

    CONTACT_TYPES = {
        "service": ("🔧 Сервис", C("service_text"), C("service_bg")),
        "master": ("👤 Мастер", C("accent_icon"), C("accent_soft")),
        "shop": ("🛒 Магазин", C("parts_text"), C("parts_bg")),
        "other": ("📦 Прочее", C("other_text"), C("other_bg")),
    }

    def open_contact_dialog(contact=None):
        is_edit = contact is not None

        name_field = ft.TextField(label="Имя / Название", width=460, text_size=13,
                                  value=contact.get("name", "") if is_edit else "")
        type_field = ft.Dropdown(
            label="Тип", width=460, text_size=13,
            value=contact.get("type", "service") if is_edit else "service",
            options=[
                ft.dropdown.Option(key="service", text="🔧 Сервис"),
                ft.dropdown.Option(key="master", text="👤 Мастер"),
                ft.dropdown.Option(key="shop", text="🛒 Магазин"),
                ft.dropdown.Option(key="other", text="📦 Прочее"),
            ])
        phone_field = ft.TextField(label="Телефон", width=460, text_size=13,
                                   value=contact.get("phone", "") if is_edit else "")
        address_field = ft.TextField(label="Адрес", width=460, text_size=13,
                                     value=contact.get("address", "") if is_edit else "")
        note_field = ft.TextField(label="Заметка", width=460, text_size=13,
                                  multiline=True, min_lines=2, max_lines=4,
                                  value=contact.get("note", "") if is_edit else "")

        error_text = ft.Text("", color=C("danger"), size=12)

        def on_save(_e):
            name = name_field.value.strip() if name_field.value else ""
            if not name:
                error_text.value = "Впиши имя или название"
                page.update()
                return
            data = {
                "name": name,
                "type": type_field.value or "other",
                "phone": phone_field.value.strip() if phone_field.value else "",
                "address": address_field.value.strip() if address_field.value else "",
                "note": note_field.value.strip() if note_field.value else "",
            }
            if is_edit:
                contact.update(data)
            else:
                data["id"] = f"contact_{datetime.now().strftime('%Y%m%d%H%M%S')}"
                catalog.setdefault("contacts_log", []).insert(0, data)
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("✏️ Редактировать контакт" if is_edit else "➕ Новый контакт", size=16),
            content=ft.Container(
                content=ft.Column([
                    name_field,
                    type_field,
                    phone_field,
                    address_field,
                    note_field,
                    error_text,
                ], spacing=10, tight=True, width=480, scroll=ft.ScrollMode.AUTO),
                padding=ft.padding.only(top=10)),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СОХРАНИТЬ", on_click=on_save,
                                  bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def open_delete_dialog(contact):
        def on_confirm(_e):
            catalog["contacts_log"] = [c for c in catalog.get("contacts_log", [])
                                       if c.get("id") != contact.get("id")]
            save_catalog(catalog)
            page.close(dialog)
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Удалить контакт?", size=16),
            content=ft.Text(f"«{contact.get('name', '')}» будет удалён.", size=13),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def apply_filters():
        content_column.controls.clear()
        search_text = search_field.value.lower().strip() if search_field.value else ""
        contacts = catalog.get("contacts_log", [])
        shown = 0
        for contact in contacts:
            ctype = contact.get("type", "other")
            if ctype not in CONTACT_TYPES:
                ctype = "other"
            if filter_state["active"] != "all" and filter_state["active"] != ctype:
                continue
            if search_text:
                haystack = " ".join([
                    contact.get("name", ""),
                    contact.get("phone", ""),
                    contact.get("address", ""),
                    contact.get("note", ""),
                ]).lower()
                if search_text not in haystack:
                    continue
            shown += 1
            label, color, bg = CONTACT_TYPES[ctype]

            def make_edit(c=contact):
                def handler(_e):
                    open_contact_dialog(c)
                return handler

            def make_delete(c=contact):
                def handler(_e):
                    open_delete_dialog(c)
                return handler

            left_bar = ft.Container(width=4, bgcolor=color, border_radius=2)

            info_col = ft.Column([
                ft.Row([
                    ft.Text(contact.get("name", "—"), size=14, weight=ft.FontWeight.BOLD,
                            color=C("text"), expand=True),
                    ft.Text(label, size=11, color=color, weight=ft.FontWeight.BOLD),
                ], spacing=6),
            ], spacing=2)

            if contact.get("phone"):
                info_col.controls.append(
                    ft.Text(f"📞 {contact['phone']}", size=12, color=C("text")))
            if contact.get("address"):
                info_col.controls.append(
                    ft.Text(f"📍 {contact['address']}", size=11, color=C("text_muted")))
            if contact.get("note"):
                info_col.controls.append(
                    ft.Text(f"💬 {contact['note']}", size=11, color=C("text_muted")))

            info_col.controls.append(
                ft.Row([
                    ft.Container(expand=True),
                    ft.IconButton(ft.Icons.EDIT, icon_size=18, icon_color=C("accent_icon"),
                                  tooltip="Редактировать", on_click=make_edit(contact)),
                    ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_size=18,
                                  icon_color=C("danger_icon"),
                                  tooltip="Удалить", on_click=make_delete(contact)),
                ], spacing=4))

            card = ft.Container(
                content=ft.Row([
                    left_bar,
                    ft.Column([info_col], spacing=2, expand=True),
                ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                padding=10, bgcolor=bg,
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(card)

        if shown == 0:
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.CONTACTS_OUTLINED, size=48, color=C("text_disabled")),
                        ft.Text("Контактов нет", size=14, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
        page.update()

    search_field = ft.TextField(
        hint_text="Поиск по имени, телефону, адресу...",
        prefix_icon=ft.Icons.SEARCH, width=400, text_size=13,
        border_radius=8, on_change=lambda _e: apply_filters())

    def make_filter_btn(label, color, filter_key):
        def on_click(_e):
            filter_state["active"] = filter_key
            for btn in filter_buttons:
                btn.content.border = ft.border.all(
                    2 if btn.data == filter_key else 1,
                    C("accent_border") if btn.data == filter_key else C("border"))
                btn.content.bgcolor = C("accent_soft") if btn.data == filter_key else C("card")
            apply_filters()

        btn = ft.ElevatedButton(
            text=label, data=filter_key, on_click=on_click,
            width=135,
            content=ft.Container(
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE, color=color, size=12),
                                ft.Text(label, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=6),
                border_radius=6,
                bgcolor=C("accent_soft") if filter_key == "all" else C("card"),
                border=ft.border.all(2 if filter_key == "all" else 1,
                                     C("accent_border") if filter_key == "all" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        return btn

    filter_buttons = [
        make_filter_btn("Все", C("text_muted"), "all"),
        make_filter_btn("🔧 Сервис", C("service_text"), "service"),
        make_filter_btn("👤 Мастер", C("accent_icon"), "master"),
        make_filter_btn("🛒 Магазин", ft.Colors.CYAN_700, "shop"),
        make_filter_btn("📦 Прочее", C("other_text"), "other"),
    ]
    filters_row = ft.Row(filter_buttons, spacing=8, scroll=ft.ScrollMode.AUTO)

    add_btn = ft.ElevatedButton(
        "+ НОВЫЙ КОНТАКТ", icon=ft.Icons.ADD,
        on_click=lambda _e: open_contact_dialog(None),
        bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE,
        style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

    apply_filters()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("📇 КОНТАКТЫ", size=16, weight=ft.FontWeight.BOLD,
                            color=C("accent")),
                    ft.Container(expand=True),
                    add_btn,
                ]),
                ft.Divider(height=1, color=C("border")),
                filters_row,
                search_field,
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)

# === ВКЛАДКА: EXCEL ===
def build_excel_tab(catalog, state, page):
    content_column = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)
    last_export_text = ft.Text("Экспортов ещё не было", size=12, color=C("text_muted"))

    def make_export_btn(label, icon, color, handler):
        return ft.ElevatedButton(
            content=ft.Row([
                ft.Icon(icon, size=18, color=ft.Colors.WHITE),
                ft.Text(label, size=13, color=ft.Colors.WHITE),
            ], spacing=8),
            on_click=handler,
            bgcolor=color,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=14)))

    def do_export(rows, filename, columns, title):
        if not rows:
            last_export_text.value = f"⚠ {title}: нет данных для выгрузки"
            last_export_text.color = C("warning_text")
            page.update()
            return
        path = export_to_csv(rows, filename, columns)
        last_export_text.value = f"✔ {title}: {os.path.basename(path)} (папка exports)"
        last_export_text.color = C("success")
        page.update()

    def export_history(_e):
        rows = catalog.get("history", [])
        columns = [
            ("date", "Дата"),
            ("km", "Пробег"),
            ("type", "Тип"),
            ("service", "Сервис"),
            ("work", "Работа"),
            ("parts", "Запчасти"),
            ("installed_article", "Артикул установленной"),
            ("cost", "Стоимость"),
        ]
        do_export(rows, "history.csv", columns, "История")

    def export_expenses(_e):
        rows = catalog.get("expenses_log", [])
        columns = [
            ("date", "Дата"),
            ("km", "Пробег"),
            ("expense_type", "Тип расхода"),
            ("name", "Наименование"),
            ("qty", "Количество"),
            ("price", "Цена"),
            ("total", "Итого"),
            ("service", "Место"),
        ]
        do_export(rows, "expenses.csv", columns, "Расходы")

    def export_fuel(_e):
        rows = catalog.get("fuel_log", [])
        columns = [
            ("date", "Дата"),
            ("km", "Пробег"),
            ("liters", "Литры"),
            ("price_per_liter", "Цена за литр"),
            ("total", "Сумма"),
            ("fuel_type", "Тип топлива"),
            ("station", "АЗС"),
            ("is_full", "До полного"),
            ("comment", "Комментарий"),
        ]
        do_export(rows, "fuel.csv", columns, "Заправки")

    def export_contacts(_e):
        rows = catalog.get("contacts_log", [])
        columns = [
            ("name", "Имя"),
            ("type", "Тип"),
            ("phone", "Телефон"),
            ("address", "Адрес"),
            ("note", "Заметка"),
        ]
        do_export(rows, "contacts.csv", columns, "Контакты")

    def export_defects(_e):
        rows = catalog.get("defect_log", [])
        columns = [
            ("item_name", "Деталь"),
            ("date", "Дата"),
            ("km", "Пробег"),
            ("found_by", "Кто нашёл"),
            ("note", "Заметка"),
            ("status", "Статус"),
            ("resolved_date", "Дата снятия"),
            ("resolved_km", "Пробег снятия"),
        ]
        do_export(rows, "defects.csv", columns, "Журнал дефектов")

    def export_notes(_e):
        rows = catalog.get("notes", [])
        columns = [
            ("title", "Заголовок"),
            ("text", "Текст"),
            ("priority", "Важность"),
            ("date", "Дата"),
        ]
        do_export(rows, "notes.csv", columns, "Заметки")

    def export_analogs(_e):
        data = load_analogs_torque()
        if not data:
            last_export_text.value = "⚠ Аналоги: файл analogs_torque.json не найден"
            last_export_text.color = C("danger_strong")
            page.update()
            return
        rows = data.get("analogs", [])
        columns = [
            ("group", "Группа"),
            ("name", "Название"),
            ("vag", "VAG"),
            ("oem", "OEM"),
            ("verified", "Проверенные"),
            ("budget", "Бюджет"),
            ("note", "Заметка"),
        ]
        do_export(rows, "analogs.csv", columns, "Аналоги")

    def export_torque(_e):
        data = load_analogs_torque()
        if not data:
            last_export_text.value = "⚠ Моменты: файл analogs_torque.json не найден"
            last_export_text.color = C("danger_strong")
            page.update()
            return
        rows = []
        for block in data.get("torque_specs", []):
            gname = block.get("group", "")
            for item in block.get("items", []):
                rows.append({
                    "group": gname,
                    "name": item.get("name", ""),
                    "value": item.get("value", ""),
                })
        columns = [
            ("group", "Группа"),
            ("name", "Что затягиваем"),
            ("value", "Момент"),
        ]
        do_export(rows, "torque.csv", columns, "Моменты затяжки")

    buttons_row = ft.Row([
        make_export_btn("📜 История", ft.Icons.HISTORY, C("accent_icon"), export_history),
        make_export_btn("💰 Расходы", ft.Icons.PAYMENTS, C("service_text"), export_expenses),
        make_export_btn("⛽ Заправки", ft.Icons.LOCAL_GAS_STATION, C("teal_text"), export_fuel),
    ], spacing=10, wrap=True)

    buttons_row2 = ft.Row([
        make_export_btn("📇 Контакты", ft.Icons.CONTACTS, ft.Colors.CYAN_700, export_contacts),
        make_export_btn("⚠ Дефекты", ft.Icons.WARNING_AMBER, C("danger_strong"), export_defects),
        make_export_btn("📝 Заметки", ft.Icons.NOTE_ALT, C("other_text"), export_notes),
    ], spacing=10, wrap=True)

    buttons_row3 = ft.Row([
        make_export_btn("🔄 Аналоги", ft.Icons.SWAP_HORIZ, C("success"), export_analogs),
        make_export_btn("🔩 Моменты", ft.Icons.BUILD_CIRCLE, ft.Colors.ORANGE_800, export_torque),
    ], spacing=10, wrap=True)

    content_column.controls.append(
        ft.Container(
            content=ft.Column([
                ft.Text("📊 ЭКСПОРТ В CSV", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
                ft.Text("Выгрузи данные в CSV-файл. Файлы сохраняются в папку exports "
                        "рядом с программой. Открываются в Excel.",
                        size=12, color=C("text_muted")),
                ft.Container(height=6),
                buttons_row,
                buttons_row2,
                buttons_row3,
                ft.Divider(height=1, color=C("border")),
                last_export_text,
            ], spacing=10),
            padding=14, bgcolor=C("surface"), border_radius=8))

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("📊 EXCEL", size=16, weight=ft.FontWeight.BOLD, color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)

# === ВКЛАДКА: ОЧИСТКА ===
def clear_radar_marks(catalog):
    """Чистит отметки замен и дефекты в радаре ТО."""
    for item in catalog.get("maintenance_radar", []):
        item["last_km"] = 0
        item["last_date"] = ""
        item.pop("defect", None)
    catalog["defect_log"] = []
    save_catalog(catalog)


def clear_parts_marks(catalog):
    """Чистит отметки замен и дефекты в каталоге запчастей."""
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for item in subcat.get("items", []):
                item["last_km"] = 0
                item["last_date"] = ""
                item.pop("defect", None)
    catalog["defect_log"] = []
    save_catalog(catalog)
    
    
def clear_topup_stock(catalog):
    """Обнуляет остатки жидкостей и чистит историю доливок."""
    for fluid in catalog.get("topup_stock", []):
        fluid["qty"] = 0
    catalog["topup_log"] = []
    save_catalog(catalog)
    
    
CLEAN_TARGETS = {
    "history": "История",
    "expenses_log": "Расходы",
    "fuel_log": "Заправки",
    "topup_log": "Доливки",
    "defect_log": "Дефекты",
    "notes": "Заметки",
    "contacts_log": "Контакты",
}


def clear_section(catalog, key):
    """Чистит один раздел. Для дефектов дополнительно снимает отметки с деталей."""
    if key == "defect_log":
        catalog["defect_log"] = []
        for item in catalog.get("maintenance_radar", []):
            item.pop("defect", None)
        for category in catalog.get("parts", []):
            for subcat in category.get("subcategories", []):
                for item in subcat.get("items", []):
                    item.pop("defect", None)
    else:
        catalog[key] = []
    save_catalog(catalog)


def build_cleanup_tab(catalog, state, page, on_saved):
    content_column = ft.Column(spacing=12, scroll=ft.ScrollMode.AUTO, expand=True)
    status_text = ft.Text(state.get("cleanup_status", ""), size=13,
                          weight=ft.FontWeight.BOLD,
                          color=state.get("cleanup_status_color", C("text_muted")))

    def do_clear(keys, label):
        def on_confirm(_e):
            for k in keys:
                clear_section(catalog, k)
            page.close(dialog)
            state["cleanup_status"] = f"✔ Готово: {label} очищено"
            state["cleanup_status_color"] = C("success")
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("🗑 Подтверди очистку", size=16),
            content=ft.Column([
                ft.Text(f"Будет очищено: {label}", size=13),
                ft.Text("Сначала сделай экспорт! Отката не будет.",
                        size=12, color=C("danger_strong"), weight=ft.FontWeight.BOLD),
                ft.Text("Резервная копия сохранится в папке catalogs/_backup.",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("УДАЛИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.RED_600, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    def make_btn(label, icon, color, keys):
        return ft.ElevatedButton(
            content=ft.Row([
                ft.Icon(icon, size=18, color=ft.Colors.WHITE),
                ft.Text(label, size=13, color=ft.Colors.WHITE),
            ], spacing=8),
            on_click=lambda _e: do_clear(keys, label),
            bgcolor=color,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=14)))

    content_column.controls.append(
        ft.Container(
            content=ft.Column([
                ft.Text("🧹 ОЧИСТКА ДАННЫХ", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
                ft.Text("Удаление записей из базы. Перед очисткой сделай экспорт в CSV "
                        "(вкладка EXCEL) — отката не будет. Автоматическая резервная "
                        "копия файла сохраняется в catalogs/_backup.",
                        size=12, color=C("text_muted")),
            ], spacing=10),
            padding=14, bgcolor=C("surface"), border_radius=8))

    content_column.controls.append(
        ft.Text("По разделам:", size=13, weight=ft.FontWeight.BOLD,
                color=C("accent")))

    content_column.controls.append(
        ft.Row([
            make_btn("📜 История", ft.Icons.HISTORY, C("accent_icon"), ["history"]),
            make_btn("💰 Расходы", ft.Icons.PAYMENTS, C("service_text"), ["expenses_log"]),
            make_btn("⛽ Заправки", ft.Icons.LOCAL_GAS_STATION, C("teal_text"), ["fuel_log"]),
        ], spacing=10, wrap=True))

    content_column.controls.append(
        ft.Row([
            make_btn("💧 Доливки", ft.Icons.WATER_DROP, ft.Colors.CYAN_700, ["topup_log"]),
            make_btn("⚠ Дефекты", ft.Icons.WARNING_AMBER, C("danger_strong"), ["defect_log"]),
            make_btn("📝 Заметки", ft.Icons.NOTE_ALT, C("other_text"), ["notes"]),
        ], spacing=10, wrap=True))

    content_column.controls.append(
        ft.Row([
            make_btn("📇 Контакты", ft.Icons.CONTACTS, C("success"), ["contacts_log"]),
        ], spacing=10, wrap=True))

    content_column.controls.append(ft.Divider(height=1, color=C("border")))
    content_column.controls.append(
        ft.Text("Сброс отметок замен (названия и интервалы остаются):",
                size=13, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE_800))

    def do_clear_marks(func, label, title="♻ Сбросить отметки замен?"):
        def on_confirm(_e):
            func(catalog)
            page.close(dialog)
            state["cleanup_status"] = f"✔ Готово: {label} очищен"
            state["cleanup_status_color"] = C("success")
            on_saved()

        def on_cancel(_e):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title, size=16),
            content=ft.Column([
                ft.Text(f"Будет очищено: {label}", size=13),
                ft.Text("Пробеги и даты замен обнулятся, дефекты снимутся, "
                        "журнал дефектов очистится. Названия и интервалы останутся.",
                        size=12, color=C("danger_strong"), weight=ft.FontWeight.BOLD),
                ft.Text("Резервная копия сохранится в папке catalogs/_backup.",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=440),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СБРОСИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.ORANGE_800, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    content_column.controls.append(
        ft.Row([
            ft.ElevatedButton(
                content=ft.Row([
                    ft.Icon(ft.Icons.RESTART_ALT, size=18, color=ft.Colors.WHITE),
                    ft.Text("РАДАР ТО", size=13, color=ft.Colors.WHITE),
                ], spacing=8),
                on_click=lambda _e: do_clear_marks(clear_radar_marks, "радар ТО"),
                bgcolor=ft.Colors.ORANGE_800,
                style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=14))),
            ft.ElevatedButton(
                content=ft.Row([
                    ft.Icon(ft.Icons.RESTART_ALT, size=18, color=ft.Colors.WHITE),
                    ft.Text("ЗАПЧАСТИ", size=13, color=ft.Colors.WHITE),
                ], spacing=8),
                on_click=lambda _e: do_clear_marks(clear_parts_marks, "запчасти"),
                bgcolor=ft.Colors.ORANGE_800,
                style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=14))),
                    ft.ElevatedButton(
                content=ft.Row([
                    ft.Icon(ft.Icons.WATER_DROP, size=18, color=ft.Colors.WHITE),
                    ft.Text("ОСТАТКИ ДОЛИВКИ", size=13, color=ft.Colors.WHITE),
                ], spacing=8),
                on_click=lambda _e: do_clear_marks(clear_topup_stock, "остатки доливки",
                                                   "🧴 Обнулить остатки доливки?"),
                bgcolor=ft.Colors.CYAN_700,
                style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=14))),
        ], spacing=10, wrap=True))

    content_column.controls.append(ft.Divider(height=1, color=C("border")))

    content_column.controls.append(
        ft.Text("Всё сразу:", size=13, weight=ft.FontWeight.BOLD, color=C("danger_strong")))

    content_column.controls.append(
        ft.ElevatedButton(
            content=ft.Row([
                ft.Icon(ft.Icons.DELETE_FOREVER, size=20, color=ft.Colors.WHITE),
                ft.Text("ОЧИСТИТЬ ВСЁ", size=14, color=ft.Colors.WHITE,
                        weight=ft.FontWeight.BOLD),
            ], spacing=8),
            on_click=lambda _e: do_clear(list(CLEAN_TARGETS.keys()),
                                         "все разделы"),
            bgcolor=ft.Colors.RED_800,
            style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=20, vertical=16))))

    content_column.controls.append(ft.Divider(height=1, color=C("border")))
    content_column.controls.append(status_text)

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("🧹 ОЧИСТКА", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        content_column,
    ], expand=True)

# === ВКЛАДКА: ТЕМА ===
def build_theme_tab(catalog, state, page, on_saved):
    current = get_theme(catalog)

    def make_theme_card(mode, title, icon, bg, border):
        is_active = current == mode

        def on_click(_e):
            set_theme(catalog, mode)
            apply_theme(page, mode)
            on_saved()

        card = ft.Container(
            content=ft.Column([
                ft.Icon(icon, size=48, color=C("accent")),
                ft.Text(title, size=16, weight=ft.FontWeight.BOLD,
                        color=C("text")),
                ft.Text("Активна" if is_active else "Нажми, чтобы включить",
                        size=11, color=C("text_muted")),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8),
            padding=30, width=200,
            bgcolor=bg,
            border=ft.border.all(3 if is_active else 1,
                                 C("accent_border") if is_active else border),
            border_radius=12,
            on_click=on_click, ink=True)

        return card

    light_card = make_theme_card("light", "☀ Светлая", ft.Icons.LIGHT_MODE,
                                 ft.Colors.WHITE, C("border"))
    dark_card = make_theme_card("dark", "🌙 Тёмная", ft.Icons.DARK_MODE,
                                C("text_secondary"), C("text_soft"))

    info = ft.Text(f"Текущая тема: {'Тёмная' if current == 'dark' else 'Светлая'}. "
                   f"Выбор сохраняется и применится при следующем запуске.",
                   size=12, color=C("text_muted"))

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("🌓 ТЕМА", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
            ], spacing=10),
            padding=10, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        ft.Container(
            content=ft.Column([
                ft.Row([light_card, dark_card], spacing=20, wrap=True),
                ft.Divider(height=1, color=C("border")),
                info,
            ], spacing=16),
            padding=20, bgcolor=C("card"), border_radius=8),
    ], expand=True)

# === ВКЛАДКА: НАСТРОЙКИ (ОПЦИИ МАШИНЫ) ===
def build_settings_tab(catalog, state, page, on_saved):
    """Динамические галочки опций. Читает available_options из JSON, сохраняет в options."""
    available_options = catalog.get("car", {}).get("available_options", [])
    if not available_options:
        # Заглушка, если в JSON пусто
        available_options = [{"id": "ac", "name": "Кондиционер / климат", "icon": "❄️"}]

    content_column = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)
    status_text = ft.Text("", size=14, weight=ft.FontWeight.BOLD, color=C("text_muted"))

    options_state = list(catalog.get("car", {}).get("options", []) or [])
    checkboxes = {}

    def set_status(msg, color):
        status_text.value = msg
        status_text.color = color
        page.update()

    def on_save(_e):
        selected = []
        for opt in available_options:
            key = opt.get("id")
            cb = checkboxes.get(key)
            if cb is not None and cb.value:
                selected.append(key)
        catalog.setdefault("car", {})["options"] = selected
        save_catalog(catalog)
        set_status("✔ Сохранено", C("success"))
        on_saved()

    for opt in available_options:
        key = opt.get("id")
        label = opt.get("name", key)
        icon = opt.get("icon", "")
        cb = ft.Checkbox(
            label=f"{icon} {label}",
            value=(key in options_state),
            on_change=lambda _e: set_status("", C("text_muted")))
        checkboxes[key] = cb
        content_column.controls.append(
            ft.Container(
                content=cb,
                padding=12, bgcolor=C("card"),
                border=ft.border.all(1, C("border")), border_radius=8))

    content_column.controls.append(ft.Divider(height=1, color=C("border")))
    content_column.controls.append(status_text)

    save_btn = ft.ElevatedButton(
        "💾 СОХРАНИТЬ", on_click=on_save,
        bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE,
        style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("⚙️ НАСТРОЙКИ", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
                ft.Text("Галочки опций машины. Если опции нет — связанные "
                        "подкатегории (например, обогрев сидений) скрываются в "
                        "«Запчастях». Каталог один, максимальный.", size=12,
                        color=C("text_muted")),
            ], spacing=10),
            padding=14, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        ft.Row([save_btn, status_text], spacing=14, wrap=True,
               vertical_alignment=ft.CrossAxisAlignment.CENTER),
        content_column,
    ], expand=True)

# === ЗАГЛУШКА ===
def build_placeholder(title):
    return ft.Column([
        ft.Icon(name=ft.Icons.CONSTRUCTION, size=64, color=C("text_disabled")),
        ft.Text(title, size=20, weight=ft.FontWeight.BOLD),
        ft.Text("Вкладка в разработке", size=14, color=C("text_soft")),
    ], alignment=ft.MainAxisAlignment.CENTER,
       horizontal_alignment=ft.CrossAxisAlignment.CENTER,
       expand=True)

# === ВКЛАДКА: МОИ ИНТЕРВАЛЫ ЗАМЕНЫ ===
def build_intervals_tab(catalog, state, page, on_saved):
    """Вкладка для редактирования интервалов замены.
    Читает/пишет catalogs/<машина>_intervals.json. Каталог не трогает.
    По умолчанию показывает только запчасти с интервалом > 0."""
    content_column = ft.Column(spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)
    status_text = ft.Text(
        state.get("intervals_status", ""),
        size=12,
        color=state.get("intervals_status_color", C("text_muted")))
    show_all_state = {"value": False}
    
    def set_status(msg, color):
        status_text.value = msg
        status_text.color = color
        state["intervals_status"] = msg
        state["intervals_status_color"] = color
        page.update()

        async def clear_later():
            await asyncio.sleep(3)
            state.pop("intervals_status", None)
            state.pop("intervals_status_color", None)
            try:
                if status_text.value == msg:
                    status_text.value = ""
                    status_text.color = C("text_muted")
                    page.update()
            except Exception:
                pass

        page.run_task(clear_later)

    # Собираем все запчасти: id, name, interval_km, источник
    all_items = []
    for item in catalog.get("maintenance_radar", []):
        all_items.append({
            "id": item.get("id", ""),
            "name": item.get("name", ""),
            "interval": item.get("interval_km", 0),
            "source": "Радар ТО",
        })
    for category in catalog.get("parts", []):
        for subcat in category.get("subcategories", []):
            for item in subcat.get("items", []):
                all_items.append({
                    "id": item.get("id", ""),
                    "name": item.get("name", ""),
                    "interval": item.get("interval_km", 0),
                    "source": f"{category.get('category_id', '')} · {subcat.get('subcategory_id', '')}",
                })

    # Поля ввода: id -> TextField (создаём один раз, чтобы не терять введённое)
    fields = {}

    def get_or_make_field(entry):
        item_id = entry["id"]
        if item_id not in fields:
            fields[item_id] = ft.TextField(
                value=str(entry["interval"]),
                width=140, text_size=13,
                keyboard_type=ft.KeyboardType.NUMBER,
                text_align=ft.TextAlign.RIGHT)
        return fields[item_id]

    def render():
        content_column.controls.clear()

        visible = []
        for entry in all_items:
            if show_all_state["value"]:
                visible.append(entry)
            else:
                if entry["interval"] and entry["interval"] > 0:
                    visible.append(entry)

        if not visible:
            hint = ("Нет запчастей без интервала" if show_all_state["value"]
                    else "Нет запчастей с интервалом > 0. Включи галочку выше, чтобы увидеть все.")
            content_column.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.TUNE, size=48, color=C("text_disabled")),
                        ft.Text(hint, size=13, color=C("text_soft")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40, alignment=ft.alignment.center))
            page.update()
            return

        for entry in visible:
            field = get_or_make_field(entry)
            row = ft.Container(
                content=ft.Row([
                    ft.Column([
                        ft.Text(entry["name"], size=12, weight=ft.FontWeight.BOLD,
                                color=C("text")),
                        ft.Text(f"id: {entry['id']} · {entry['source']}", size=10,
                                color=C("text_soft"), font_family="monospace"),
                    ], spacing=1, expand=True),
                    ft.Text("км", size=11, color=C("text_muted")),
                    field,
                ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=8, bgcolor=C("card"),
                border=ft.border.all(1, C("border_light")), border_radius=6,
                margin=ft.margin.only(bottom=4))
            content_column.controls.append(row)

        page.update()

    def on_toggle_all(_e):
        show_all_state["value"] = bool(show_all_checkbox.value)
        render()

    show_all_checkbox = ft.Checkbox(
        label="Показать все (включая запчасти без интервала)",
        value=False,
        on_change=on_toggle_all)

    def on_save(_e):
        if not CATALOG_PATH:
            set_status("⚠ Не выбран каталог машины", C("danger_strong"))
            return
        intervals_path = get_intervals_path(CATALOG_PATH)
        new_data = {}
        for item_id, field in fields.items():
            val = parse_int(field.value)
            if val is None or val < 0:
                msg = f"⚠ Неверное число в поле «{item_id}»: {field.value}"
                set_status(msg, C("danger_strong"))
                return
            new_data[item_id] = val
        try:
            os.makedirs(CATALOGS_DIR, exist_ok=True)
            with open(intervals_path, "w", encoding="utf-8") as f:
                json.dump(new_data, f, ensure_ascii=False, indent=2)
            msg = f"✔ Сохранено: {os.path.basename(intervals_path)}"
            set_status(msg, C("success"))
            on_saved()
        except OSError as ex:
            set_status(f"⚠ Ошибка записи: {ex}", C("danger_strong"))

    def on_reset(_e):
        def on_confirm(_e2):
            if not CATALOG_PATH:
                page.close(dialog)
                return
            intervals_path = get_intervals_path(CATALOG_PATH)
            try:
                if os.path.exists(intervals_path):
                    os.remove(intervals_path)
            except OSError:
                pass
            page.close(dialog)
            msg = "✔ Сброшено к дефолтам. Перезайди на вкладку."
            set_status("✔ Сброшено к дефолтам. Перезайди на вкладку.", C("success"))
            on_saved()

        def on_cancel(_e2):
            page.close(dialog)

        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("♻ Сбросить к дефолтам?", size=16),
            content=ft.Column([
                ft.Text("Файл интервалов будет удалён. При следующей загрузке "
                        "каталога он создастся заново из дефолтов.", size=12),
                ft.Text("Каталог машины (история, расходы, дефекты) НЕ пострадает.",
                        size=11, color=C("text_muted"), italic=True),
            ], spacing=8, tight=True, width=420),
            actions=[
                ft.TextButton("ОТМЕНА", on_click=on_cancel),
                ft.ElevatedButton("СБРОСИТЬ", on_click=on_confirm,
                                  bgcolor=ft.Colors.ORANGE_800, color=ft.Colors.WHITE),
            ],
            actions_alignment=ft.MainAxisAlignment.END)
        page.open(dialog)

    save_btn = ft.ElevatedButton(
        "💾 СОХРАНИТЬ", on_click=on_save,
        bgcolor=ft.Colors.GREEN_600, color=ft.Colors.WHITE,
        style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))
    reset_btn = ft.ElevatedButton(
        "♻ СБРОСИТЬ К ДЕФОЛТАМ", on_click=on_reset,
        bgcolor=ft.Colors.ORANGE_800, color=ft.Colors.WHITE,
        style=ft.ButtonStyle(padding=ft.padding.symmetric(horizontal=16, vertical=12)))

    render()

    return ft.Column([
        ft.Container(
            content=ft.Column([
                ft.Text("📏 МОИ ИНТЕРВАЛЫ ЗАМЕНЫ", size=16, weight=ft.FontWeight.BOLD,
                        color=C("accent")),
                ft.Divider(height=1, color=C("border")),
                ft.Text("Здесь можно поменять интервал замены для запчастей, "
                        "которые меняются по пробегу. Значения сохраняются в отдельный "
                        "файл интервалов машины. Каталог (история, расходы, дефекты) "
                        "не меняется.", size=12, color=C("text_muted")),
            ], spacing=10),
            padding=14, bgcolor=C("surface"), border_radius=8,
            margin=ft.margin.only(bottom=10)),
        ft.Row([save_btn, reset_btn], spacing=10, wrap=True),
        show_all_checkbox,
        status_text,
        ft.Divider(height=1, color=C("border")),
        content_column,
    ], expand=True)
           


# === СПИСОК ВКЛАДОК ===
TABS = [
    ("radar", "🔧 РАДАР ТО", ft.Icons.SHIELD),
    ("parts", "📦 ЗАПЧАСТИ", ft.Icons.INVENTORY_2),
    ("defects", "🔴 ЖУРНАЛ ДЕФЕКТОВ", ft.Icons.WARNING_AMBER),
    ("expenses", "💰 РАСХОДЫ", ft.Icons.PAYMENTS),
    ("fuel", "⛽ БЕНЗИН", ft.Icons.LOCAL_GAS_STATION),
    ("history", "📜 ИСТОРИЯ", ft.Icons.HISTORY),
    ("notes", "📋 ЗАМЕТКИ", ft.Icons.NOTE_ALT),
    ("topup", "💧 ДОЛИВКА", ft.Icons.WATER_DROP),
    ("tires", "🔘 ШИНЫ / СЕЗОН", ft.Icons.TIRE_REPAIR),
    ("analogs", "🔩 АНАЛОГИ / МОМЕНТЫ", ft.Icons.SWAP_HORIZ),
    ("contacts", "📇 КОНТАКТЫ", ft.Icons.CONTACTS),
    ("excel", "📊 EXCEL", ft.Icons.TABLE_VIEW),
    ("theme", "🌓 ТЕМА", ft.Icons.DARK_MODE),
    ("settings", "⚙️ НАСТРОЙКИ", ft.Icons.SETTINGS),
    ("intervals", "📏 МОИ ИНТЕРВАЛЫ ЗАМЕНЫ", ft.Icons.TUNE),
    ("cleanup", "🧹 ОЧИСТКА", ft.Icons.DELETE_SWEEP),
]


# === ГЛАВНАЯ ===
def main(page: ft.Page):
    global CATALOG_PATH

    page.title = "Polo Assistant"
    page.window.width = 1200
    page.window.height = 780
    page.padding = 15

        # 1. Читаем список машин
    cars = load_cars_list()
    if not cars:
        page.add(ft.Text("❌ Файл catalogs/cars.json пуст или неверный",
                         color=C("danger"), size=16))
        return

    # 2. Берём сохранённую машину (или первую, если ничего не сохранено)
    saved_car_id = get_saved_car_id()
    current_car = get_active_car(cars, saved_car_id)
    state_car = {"current_car": current_car, "cars": cars}
    CATALOG_PATH = get_catalog_path_for_car(current_car)

    # 3. Грузим её каталог
    catalog = load_catalog()
    if catalog is None:
        page.add(ft.Text(
            f"❌ Не найден файл каталога: {CATALOG_PATH}",
            color=C("danger"), size=16))
        return

    state = {
        "current_km": catalog["car"]["current_km"],
        "active_tab": "radar",
        "expanded_cats": set(),
    }
    
    def build_car_logo(car):
        """Строит картинку-значок машины из assets/. Если файла нет — нейтральная иконка."""
        logo_file = car.get("logo", "") if car else ""
        if logo_file:
            full_path = os.path.join(ASSETS_DIR, logo_file)
            if os.path.exists(full_path):
                return ft.Image(
                    src=logo_file,
                    width=40,
                    height=40,
                    fit=ft.ImageFit.CONTAIN,
                )
        return ft.Icon(ft.Icons.DIRECTIONS_CAR, size=36, color=C("accent"))

    # Применяем сохранённую тему
    apply_theme(page, get_theme(catalog))
    
    
    odometer_field = ft.TextField(
        value=str(state["current_km"]), width=140, text_size=16,
        text_align=ft.TextAlign.RIGHT, label="Пробег, км",
        color=C("text"), bgcolor=C("card"), border_color=C("border"))

    cars_dropdown = ft.Dropdown(
        width=240,
        text_size=13,
        bgcolor=C("card"), color=C("text"), border_color=C("border"),
        value=current_car.get("id", "") if current_car else "",
        options=[
            ft.dropdown.Option(
                key=c.get("id", ""),
                text=c.get("name", "Без названия"),
            )
            for c in cars
        ],
        label="Машина",
        on_change=lambda e: switch_car(e.control.value),
    )

    car_logo_container = ft.Container(
        content=build_car_logo(current_car),
        width=44, height=44,
        alignment=ft.alignment.center,
    )

    header_text_column = ft.Column([
        ft.Text(catalog["car"]["model"], size=20, weight=ft.FontWeight.BOLD),
        ft.Text(f"VIN: {catalog['car']['vin']}  |  Гос. номер: {catalog['car']['plate']}  |  {catalog['car']['engine']}",
                size=12, color=C("text_muted")),
    ], spacing=2)

    header = ft.Container(
        content=ft.Row([
            car_logo_container,
            header_text_column,
            ft.Container(expand=True),
            ft.Column([
                cars_dropdown,
                odometer_field,
            ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.END),
        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
           vertical_alignment=ft.CrossAxisAlignment.CENTER),
        padding=15, bgcolor=C("card"), border_radius=10,
        border=ft.border.all(1, C("border")))
    # (header теперь доступен по имени)

    content_area = ft.Column(expand=True)
    nav_buttons = []
    
    def switch_car(new_car_id):
        """Переключает активную машину: перечитывает список, грузит новый каталог."""
        nonlocal catalog, current_car
        cars_local = state_car.get("cars", [])
        new_car = get_active_car(cars_local, new_car_id)
        if not new_car:
            return

        new_catalog_path = get_catalog_path_for_car(new_car)

        if not os.path.exists(new_catalog_path):
            content_area.controls.clear()
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.INFO_OUTLINE, size=56, color=C("warning_text")),
                        ft.Text(
                            f"Каталог для «{new_car.get('name', '')}» ещё не создан",
                            size=16, weight=ft.FontWeight.BOLD),
                        ft.Text(
                            f"Положи файл {new_car.get('file', '')} в папку catalogs/",
                            size=12, color=C("text_muted")),
                    ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
                    padding=60, alignment=ft.alignment.center))
            cars_dropdown.value = new_car_id
            page.update()
            return

        # Файл есть — переключаемся
        global CATALOG_PATH
        CATALOG_PATH = new_catalog_path
        new_catalog = load_catalog()
        if new_catalog is None:
            page.update()
            return

        catalog = new_catalog
        current_car = new_car
        state_car["current_car"] = new_car
        set_saved_car_id(new_car_id)

        # Обновляем шапку
        state["current_km"] = catalog["car"]["current_km"]
        odometer_field.value = str(state["current_km"])
        cars_dropdown.value = new_car_id
        car_logo_container.content = build_car_logo(new_car)

        header_text_column.controls[0].value = catalog["car"]["model"]
        header_text_column.controls[1].value = (
            f"VIN: {catalog['car']['vin']}  |  "
            f"Гос. номер: {catalog['car']['plate']}  |  "
            f"{catalog['car']['engine']}")

        page.title = f"Polo Assistant — {catalog['car']['model']}"
        refresh_active_tab()

    def update_theme_visuals():
        """Обновляет цвета шапки, меню, полей ввода и кнопок навигации при смене темы."""
        # 1. Верхняя шапка
        header.bgcolor = C("card")
        header.border = ft.border.all(1, C("border"))
        odometer_field.bgcolor = C("card")
        odometer_field.color = C("text")
        odometer_field.border_color = C("border")
        cars_dropdown.bgcolor = C("card")
        cars_dropdown.color = C("text")
        cars_dropdown.border_color = C("border")
        
        # 2. Левое меню и контент
        nav_container.bgcolor = C("card")
        nav_container.border = ft.border.all(1, C("border"))
        content_container.bgcolor = C("card")
        content_container.border = ft.border.all(1, C("border"))
        
        # 3. Кнопки навигации
        for btn in nav_buttons:
            is_active = (btn.data == state.get("active_tab", "radar"))
            btn.content.bgcolor = C("accent_soft") if is_active else C("card")
            btn.content.border = ft.border.all(
                2 if is_active else 1,
                C("accent_border") if is_active else C("border"))
            # Обновляем цвет текста в кнопке
            if btn.content.content.controls[1]: # это ft.Text в Row
                btn.content.content.controls[1].color = C("text")

    def refresh_active_tab():
        nonlocal catalog
        fresh = load_catalog()
        if fresh is not None:
            catalog = fresh
            state["current_km"] = catalog["car"]["current_km"]
            odometer_field.value = str(state["current_km"])

        tab_id = state.get("active_tab", "radar")
        content_area.controls.clear()

        if tab_id == "radar":
            content_area.controls.append(build_radar_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "parts":
            content_area.controls.append(build_parts_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "defects":
            content_area.controls.append(build_defect_log_tab(catalog, state, page))
        elif tab_id == "expenses":
            content_area.controls.append(build_expenses_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "fuel":
            content_area.controls.append(build_fuel_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "history":
            content_area.controls.append(build_history_tab(catalog, state, page))
        elif tab_id == "notes":
            content_area.controls.append(build_notes_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "topup":
            content_area.controls.append(build_topup_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "tires":
            content_area.controls.append(build_tires_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "analogs":
            content_area.controls.append(build_analogs_torque_tab(catalog, state, page))
        elif tab_id == "contacts":
            content_area.controls.append(build_contacts_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "excel":
            content_area.controls.append(build_excel_tab(catalog, state, page))
        elif tab_id == "theme":
            content_area.controls.append(build_theme_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "settings":
            content_area.controls.append(build_settings_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "intervals":
            content_area.controls.append(build_intervals_tab(catalog, state, page, refresh_active_tab))
        elif tab_id == "cleanup":
            content_area.controls.append(build_cleanup_tab(catalog, state, page, refresh_active_tab))
        else:
            title = next((t[1] for t in TABS if t[0] == tab_id), tab_id)
            content_area.controls.append(build_placeholder(title))

        # Растянуть вкладку на всю высоту content_area — чтобы внутренний
        # content_column со scroll получил высоту и включил скролл.
        if content_area.controls:
            content_area.controls[-1].expand = True

        update_theme_visuals()
        page.update()

    def switch_tab(tab_id):
        state["active_tab"] = tab_id
        refresh_active_tab()

    for tab_id, tab_name, tab_icon in TABS:
        btn = ft.ElevatedButton(
            text=tab_name, icon=tab_icon, data=tab_id,
            width=240, height=42,
            on_click=lambda _e, tid=tab_id: switch_tab(tid),
            content=ft.Container(
                content=ft.Row([ft.Icon(tab_icon, size=18), ft.Text(tab_name, size=12)]),
                padding=ft.padding.symmetric(horizontal=10, vertical=8),
                border_radius=6,
                bgcolor=C("accent_soft") if tab_id == "radar" else C("card"),
                border=ft.border.all(2 if tab_id == "radar" else 1,
                                     C("accent_border") if tab_id == "radar" else C("border"))),
            style=ft.ButtonStyle(padding=0, bgcolor=ft.Colors.TRANSPARENT))
        nav_buttons.append(btn)

    nav_column = ft.Column(nav_buttons, spacing=4, scroll=ft.ScrollMode.AUTO, expand=True)
    nav_container = ft.Container(content=nav_column, width=260, bgcolor=C("card"),
                                 border_radius=10, padding=8,
                                 border=ft.border.all(1, C("border")))
    content_container = ft.Container(content=content_area, expand=True, bgcolor=C("card"),
                                     border_radius=10, padding=15,
                                     border=ft.border.all(1, C("border")),
                                     margin=ft.margin.only(left=10))

    page.add(
        ft.Column([
            header,
            ft.Row([
                nav_container,
                content_container,
            ], expand=True, vertical_alignment=ft.CrossAxisAlignment.STRETCH),
        ], expand=True))

    def on_odometer_change(e):
        raw = (e.control.value or "").strip()
        if not raw:
            page.open(ft.SnackBar(
                ft.Text("Пробег не может быть пустым"),
                bgcolor=ft.Colors.RED_600))
            return
        try:
            new_km = int(raw)
        except (ValueError, TypeError):
            page.open(ft.SnackBar(
                ft.Text("Пробег — только целое число"),
                bgcolor=ft.Colors.RED_600))
            return
        if new_km < 0:
            page.open(ft.SnackBar(
                ft.Text("Пробег не может быть отрицательным"),
                bgcolor=ft.Colors.RED_600))
            return
        state["current_km"] = new_km
        catalog["car"]["current_km"] = new_km
        save_catalog(catalog)
        if state["active_tab"] in ["radar", "parts", "defects", "expenses", "fuel",
                                    "history", "topup", "tires"]:
            refresh_active_tab()

    odometer_field.on_change = on_odometer_change
    page.title = f"Polo Assistant — {catalog['car']['model']}"
    switch_tab("radar")


if __name__ == "__main__":
    ft.app(target=main)