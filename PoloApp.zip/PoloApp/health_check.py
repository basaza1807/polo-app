# health_check.py — проверка данных проекта (только чтение)
# P3 (дубли id в радаре и запчастях) теперь считаются ДИЗАЙНОМ, если
# содержательные поля совпадают. Если разъедутся — будет предупреждение.
import json
import os
from datetime import datetime

CATALOGS = "catalogs"
problems = []
warnings = []
info = []

def P(msg): problems.append(msg)
def W(msg): warnings.append(msg)
def I(msg): info.append(msg)

def load_json(path, label):
    if not os.path.exists(path):
        P(f"{label}: файл не найден ({path})")
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        P(f"{label}: JSON битый — {e}")
        return None

def is_date(s):
    if s is None or s == "": return True
    try:
        datetime.strptime(str(s).strip(), "%d.%m.%Y")
        return True
    except (ValueError, AttributeError):
        return False

def check_date(v, loc):
    if not is_date(v): P(f"{loc}: дата «{v}» не в формате ДД.ММ.ГГГГ")

def walk_items(data):
    items = []
    for it in data.get("maintenance_radar", []):
        items.append(("radar", it))
    for cat in data.get("parts", []):
        cid = cat.get("category_id", "?")
        for sub in cat.get("subcategories", []):
            sid = sub.get("subcategory_id", "?")
            for it in sub.get("items", []):
                items.append((f"parts {cid}/{sid}", it))
    return items

# Поля, которые должны совпадать у одной и той же детали в радаре и запчастях
SYNC_FIELDS = ["name", "vag", "oem", "interval_km", "analog_best",
               "last_km", "last_date", "note", "installed_article", "pair_id"]

def check_same_id_groups(data, label):
    """Группирует записи по id. Если id встречается >1 раз — проверяет,
    что содержательные поля совпадают. Если name разное — проблема.
    Если name одинаковый, а другие поля разъехались — предупреждение."""
    by_id = {}
    for loc, it in walk_items(data):
        iid = it.get("id")
        if not iid: continue
        by_id.setdefault(iid, []).append((loc, it))
    for iid, records in by_id.items():
        if len(records) < 2:
            continue
        names = {r.get("name") for _, r in records}
        if len(names) > 1:
            P(f"{label}: id «{iid}» в {len(records)} местах с РАЗНЫМИ именами: {names}")
            continue
        # name одинаковое — проверяем остальные содержательные поля
        diffs = []
        for field in SYNC_FIELDS:
            if field == "name": continue
            values = {str(r.get(field)) for _, r in records}
            if len(values) > 1:
                diffs.append(field)
        if diffs:
            places = [loc for loc, _ in records]
            W(f"{label}: id «{iid}» в {len(records)} местах ({places}), различаются поля: {diffs}")

def check_catalog(path, label, prefix_type):
    data = load_json(path, label)
    if data is None: return None
    car = data.get("car")
    if not car:
        P(f"{label}: нет блока «car»")
    else:
        for f in ["model", "vin", "plate", "engine"]:
            if not car.get(f): P(f"{label} / car: пустое «{f}»")
        km = car.get("current_km")
        if not isinstance(km, (int, float)) or km < 0:
            P(f"{label} / car: пробег «{km}» некорректен")
        avail = car.get("available_options", [])
        if not isinstance(avail, list):
            P(f"{label} / car: available_options — не список"); avail = []
        avail_ids = set()
        for opt in avail:
            if not isinstance(opt, dict):
                P(f"{label} / available_options: элемент не объект"); continue
            oid = opt.get("id")
            if not oid: P(f"{label} / available_options: пустой id"); continue
            if oid in avail_ids: P(f"{label} / available_options: дубль id «{oid}»")
            avail_ids.add(oid)
            if not opt.get("name"): P(f"{label} / available_options: у «{oid}» нет name")
        opts = car.get("options", [])
        if not isinstance(opts, list):
            P(f"{label} / car: options — не список"); opts = []
        for oid in opts:
            if oid not in avail_ids:
                P(f"{label} / options: «{oid}» нет в available_options")
    wrong_field = "vag" if prefix_type == "OEM" else "oem"
    bad = [f"{loc} → {it.get('id','?')}" for loc, it in walk_items(data) if wrong_field in it]
    if bad:
        P(f"{label}: у {prefix_type}-машины найдено поле «{wrong_field}»: {', '.join(bad[:5])}")
    seen = {}
    for loc, it in walk_items(data):
        iid = it.get("id")
        if not iid: P(f"{label} / {loc}: пустой id"); continue
        if not it.get("name"):
            P(f"{label} / {loc}: пустое name (id={iid})")
        for f in ["last_km", "interval_km"]:
            v = it.get(f, 0)
            if not isinstance(v, (int, float)) or v < 0:
                P(f"{label} / {loc}: {f} «{v}» некорректен (id={iid})")
    for cat in data.get("parts", []):
        for sub in cat.get("subcategories", []):
            req = sub.get("requires_option")
            if req and req not in avail_ids:
                P(f"{label} / {cat.get('category_id','?')}/{sub.get('subcategory_id','?')}: requires_option=«{req}» нет в available_options")
    for loc, it in walk_items(data):
        if loc == "radar":
            req = it.get("requires_option")
            if req and req not in avail_ids:
                P(f"{label} / radar «{it.get('id')}»: requires_option=«{req}» нет в available_options")
    # pair_id
    pmap = {}
    for loc, it in walk_items(data):
        pid = it.get("pair_id")
        if pid: pmap.setdefault(pid, []).append(it.get("id", "?"))
    for pid, ids in pmap.items():
        if len(ids) == 1: P(f"{label}: pair_id «{pid}» только у одного id: {ids}")
        elif len(ids) > 2: W(f"{label}: pair_id «{pid}» у {len(ids)} id: {ids}")
    # даты
    for e in data.get("history", []): check_date(e.get("date"), f"{label}/history")
    for e in data.get("expenses_log", []): check_date(e.get("date"), f"{label}/expenses")
    for e in data.get("fuel_log", []): check_date(e.get("date"), f"{label}/fuel")
    for e in data.get("topup_log", []): check_date(e.get("date"), f"{label}/topup")
    for e in data.get("defect_log", []):
        check_date(e.get("date"), f"{label}/defect")
        if e.get("resolved_date"):
            check_date(e.get("resolved_date"), f"{label}/defect(resolved)")
    for e in data.get("notes", []): check_date(e.get("date"), f"{label}/notes")
    if not data.get("tire_reference"):
        W(f"{label}: tire_reference пуст (по П.27 должен быть заполнен)")
    rb = data.get("reference_blocks", [])
    if not rb: W(f"{label}: reference_blocks пуст")
    elif len(rb) < 13: W(f"{label}: reference_blocks — {len(rb)} блоков (обычно 13)")
    # проверка одинаковых id (дизайн)
    check_same_id_groups(data, label)
    return data

def check_intervals(cat_path, cat_data, label):
    base = os.path.splitext(os.path.basename(cat_path))[0]
    ipath = os.path.join(CATALOGS, f"{base}_intervals.json")
    if not os.path.exists(ipath):
        W(f"{label}: {ipath} не найден (создастся при запуске)"); return
    data = load_json(ipath, f"{label}/intervals")
    if data is None: return
    if not isinstance(data, dict):
        P(f"{label}/intervals: не словарь"); return
    cat_ids = set()
    for it in cat_data.get("maintenance_radar", []):
        if it.get("id"): cat_ids.add(it["id"])
    for cat in cat_data.get("parts", []):
        for sub in cat.get("subcategories", []):
            for it in sub.get("items", []):
                if it.get("id"): cat_ids.add(it["id"])
    for iid, v in data.items():
        if iid not in cat_ids: W(f"{label}/intervals: id «{iid}» нет в каталоге")
        if not isinstance(v, (int, float)) or v < 0:
            P(f"{label}/intervals: «{iid}» = «{v}» некорректно")

def check_analogs(path, label, expected_field):
    data = load_json(path, label)
    if data is None: return
    analogs = data.get("analogs", [])
    if not isinstance(analogs, list):
        P(f"{label}: analogs не список"); return
    I(f"{label}: аналогов {len(analogs)}")
    if expected_field == "oem":
        bad = [a.get("name", "?") for a in analogs if "vag" in a]
        if bad:
            P(f"{label}: у OEM-машины в аналогах поле «vag»: {', '.join(bad[:5])}")
    with_field = sum(1 for a in analogs if a.get(expected_field))
    if analogs and with_field < len(analogs) * 0.9:
        W(f"{label}: только {with_field} из {len(analogs)} аналогов имеют «{expected_field}»")
    torque = data.get("torque_specs", [])
    if not isinstance(torque, list):
        P(f"{label}: torque_specs не список"); return
    I(f"{label}: групп моментов {len(torque)}, моментов {sum(len(b.get('items', [])) for b in torque)}")

def check_purchases(car_ids):
    data = load_json(os.path.join(CATALOGS, "my_purchases.json"), "my_purchases")
    if data is None: return
    purchases = data.get("purchases", []) if isinstance(data, dict) else []
    if not isinstance(purchases, list):
        P("my_purchases: purchases не список"); return
    I(f"my_purchases: покупок {len(purchases)}")
    seen = set()
    for p in purchases:
        pid = p.get("id")
        if not pid: P("my_purchases: покупка без id"); continue
        if pid in seen: P(f"my_purchases: дубль id «{pid}»")
        seen.add(pid)
        cid = p.get("car_id")
        if not cid: W(f"my_purchases: у «{pid}» нет car_id (старая запись?)")
        elif cid not in car_ids: P(f"my_purchases: у «{pid}» car_id=«{cid}» — нет такой машины")
        if not p.get("name"): P(f"my_purchases: у «{pid}» пустое name")

def main():
    print("=" * 60)
    print("ПРОВЕРКА ДАННЫХ ПРОЕКТА")
    print("=" * 60)
    print()
    if not os.path.isdir(CATALOGS):
        print(f"❌ Папка {CATALOGS}/ не найдена. Запусти из папки проекта.")
        return
    cars = load_json(os.path.join(CATALOGS, "cars.json"), "cars.json") or []
    if not isinstance(cars, list):
        P("cars.json: ожидался список"); cars = []
    car_ids = set()
    for c in cars:
        cid = c.get("id")
        if not cid: P("cars.json: машина без id"); continue
        if cid in car_ids: P(f"cars.json: дубль id «{cid}»")
        car_ids.add(cid)
        fname = c.get("file")
        if not fname: P(f"cars.json: у «{cid}» нет file")
        elif not os.path.exists(os.path.join(CATALOGS, fname)):
            P(f"cars.json: файл «{fname}» для «{cid}» не найден")
        if not c.get("name"): P(f"cars.json: у «{cid}» пустое name")
    I(f"cars.json: машин {len(cars)}")
    for c in cars:
        cid, fname = c.get("id"), c.get("file")
        if not cid or not fname: continue
        fpath = os.path.join(CATALOGS, fname)
        if not os.path.exists(fpath): continue
        ptype = "OEM" if cid == "kia" else "VAG"
        data = check_catalog(fpath, cid, ptype)
        if data is not None: check_intervals(fpath, data, cid)
    check_analogs(os.path.join(CATALOGS, "analogs_torque.json"), "analogs_torque", "vag")
    if "kia" in car_ids:
        check_analogs(os.path.join(CATALOGS, "analogs_torque_kia.json"), "analogs_torque_kia", "oem")
    check_purchases(car_ids)
    st = load_json(os.path.join(CATALOGS, "settings.json"), "settings.json")
    if st is not None:
        a = st.get("active_car_id")
        if a and a not in car_ids:
            W(f"settings.json: active_car_id=«{a}» — нет в cars.json (выберется первая)")
    print()
    print("-" * 60)
    print("РЕЗУЛЬТАТ")
    print("-" * 60)
    print()
    if info:
        print(f"📊 ИНФОРМАЦИЯ ({len(info)}):")
        for m in info: print(f"   • {m}")
        print()
    if warnings:
        print(f"⚠ ПРЕДУПРЕЖДЕНИЯ ({len(warnings)}):")
        for m in warnings: print(f"   • {m}")
        print()
    if problems:
        print(f"❌ ПРОБЛЕМЫ ({len(problems)}):")
        for m in problems: print(f"   • {m}")
        print()
        print("Пришли мне список ПРОБЛЕМ — починим.")
    else:
        print("✅ ПРОБЛЕМ НЕ НАЙДЕНО. Всё в порядке.")
        if warnings: print("   (есть предупреждения — посмотри выше)")
        print()
        print("Можно переходить к ручному тесту интерфейса.")
    print()
    print("=" * 60)

if __name__ == "__main__":
    main()