README — КАК РАБОТАТЬ С БОЛЬШИМ main_flet.py

ПРОБЛЕМА: main_flet.py — ~6600 строк. Прикреплять целиком нельзя — обрежется.
РЕШЕНИЕ: Использовать скрипты-экстракторы.

СЦЕНАРИЙ 1. НУЖНА КОНКРЕТНАЯ ФУНКЦИЯ
1. Создай extract_func.py (код ниже).
2. Запусти: %Run extract_func.py build_parts_tab
3. Он создаст extracted_build_parts_tab.py. Прикрепи этот файл в чат.

# КОД extract_func.py:
import sys
MAIN = "main_flet.py"
func_name = sys.argv[1] if len(sys.argv) > 1 else "build_parts_tab"
OUT = f"extracted_{func_name}.py"
with open(MAIN, "r", encoding="utf-8") as f: lines = f.readlines()
start = None; end = None
for i, line in enumerate(lines):
    if line.startswith(f"def {func_name}("): start = i
    if start is not None and i > start and line.startswith("def ") and not line.startswith(f"def {func_name}("): end = i; break
if start is None: print(f"Не нашёл def {func_name}"); sys.exit(1)
if end is None: end = len(lines)
with open(OUT, "w", encoding="utf-8") as f: f.writelines(lines[start:end])
print(f"Готово: {OUT} ({end-start} строк)")

СЦЕНАРИЙ 2. НУЖЕН ВЕСЬ ФАЙЛ
1. Создай extract_full.py.
2. Запусти. Получишь 3 части по ~2000 строк.
3. Прикрепляй по одной.

СЦЕНАРИЙ 3. ДИАГНОСТИКА ОШИБКИ (КУСОК ВОКРУГ)
1. Создай extract_around.py (или попроси ИИ написать).
2. Запусти: %Run extract_around.py 1234 30 (номер строки и контекст).
3. Скопируй вывод в чат.